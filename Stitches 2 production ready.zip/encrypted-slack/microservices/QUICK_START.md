# 🚀 Stitches Microservices - Quick Start Guide

Welcome to the complete production-ready Stitches microservices platform! This guide will get you up and running in minutes.

## 🎯 What You're Getting

A complete team collaboration platform with:

- **8 Production-Ready Microservices** (Auth, Chat, Notifications, Projects, Video, AI Assistant, File Storage, API Gateway)
- **Complete Infrastructure** (PostgreSQL, Redis, MinIO, Nginx, Prometheus, Grafana)
- **Production Deployment** (Docker, monitoring, health checks, security)
- **Developer Tools** (40+ automation commands, real-time dashboard, testing suite)

## ⚡ Quick Start (5 Minutes)

### 1. Prerequisites
- Docker & Docker Compose installed
- 4GB+ RAM, 20GB+ disk space
- (Optional) API keys for full functionality

### 2. One-Command Setup
```bash
cd encrypted-slack/microservices
make full-setup
```

This command will:
- ✅ Install all required tools
- ✅ Set up environment configuration
- ✅ Build all microservices
- ✅ Start all infrastructure
- ✅ Run validation tests
- ✅ Start monitoring dashboards

### 3. Access Your Platform
- **API Gateway**: http://localhost:8080
- **Real-time Dashboard**: `make dashboard`
- **Grafana Monitoring**: http://localhost:3001 (admin/admin)
- **MinIO Console**: http://localhost:9001 (minioadmin/minioadmin)

## 🔧 Configuration (Optional)

### Add API Keys for Full Functionality
Edit `.env` file and add:
```bash
# AI Features (Recommended)
OPENAI_API_KEY=sk-your-openai-key-here

# Email Notifications (Recommended)
SENDGRID_API_KEY=SG.your-sendgrid-key-here

# Video Calls (Optional)
ZOOM_API_KEY=your-zoom-key
ZOOM_API_SECRET=your-zoom-secret
```

### Apply Configuration
```bash
make restart
```

## 📊 Essential Commands

### Service Management
```bash
make start              # Start all services
make stop               # Stop all services
make restart            # Restart all services
make status             # Check service status
make logs               # View all logs
```

### Monitoring & Health
```bash
make dashboard          # Real-time status dashboard
make health-check       # Check all services
make monitoring         # Start Grafana/Prometheus
```

### Testing & Validation
```bash
make test-integration   # Run integration tests
make validate           # Validate production readiness
make load-test          # Performance testing
```

### Production Deployment
```bash
make deploy-prod        # Deploy to production
make backup-full        # Backup everything
```

## 🏗️ System Architecture

### Microservices (All Production-Ready)
| Service | Port | Purpose |
|---------|------|---------|
| Auth Service | 50051 | Authentication, Users, Organizations |
| Chat Service | 50052 | Real-time Messaging, Channels |
| Notification Service | 50053 | Email, Push, In-app Notifications |
| Project Service | 50054 | Project Management, Tasks |
| Video Service | 50055 | Video Calls, WebRTC |
| Assistant Service | 50056 | AI Features, Transcription |
| File Service | 50057 | File Storage, Versioning |
| API Gateway | 8080 | REST API, Load Balancing |

### Infrastructure
| Component | Port | Purpose |
|-----------|------|---------|
| PostgreSQL | 5432 | Primary Database |
| Redis | 6379 | Caching, Pub/Sub |
| MinIO | 9000/9001 | Object Storage |
| Nginx | 80/443 | Load Balancer |
| Prometheus | 9090 | Metrics Collection |
| Grafana | 3001 | Monitoring Dashboards |

## 🧪 Testing Your Setup

### 1. Health Check
```bash
make health-check
```
Should show all services as "healthy" ✅

### 2. API Gateway Test
```bash
curl http://localhost:8080/health
```
Should return `{"status":"ok"}`

### 3. Integration Tests
```bash
make test-integration
```
Should pass all tests with 100% success rate

### 4. Real-time Dashboard
```bash
make dashboard
```
Shows live status of all services

## 🎛️ Real-time Dashboard

The status dashboard provides live monitoring:

```bash
make dashboard          # Single view
make dashboard-continuous  # Auto-refresh every 5s
```

Features:
- ✅ Service health status
- 📊 Resource usage (CPU, Memory)
- 🐳 Container status
- 🌐 System metrics
- 🔗 Quick action commands

## 🔍 Troubleshooting

### Common Issues

**Services won't start:**
```bash
make status              # Check what's running
make logs               # Check for errors
make restart            # Restart all services
```

**Health checks failing:**
```bash
make health-check-detailed  # Detailed diagnostics
make validate               # Check configuration
```

**Performance issues:**
```bash
make dashboard             # Check resource usage
docker stats               # Monitor containers
```

### Get Help
```bash
make help                  # All available commands
make help-troubleshooting  # Troubleshooting guide
make help-production       # Production deployment help
```

## 🚀 Production Deployment

### 1. Validate Production Readiness
```bash
make validate
```

### 2. Deploy to Production
```bash
make deploy-prod
```

This includes:
- ✅ Pre-flight checks
- ✅ Automatic backups
- ✅ Zero-downtime deployment
- ✅ Health verification
- ✅ Monitoring setup

### 3. Production Monitoring
```bash
make monitoring           # Start monitoring stack
make dashboard-continuous # Continuous monitoring
```

## 📈 Scaling & Performance

### Horizontal Scaling
```bash
# Scale specific services
docker-compose up -d --scale auth-service=3
docker-compose up -d --scale api-gateway=5
```

### Performance Testing
```bash
make load-test           # Run performance tests
make perf-monitor        # Monitor performance
```

### Resource Monitoring
```bash
make dashboard           # Real-time resource usage
```

## 🔒 Security Features

### Built-in Security
- ✅ Non-root containers
- ✅ Network isolation
- ✅ Secret management
- ✅ SSL/TLS support
- ✅ Rate limiting
- ✅ Input validation

### Security Scanning
```bash
make security-scan       # Scan for vulnerabilities
```

## 📚 Additional Resources

### Documentation
- [Complete Deployment Guide](./DEPLOYMENT.md)
- [Architecture Overview](./README.md)
- [API Documentation](http://localhost:8080/swagger)

### Monitoring
- [Grafana Dashboards](http://localhost:3001)
- [Prometheus Metrics](http://localhost:9090)
- [Health Check Script](./scripts/health-check.sh)

### Development
- [Makefile Commands](./Makefile)
- [Development Workflow](./README.md#development)
- [Testing Guide](./test-microservices.sh)

## 🎉 Success Checklist

After setup, you should have:

- [ ] ✅ All 8 microservices running
- [ ] ✅ All infrastructure services operational
- [ ] ✅ API Gateway responding at localhost:8080
- [ ] ✅ Health checks passing 100%
- [ ] ✅ Grafana dashboard accessible
- [ ] ✅ Real-time status dashboard working
- [ ] ✅ Integration tests passing

## 🆘 Support

If you encounter issues:

1. **Check Status**: `make dashboard`
2. **View Logs**: `make logs`
3. **Run Validation**: `make validate`
4. **Health Check**: `make health-check-detailed`
5. **Restart Services**: `make restart`

---

## 🎊 Congratulations!

You now have a complete, production-ready microservices platform with:

🔹 **8 Microservices** - All connected via gRPC
🔹 **6 Infrastructure Services** - Production-grade setup
🔹 **Real-time Monitoring** - Comprehensive dashboards
🔹 **Automated Deployment** - One-command production deploy
🔹 **Complete Testing** - Integration and load testing
🔹 **Developer Tools** - 40+ automation commands

**Ready to build the future of team collaboration! 🚀**

---

*For detailed information, see [DEPLOYMENT.md](./DEPLOYMENT.md) and [README.md](./README.md)*
