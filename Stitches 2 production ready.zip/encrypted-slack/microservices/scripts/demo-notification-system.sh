#!/bin/bash

# Stitches Microservices - Notification System Demonstration
# Interactive demo showcasing the complete notification system

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Configuration
DEMO_MODE="interactive"
PAUSE_DURATION=2

# Functions
log() {
    echo -e "${GREEN}[$(date +'%H:%M:%S')] $1${NC}"
}

info() {
    echo -e "${BLUE}[$(date +'%H:%M:%S')] $1${NC}"
}

demo() {
    echo -e "${PURPLE}[DEMO] $1${NC}"
}

success() {
    echo -e "${CYAN}✅ $1${NC}"
}

pause_demo() {
    if [[ "$DEMO_MODE" == "interactive" ]]; then
        echo ""
        read -p "Press Enter to continue..."
    else
        sleep "$PAUSE_DURATION"
    fi
}

# Banner
clear
echo -e "${BLUE}"
cat << 'EOF'
 ____  _   _ _       _
/ ___|| |_(_) |_ ___| |__   ___  ___
\___ \| __| | __/ __| '_ \ / _ \/ __|
 ___) | |_| | || (__| | | |  __/\__ \
|____/ \__|_|\__\___|_| |_|\___||___/

🎭 NOTIFICATION SYSTEM DEMONSTRATION
=====================================
Complete showcase of email, SMS, and alert delivery testing
EOF
echo -e "${NC}"

# Introduction
demo_introduction() {
    demo "Welcome to the Stitches Notification System Demonstration!"
    echo ""
    echo "This demo will showcase:"
    echo "📧 Email notification system with multiple providers"
    echo "📱 SMS notification system with 5 provider options"
    echo "🧪 Comprehensive alert delivery testing"
    echo "🔍 Real-time monitoring and health checks"
    echo "🛠️ Easy management with 25+ automation commands"
    echo ""
    pause_demo
}

# Demo notification features
demo_features() {
    demo "🚀 NOTIFICATION SYSTEM FEATURES"
    echo ""

    echo -e "${WHITE}📧 Email Notifications:${NC}"
    echo "  • Multi-provider support: Gmail, Outlook, SendGrid, AWS SES"
    echo "  • Beautiful HTML templates with rich formatting"
    echo "  • Automatic testing and validation"
    echo "  • SMTP health checks"
    echo ""

    echo -e "${WHITE}📱 SMS Notifications:${NC}"
    echo "  • 5 provider options: Twilio, AWS SNS, Nexmo, TextMagic, Custom"
    echo "  • Webhook server for Grafana integration"
    echo "  • Smart message formatting for SMS limits"
    echo "  • Multi-recipient delivery"
    echo ""

    echo -e "${WHITE}🧪 Alert Delivery Testing:${NC}"
    echo "  • Comprehensive testing of all channels"
    echo "  • Basic, comprehensive, and stress test modes"
    echo "  • Automatic channel discovery"
    echo "  • Detailed reporting with recommendations"
    echo ""

    pause_demo
}

# Demo configuration
demo_configuration() {
    demo "🔧 CONFIGURATION DEMONSTRATION"
    echo ""

    info "Checking current notification configurations..."
    echo ""

    # Check email configuration
    echo -e "${WHITE}📧 Email Configuration:${NC}"
    if grep -q "EMAIL_SMTP_HOST" .env 2>/dev/null; then
        success "Email SMTP configured"
        grep "EMAIL_SMTP_HOST\|EMAIL_FROM" .env | sed 's/^/  /'
    else
        echo "  ❌ Email not configured"
        echo "  💡 Run: make setup-email-notifications"
    fi
    echo ""

    # Check SMS configuration
    echo -e "${WHITE}📱 SMS Configuration:${NC}"
    if grep -q "SMS_PROVIDER" .env 2>/dev/null; then
        success "SMS provider configured"
        grep "SMS_PROVIDER" .env | sed 's/^/  /'
    else
        echo "  ❌ SMS not configured"
        echo "  💡 Run: make setup-sms-notifications"
    fi
    echo ""

    # Check Slack configuration
    echo -e "${WHITE}💬 Slack Configuration:${NC}"
    if grep -q "SLACK_WEBHOOK_URL" .env 2>/dev/null; then
        success "Slack webhook configured"
    else
        echo "  ❌ Slack webhook not configured"
        echo "  💡 Add SLACK_WEBHOOK_URL to .env file"
    fi
    echo ""

    pause_demo
}

# Demo testing capabilities
demo_testing() {
    demo "🧪 TESTING CAPABILITIES DEMONSTRATION"
    echo ""

    info "Available testing commands:"
    echo ""

    echo -e "${WHITE}Individual Channel Testing:${NC}"
    echo "  make test-email-alerts     # Test email delivery"
    echo "  make test-sms-alerts      # Test SMS delivery"
    echo "  make test-slack-alerts    # Test Slack delivery"
    echo ""

    echo -e "${WHITE}Comprehensive Testing:${NC}"
    echo "  make test-all-alerts                     # Test all channels"
    echo "  make test-alert-delivery-comprehensive   # Full test suite"
    echo "  make test-alert-delivery-stress         # Stress testing"
    echo ""

    echo -e "${WHITE}Live Testing Demonstration:${NC}"

    # Test Slack if configured
    if grep -q "SLACK_WEBHOOK_URL" .env 2>/dev/null; then
        info "Testing Slack notification..."

        local slack_url=$(grep "SLACK_WEBHOOK_URL" .env | cut -d'=' -f2- | tr -d '"')
        local test_payload='{"text":"🎭 DEMO: Stitches Notification System","attachments":[{"color":"good","fields":[{"title":"Demo Status","value":"Testing Slack Integration","short":true},{"title":"System","value":"Stitches Microservices","short":true}],"footer":"Notification System Demo"}]}'

        if curl -s -X POST -H "Content-Type: application/json" -d "$test_payload" "$slack_url" | grep -q "ok"; then
            success "Slack test message sent!"
            echo "  📱 Check your Slack channel for the demo message"
        else
            echo "  ❌ Slack test failed"
        fi
    else
        echo "  ⏭️ Slack not configured - skipping test"
    fi
    echo ""

    pause_demo
}

# Demo email templates
demo_email_templates() {
    demo "📧 EMAIL TEMPLATE DEMONSTRATION"
    echo ""

    info "Email templates showcase beautiful, professional alert notifications"
    echo ""

    if [[ -d "email-templates" ]]; then
        echo -e "${WHITE}Available Email Templates:${NC}"
        ls email-templates/ | sed 's/^/  📄 /'
        echo ""

        echo -e "${WHITE}Critical Alert Template Preview:${NC}"
        if [[ -f "email-templates/critical-alert-example.html" ]]; then
            echo "  🚨 Subject: [CRITICAL] Service Down - Auth Service"
            echo "  📧 Rich HTML formatting with:"
            echo "     • Color-coded severity indicators"
            echo "     • Structured alert information"
            echo "     • Quick action links"
            echo "     • Troubleshooting commands"
            echo "     • Professional branding"
        fi
        echo ""

        echo -e "${WHITE}Warning Alert Template Preview:${NC}"
        if [[ -f "email-templates/warning-alert-example.html" ]]; then
            echo "  ⚠️ Subject: [WARNING] High Response Time (P95)"
            echo "  📧 Includes:"
            echo "     • Performance metrics"
            echo "     • Investigation links"
            echo "     • Impact assessment"
            echo "     • Escalation procedures"
        fi
    else
        echo "  💡 Email templates will be created when you run:"
        echo "     make setup-email-notifications"
    fi
    echo ""

    pause_demo
}

# Demo SMS system
demo_sms_system() {
    demo "📱 SMS NOTIFICATION SYSTEM"
    echo ""

    echo -e "${WHITE}Supported SMS Providers:${NC}"
    echo "  🔹 Twilio           - Most popular, reliable global delivery"
    echo "  🔹 AWS SNS          - Amazon's SMS service, pay-per-message"
    echo "  🔹 Nexmo/Vonage     - Enterprise messaging platform"
    echo "  🔹 TextMagic        - Business SMS service"
    echo "  🔹 Custom Webhook   - Any HTTP endpoint for SMS delivery"
    echo ""

    echo -e "${WHITE}SMS Features:${NC}"
    echo "  📝 Smart message formatting (SMS character limit optimized)"
    echo "  📞 Multi-recipient delivery"
    echo "  🔗 Webhook server for Grafana integration"
    echo "  ⚡ Real-time delivery tracking"
    echo "  🛡️ Error handling and retry mechanisms"
    echo ""

    if [[ -d "scripts/sms-webhooks" ]]; then
        echo -e "${WHITE}SMS Webhook Scripts:${NC}"
        ls scripts/sms-webhooks/*.py | sed 's/.*\//  📄 /' | sed 's/\.py$//'
        echo ""

        # Check if SMS webhook server is available
        if [[ -f "scripts/sms-webhooks/sms-webhook-server.py" ]]; then
            echo -e "${WHITE}SMS Webhook Server:${NC}"
            echo "  🚀 HTTP server: http://localhost:8081"
            echo "  🏥 Health check: http://localhost:8081/health"
            echo "  📨 Webhook endpoint: POST /"

            # Test if server is running
            if curl -f -s "http://localhost:8081/health" >/dev/null 2>&1; then
                success "SMS webhook server is running!"
            else
                echo "  💡 Start with: make start-sms-webhook-server"
            fi
        fi
    fi
    echo ""

    pause_demo
}

# Demo management commands
demo_management() {
    demo "🛠️ MANAGEMENT & AUTOMATION"
    echo ""

    echo -e "${WHITE}Setup Commands (25+ available):${NC}"
    echo "  make setup-email-notifications      # Interactive email setup"
    echo "  make setup-sms-notifications       # Interactive SMS setup"
    echo "  make setup-all-notifications       # Setup all channels"
    echo ""

    echo -e "${WHITE}Testing Commands:${NC}"
    echo "  make test-all-alerts               # Test all channels"
    echo "  make test-alert-delivery-comprehensive  # Full test suite"
    echo "  make test-alert-delivery-stress    # Stress testing"
    echo ""

    echo -e "${WHITE}Monitoring Commands:${NC}"
    echo "  make validate-notification-config  # Check configurations"
    echo "  make notification-health-check     # Service health status"
    echo "  make notification-delivery-monitor # Monitor delivery rates"
    echo ""

    echo -e "${WHITE}Interactive Guides:${NC}"
    echo "  make notification-setup-guide      # Step-by-step setup guide"
    echo "  make help                          # All available commands"
    echo ""

    pause_demo
}

# Demo live monitoring
demo_monitoring() {
    demo "🔍 LIVE MONITORING DEMONSTRATION"
    echo ""

    info "Running live notification health check..."
    echo ""

    # Email health check
    echo -e "${WHITE}📧 Email Service Health:${NC}"
    if grep -q "EMAIL_SMTP_HOST" .env 2>/dev/null; then
        local smtp_host=$(grep "EMAIL_SMTP_HOST" .env | cut -d'=' -f2)
        echo -n "  SMTP Connection ($smtp_host): "
        if python3 -c "
import socket
try:
    socket.create_connection(('$smtp_host', 587), timeout=5)
    print('✅ Reachable')
except:
    print('❌ Unreachable')
" 2>/dev/null; then
            echo ""
        fi
    else
        echo "  ❌ Not configured"
    fi

    # SMS health check
    echo -e "${WHITE}📱 SMS Service Health:${NC}"
    echo -n "  SMS Webhook Server: "
    if curl -f -s "http://localhost:8081/health" >/dev/null 2>&1; then
        echo "✅ Running"
    else
        echo "❌ Not running"
    fi

    # Grafana health check
    echo -e "${WHITE}📊 Monitoring System Health:${NC}"
    echo -n "  Grafana: "
    if curl -f -s "http://localhost:3001/api/health" >/dev/null 2>&1; then
        echo "✅ Running"
    else
        echo "❌ Not running"
    fi

    echo -n "  Prometheus: "
    if curl -f -s "http://localhost:9090/-/healthy" >/dev/null 2>&1; then
        echo "✅ Running"
    else
        echo "❌ Not running"
    fi
    echo ""

    pause_demo
}

# Demo comprehensive testing
demo_comprehensive_testing() {
    demo "🧪 COMPREHENSIVE TESTING DEMONSTRATION"
    echo ""

    info "Showcasing the alert delivery testing suite..."
    echo ""

    echo -e "${WHITE}Test Modes Available:${NC}"
    echo "  🔸 Basic Mode      - Quick validation of core functionality"
    echo "  🔸 Comprehensive   - Full testing with multiple alert types"
    echo "  🔸 Stress Mode     - High-volume concurrent delivery testing"
    echo ""

    echo -e "${WHITE}Test Coverage:${NC}"
    echo "  📧 Email delivery testing (SMTP, authentication, formatting)"
    echo "  📱 SMS delivery testing (provider APIs, webhook integration)"
    echo "  💬 Slack integration testing (webhook, message formatting)"
    echo "  🔗 Webhook testing (external monitoring systems)"
    echo "  📊 Multi-channel simultaneous testing"
    echo ""

    echo -e "${WHITE}Test Reports:${NC}"
    echo "  📄 Detailed Markdown reports with pass/fail status"
    echo "  📈 Performance metrics and response times"
    echo "  💡 Specific recommendations for failed configurations"
    echo "  🏥 Real-time service health monitoring"
    echo ""

    # Show example test report if available
    if ls alert-delivery-test-report-*.md >/dev/null 2>&1; then
        echo -e "${WHITE}Recent Test Reports:${NC}"
        ls -t alert-delivery-test-report-*.md | head -3 | sed 's/^/  📄 /'
        echo ""
    fi

    pause_demo
}

# Demo production readiness
demo_production_readiness() {
    demo "🚀 PRODUCTION READINESS"
    echo ""

    echo -e "${WHITE}Enterprise-Grade Features:${NC}"
    echo "  ✅ Multi-provider support for reliability"
    echo "  ✅ Interactive setup wizards"
    echo "  ✅ Production-ready templates and configurations"
    echo "  ✅ Automated testing and validation"
    echo "  ✅ Error handling and recovery mechanisms"
    echo "  ✅ Detailed reporting and analytics"
    echo ""

    echo -e "${WHITE}Security & Reliability:${NC}"
    echo "  🔐 Secure credential management"
    echo "  🔄 Automatic retry mechanisms"
    echo "  📊 Delivery rate monitoring"
    echo "  🛡️ Error handling and logging"
    echo "  ⚡ Performance optimization"
    echo ""

    echo -e "${WHITE}Scalability:${NC}"
    echo "  📈 High-volume message delivery"
    echo "  🔀 Load balancing across providers"
    echo "  📱 Multi-channel redundancy"
    echo "  🎯 Smart routing and escalation"
    echo ""

    pause_demo
}

# Demo next steps
demo_next_steps() {
    demo "📋 NEXT STEPS & GETTING STARTED"
    echo ""

    echo -e "${WHITE}Quick Start (5 minutes):${NC}"
    echo "  1. Configure email notifications:"
    echo "     make setup-email-notifications"
    echo ""
    echo "  2. Test email delivery:"
    echo "     make test-email-alerts"
    echo ""
    echo "  3. Configure SMS notifications:"
    echo "     make setup-sms-notifications"
    echo ""
    echo "  4. Start SMS webhook server:"
    echo "     make start-sms-webhook-server"
    echo ""
    echo "  5. Test all channels:"
    echo "     make test-all-alerts"
    echo ""

    echo -e "${WHITE}Advanced Setup:${NC}"
    echo "  • Add Slack webhook URL to .env file"
    echo "  • Configure Teams/Discord webhooks"
    echo "  • Set up PagerDuty integration"
    echo "  • Run comprehensive testing"
    echo "  • Set up monitoring and alerting"
    echo ""

    echo -e "${WHITE}Documentation & Support:${NC}"
    echo "  📚 Setup Guide: make notification-setup-guide"
    echo "  🔍 Health Check: make notification-health-check"
    echo "  📊 Monitoring: make notification-delivery-monitor"
    echo "  🆘 Help: make help"
    echo ""

    pause_demo
}

# Interactive menu
show_menu() {
    echo ""
    echo -e "${WHITE}🎭 NOTIFICATION SYSTEM DEMO MENU${NC}"
    echo -e "${BLUE}=================================${NC}"
    echo ""
    echo "1. 🚀 System Features Overview"
    echo "2. 🔧 Configuration Status"
    echo "3. 🧪 Testing Capabilities"
    echo "4. 📧 Email Templates Showcase"
    echo "5. 📱 SMS System Demo"
    echo "6. 🛠️ Management Commands"
    echo "7. 🔍 Live Monitoring"
    echo "8. 🧪 Comprehensive Testing"
    echo "9. 🚀 Production Readiness"
    echo "10. 📋 Next Steps & Getting Started"
    echo "11. 🎬 Full Demo (All Sections)"
    echo "0. ❌ Exit"
    echo ""
}

# Main interactive mode
interactive_demo() {
    while true; do
        show_menu
        read -p "Select an option (0-11): " choice

        case $choice in
            1) demo_features ;;
            2) demo_configuration ;;
            3) demo_testing ;;
            4) demo_email_templates ;;
            5) demo_sms_system ;;
            6) demo_management ;;
            7) demo_monitoring ;;
            8) demo_comprehensive_testing ;;
            9) demo_production_readiness ;;
            10) demo_next_steps ;;
            11)
                demo_introduction
                demo_features
                demo_configuration
                demo_testing
                demo_email_templates
                demo_sms_system
                demo_management
                demo_monitoring
                demo_comprehensive_testing
                demo_production_readiness
                demo_next_steps
                ;;
            0)
                echo ""
                demo "Thank you for exploring the Stitches Notification System!"
                echo ""
                echo "🚀 Ready to get started? Run: make notification-setup-guide"
                echo ""
                exit 0
                ;;
            *)
                echo ""
                echo "❌ Invalid option. Please select 0-11."
                ;;
        esac
    done
}

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --auto)
            DEMO_MODE="auto"
            shift
            ;;
        --quick)
            PAUSE_DURATION=1
            shift
            ;;
        --help)
            echo "Usage: $0 [OPTIONS]"
            echo "Options:"
            echo "  --auto    Run demo automatically without pauses"
            echo "  --quick   Use shorter pauses in auto mode"
            echo "  --help    Show this help"
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Main execution
main() {
    demo_introduction

    if [[ "$DEMO_MODE" == "interactive" ]]; then
        interactive_demo
    else
        # Auto demo mode
        demo_features
        demo_configuration
        demo_testing
        demo_email_templates
        demo_sms_system
        demo_management
        demo_monitoring
        demo_comprehensive_testing
        demo_production_readiness
        demo_next_steps

        echo ""
        demo "🎉 Demonstration complete!"
        echo ""
        echo "🚀 Ready to get started? Run: make notification-setup-guide"
        echo ""
    fi
}

# Run the demo
main "$@"
