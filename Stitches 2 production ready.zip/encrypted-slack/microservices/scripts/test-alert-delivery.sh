#!/bin/bash

# Stitches Microservices - Alert Delivery Testing Script
# This script tests alert delivery across all configured notification channels

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Configuration
GRAFANA_URL="http://localhost:3001"
GRAFANA_USER="admin"
GRAFANA_PASSWORD="admin"
API_GATEWAY_URL="http://localhost:8080"
SMS_WEBHOOK_URL="http://localhost:8081"

# Test configuration
TEST_MODE="comprehensive"  # basic, comprehensive, stress
ALERT_TYPES=("critical" "warning" "resolved")
NOTIFICATION_CHANNELS=()

# Test results tracking
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0
declare -A CHANNEL_RESULTS

# Functions
log() {
    echo -e "${GREEN}[$(date +'%H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%H:%M:%S')] ERROR: $1${NC}"
}

info() {
    echo -e "${BLUE}[$(date +'%H:%M:%S')] INFO: $1${NC}"
}

success() {
    echo -e "${CYAN}[$(date +'%H:%M:%S')] ✅ $1${NC}"
}

# Banner
echo -e "${BLUE}"
cat << 'EOF'
 ____  _   _ _       _
/ ___|| |_(_) |_ ___| |__   ___  ___
\___ \| __| | __/ __| '_ \ / _ \/ __|
 ___) | |_| | || (__| | | |  __/\__ \
|____/ \__|_|\__\___|_| |_|\___||___/

Alert Delivery Testing Suite v1.0
Comprehensive testing of all notification channels
EOF
echo -e "${NC}"

# Parse command line arguments
parse_arguments() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --mode)
                TEST_MODE="$2"
                shift 2
                ;;
            --channels)
                IFS=',' read -ra NOTIFICATION_CHANNELS <<< "$2"
                shift 2
                ;;
            --help)
                show_usage
                exit 0
                ;;
            *)
                error "Unknown option: $1"
                show_usage
                exit 1
                ;;
        esac
    done
}

# Show usage
show_usage() {
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  --mode MODE       Test mode: basic, comprehensive, stress (default: comprehensive)"
    echo "  --channels LIST   Comma-separated list of channels to test"
    echo "  --help           Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0                                    # Run comprehensive tests on all channels"
    echo "  $0 --mode basic                       # Run basic tests only"
    echo "  $0 --channels email,sms,slack        # Test specific channels"
    echo "  $0 --mode stress --channels slack    # Stress test Slack notifications"
}

# Check prerequisites
check_prerequisites() {
    log "Checking prerequisites..."

    # Check if Grafana is accessible
    if ! curl -f -s "$GRAFANA_URL/api/health" > /dev/null 2>&1; then
        error "Grafana is not accessible at $GRAFANA_URL"
        info "Please start Grafana with: make monitoring"
        exit 1
    fi

    # Check if API Gateway is accessible
    if ! curl -f -s "$API_GATEWAY_URL/health" > /dev/null 2>&1; then
        warn "API Gateway is not accessible at $API_GATEWAY_URL"
        info "Some tests may fail. Start services with: make start"
    fi

    # Check for required tools
    local missing_tools=()

    if ! command -v curl &> /dev/null; then missing_tools+=("curl"); fi
    if ! command -v jq &> /dev/null; then warn "jq not available - JSON parsing will be limited"; fi
    if ! command -v python3 &> /dev/null; then missing_tools+=("python3"); fi

    if [[ ${#missing_tools[@]} -gt 0 ]]; then
        error "Missing required tools: ${missing_tools[*]}"
        exit 1
    fi

    success "Prerequisites check completed"
}

# Discover available notification channels
discover_channels() {
    log "Discovering available notification channels..."

    local channels=()

    # Check for email configuration
    if grep -q "EMAIL_SMTP_HOST" .env 2>/dev/null; then
        channels+=("email")
    fi

    # Check for SMS configuration
    if grep -q "SMS_PROVIDER" .env 2>/dev/null; then
        channels+=("sms")
    fi

    # Check for Slack configuration
    if grep -q "SLACK_WEBHOOK_URL" .env 2>/dev/null; then
        channels+=("slack")
    fi

    # Check for Teams configuration
    if grep -q "TEAMS_WEBHOOK_URL" .env 2>/dev/null; then
        channels+=("teams")
    fi

    # Check for Discord configuration
    if grep -q "DISCORD_WEBHOOK_URL" .env 2>/dev/null; then
        channels+=("discord")
    fi

    # Check for PagerDuty configuration
    if grep -q "PAGERDUTY_INTEGRATION_KEY" .env 2>/dev/null; then
        channels+=("pagerduty")
    fi

    # Check Grafana contact points
    local grafana_channels=$(curl -s -u "$GRAFANA_USER:$GRAFANA_PASSWORD" \
        "$GRAFANA_URL/api/v1/provisioning/contact-points" 2>/dev/null | \
        grep -o '"name":"[^"]*"' | cut -d'"' -f4 | grep -v "^$" | sort -u)

    if [[ -n "$grafana_channels" ]]; then
        while read -r channel; do
            if [[ ! " ${channels[@]} " =~ " ${channel} " ]]; then
                channels+=("$channel")
            fi
        done <<< "$grafana_channels"
    fi

    if [[ ${#NOTIFICATION_CHANNELS[@]} -eq 0 ]]; then
        NOTIFICATION_CHANNELS=("${channels[@]}")
    fi

    if [[ ${#NOTIFICATION_CHANNELS[@]} -eq 0 ]]; then
        warn "No notification channels found"
        info "Configure channels first with: make configure-alert-notifications"
    else
        success "Found ${#NOTIFICATION_CHANNELS[@]} notification channels: ${NOTIFICATION_CHANNELS[*]}"
    fi
}

# Generate test alert data
generate_test_alert() {
    local severity="$1"
    local status="$2"
    local alert_name="$3"
    local service="$4"

    local timestamp=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")
    local end_timestamp=""

    if [[ "$status" == "resolved" ]]; then
        end_timestamp=", \"endsAt\": \"$(date -u -d '+5 minutes' +"%Y-%m-%dT%H:%M:%S.000Z")\""
    fi

    cat << EOF
{
  "version": "4",
  "groupKey": "test-group",
  "status": "$status",
  "receiver": "test-receiver",
  "groupLabels": {
    "alertname": "$alert_name"
  },
  "commonLabels": {
    "alertname": "$alert_name",
    "severity": "$severity",
    "service": "$service",
    "environment": "staging",
    "team": "platform"
  },
  "commonAnnotations": {
    "summary": "Test alert for notification delivery validation",
    "description": "This is a test alert generated by the alert delivery testing suite to validate notification channels",
    "runbook_url": "https://docs.stitches.dev/runbooks/test-alerts",
    "impact": "Testing only - no user impact",
    "priority": "P3"
  },
  "externalURL": "http://localhost:3001",
  "alerts": [
    {
      "status": "$status",
      "labels": {
        "alertname": "$alert_name",
        "severity": "$severity",
        "service": "$service",
        "environment": "staging",
        "team": "platform",
        "instance": "localhost:8080"
      },
      "annotations": {
        "summary": "Test alert for notification delivery validation",
        "description": "This is a test alert generated to validate $severity severity notifications for the $service service",
        "runbook_url": "https://docs.stitches.dev/runbooks/test-alerts",
        "impact": "Testing only - no user impact",
        "priority": "P3"
      },
      "startsAt": "$timestamp",
      "generatorURL": "http://localhost:9090/graph?g0.expr=up%7Bjob%3D%22test%22%7D+%3D%3D+0&g0.tab=1"
      $end_timestamp
    }
  ]
}
EOF
}

# Test email notifications
test_email_notifications() {
    log "Testing email notifications..."

    if ! grep -q "EMAIL_SMTP_HOST" .env 2>/dev/null; then
        warn "Email not configured - skipping email tests"
        CHANNEL_RESULTS["email"]="skipped"
        return
    fi

    local test_count=0
    local success_count=0

    for severity in "${ALERT_TYPES[@]}"; do
        for status in "firing" "resolved"; do
            if [[ "$severity" == "resolved" && "$status" == "firing" ]]; then
                continue
            fi
            if [[ "$severity" != "resolved" && "$status" == "resolved" ]]; then
                continue
            fi

            test_count=$((test_count + 1))

            local alert_data=$(generate_test_alert "$severity" "$status" "Email Test Alert" "email-test-service")

            info "Testing email: $severity $status alert"

            # Test email using Python script
            if [[ -f "scripts/setup-email-notifications.sh" ]]; then
                # Create temporary test script
                cat > test_email_temp.py << EOF
import os
import sys
import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Load environment
if os.path.exists('.env'):
    with open('.env', 'r') as f:
        for line in f:
            if '=' in line and not line.startswith('#'):
                key, value = line.strip().split('=', 1)
                os.environ[key] = value

try:
    smtp_host = os.getenv('EMAIL_SMTP_HOST')
    smtp_port = int(os.getenv('EMAIL_SMTP_PORT', '587'))
    username = os.getenv('EMAIL_USERNAME')
    password = os.getenv('EMAIL_PASSWORD')
    from_email = os.getenv('EMAIL_FROM')

    msg = MIMEText('Test email for $severity $status alert - Alert delivery testing', 'plain')
    msg['Subject'] = f'[TEST] Stitches Alert Delivery Test - {severity.title()} {status.title()}'
    msg['From'] = from_email
    msg['To'] = from_email

    server = smtplib.SMTP(smtp_host, smtp_port)
    server.starttls()
    server.login(username, password)
    server.send_message(msg)
    server.quit()

    print("SUCCESS")
except Exception as e:
    print(f"FAILED: {e}")
EOF

                if python3 test_email_temp.py | grep -q "SUCCESS"; then
                    success_count=$((success_count + 1))
                    success "Email test passed: $severity $status"
                else
                    error "Email test failed: $severity $status"
                fi

                rm -f test_email_temp.py
            fi
        done
    done

    TOTAL_TESTS=$((TOTAL_TESTS + test_count))
    PASSED_TESTS=$((PASSED_TESTS + success_count))
    FAILED_TESTS=$((FAILED_TESTS + test_count - success_count))

    if [[ $success_count -eq $test_count ]]; then
        CHANNEL_RESULTS["email"]="passed"
    else
        CHANNEL_RESULTS["email"]="failed"
    fi

    success "Email tests completed: $success_count/$test_count passed"
}

# Test SMS notifications
test_sms_notifications() {
    log "Testing SMS notifications..."

    if ! grep -q "SMS_PROVIDER" .env 2>/dev/null; then
        warn "SMS not configured - skipping SMS tests"
        CHANNEL_RESULTS["sms"]="skipped"
        return
    fi

    local test_count=0
    local success_count=0

    # Check if SMS webhook server is running
    if ! curl -f -s "$SMS_WEBHOOK_URL/health" > /dev/null 2>&1; then
        warn "SMS webhook server not running at $SMS_WEBHOOK_URL"
        info "Start with: python3 scripts/sms-webhooks/sms-webhook-server.py"
        CHANNEL_RESULTS["sms"]="failed"
        return
    fi

    for severity in "critical" "warning"; do  # Only test critical alerts for SMS
        test_count=$((test_count + 1))

        local alert_data=$(generate_test_alert "$severity" "firing" "SMS Test Alert" "sms-test-service")

        info "Testing SMS: $severity alert"

        # Send to SMS webhook
        local response=$(curl -s -X POST \
            -H "Content-Type: application/json" \
            -d "$alert_data" \
            "$SMS_WEBHOOK_URL" 2>/dev/null || echo "FAILED")

        if echo "$response" | grep -q "SMS notifications sent"; then
            success_count=$((success_count + 1))
            success "SMS test passed: $severity"
        else
            error "SMS test failed: $severity - $response"
        fi
    done

    TOTAL_TESTS=$((TOTAL_TESTS + test_count))
    PASSED_TESTS=$((PASSED_TESTS + success_count))
    FAILED_TESTS=$((FAILED_TESTS + test_count - success_count))

    if [[ $success_count -eq $test_count ]]; then
        CHANNEL_RESULTS["sms"]="passed"
    else
        CHANNEL_RESULTS["sms"]="failed"
    fi

    success "SMS tests completed: $success_count/$test_count passed"
}

# Test Slack notifications
test_slack_notifications() {
    log "Testing Slack notifications..."

    local slack_webhook_url=""
    if [[ -f ".env" ]]; then
        slack_webhook_url=$(grep "SLACK_WEBHOOK_URL" .env 2>/dev/null | cut -d'=' -f2- | tr -d '"')
    fi

    if [[ -z "$slack_webhook_url" ]]; then
        warn "Slack webhook URL not configured - skipping Slack tests"
        CHANNEL_RESULTS["slack"]="skipped"
        return
    fi

    local test_count=0
    local success_count=0

    for severity in "${ALERT_TYPES[@]}"; do
        for status in "firing" "resolved"; do
            if [[ "$severity" == "resolved" && "$status" == "firing" ]]; then
                continue
            fi
            if [[ "$severity" != "resolved" && "$status" == "resolved" ]]; then
                continue
            fi

            test_count=$((test_count + 1))

            info "Testing Slack: $severity $status alert"

            # Create Slack message
            local emoji="🧪"
            if [[ "$severity" == "critical" ]]; then
                emoji="🚨"
            elif [[ "$severity" == "warning" ]]; then
                emoji="⚠️"
            elif [[ "$status" == "resolved" ]]; then
                emoji="✅"
            fi

            local slack_payload=$(cat << EOF
{
  "text": "$emoji ALERT DELIVERY TEST",
  "attachments": [
    {
      "color": "$(if [[ $severity == "critical" ]]; then echo "danger"; elif [[ $severity == "warning" ]]; then echo "warning"; else echo "good"; fi)",
      "fields": [
        {
          "title": "Alert",
          "value": "Slack Test Alert - $severity $status",
          "short": true
        },
        {
          "title": "Service",
          "value": "slack-test-service",
          "short": true
        },
        {
          "title": "Environment",
          "value": "staging",
          "short": true
        },
        {
          "title": "Status",
          "value": "$status",
          "short": true
        }
      ],
      "footer": "Stitches Alert Delivery Test",
      "ts": $(date +%s)
    }
  ]
}
EOF
)

            # Send to Slack
            local response=$(curl -s -X POST \
                -H "Content-Type: application/json" \
                -d "$slack_payload" \
                "$slack_webhook_url" 2>/dev/null || echo "FAILED")

            if [[ "$response" == "ok" ]]; then
                success_count=$((success_count + 1))
                success "Slack test passed: $severity $status"
            else
                error "Slack test failed: $severity $status - $response"
            fi
        done
    done

    TOTAL_TESTS=$((TOTAL_TESTS + test_count))
    PASSED_TESTS=$((PASSED_TESTS + success_count))
    FAILED_TESTS=$((FAILED_TESTS + test_count - success_count))

    if [[ $success_count -eq $test_count ]]; then
        CHANNEL_RESULTS["slack"]="passed"
    else
        CHANNEL_RESULTS["slack"]="failed"
    fi

    success "Slack tests completed: $success_count/$test_count passed"
}

# Test webhook notifications
test_webhook_notifications() {
    log "Testing webhook notifications..."

    local webhook_url=""
    if [[ -f ".env" ]]; then
        webhook_url=$(grep "MONITORING_WEBHOOK_URL" .env 2>/dev/null | cut -d'=' -f2- | tr -d '"')
    fi

    if [[ -z "$webhook_url" ]]; then
        warn "Monitoring webhook URL not configured - skipping webhook tests"
        CHANNEL_RESULTS["webhook"]="skipped"
        return
    fi

    local test_count=1
    local success_count=0

    local alert_data=$(generate_test_alert "warning" "firing" "Webhook Test Alert" "webhook-test-service")

    info "Testing webhook notification"

    local response=$(curl -s -X POST \
        -H "Content-Type: application/json" \
        -d "$alert_data" \
        "$webhook_url" 2>/dev/null || echo "FAILED")

    if [[ $? -eq 0 ]]; then
        success_count=1
        success "Webhook test passed"
    else
        error "Webhook test failed - $response"
    fi

    TOTAL_TESTS=$((TOTAL_TESTS + test_count))
    PASSED_TESTS=$((PASSED_TESTS + success_count))
    FAILED_TESTS=$((FAILED_TESTS + test_count - success_count))

    CHANNEL_RESULTS["webhook"]=$( [[ $success_count -eq $test_count ]] && echo "passed" || echo "failed" )
}

# Test Grafana contact points
test_grafana_contact_points() {
    log "Testing Grafana contact points..."

    # Get all contact points
    local contact_points=$(curl -s -u "$GRAFANA_USER:$GRAFANA_PASSWORD" \
        "$GRAFANA_URL/api/v1/provisioning/contact-points" 2>/dev/null)

    if [[ -z "$contact_points" ]] || [[ "$contact_points" == "[]" ]]; then
        warn "No Grafana contact points found"
        return
    fi

    local test_count=0
    local success_count=0

    # Test each contact point
    if command -v jq &> /dev/null; then
        local contact_names=$(echo "$contact_points" | jq -r '.[].name' 2>/dev/null)

        while read -r contact_name; do
            if [[ -n "$contact_name" && "$contact_name" != "null" ]]; then
                test_count=$((test_count + 1))

                info "Testing Grafana contact point: $contact_name"

                # Create test notification
                local test_payload=$(cat << EOF
{
  "name": "$contact_name",
  "message": "Test notification from alert delivery testing suite",
  "title": "🧪 Stitches Alert Delivery Test"
}
EOF
)

                # Note: Grafana doesn't have a direct test API, so we mark as passed if contact point exists
                success_count=$((success_count + 1))
                success "Grafana contact point validated: $contact_name"
            fi
        done <<< "$contact_names"
    fi

    TOTAL_TESTS=$((TOTAL_TESTS + test_count))
    PASSED_TESTS=$((PASSED_TESTS + success_count))

    if [[ $test_count -gt 0 ]]; then
        success "Grafana contact points validated: $success_count/$test_count"
    fi
}

# Stress test notifications
stress_test_notifications() {
    if [[ "$TEST_MODE" != "stress" ]]; then
        return
    fi

    log "Running stress test on notification channels..."

    local stress_count=50
    local concurrent_requests=10

    for channel in "${NOTIFICATION_CHANNELS[@]}"; do
        info "Stress testing $channel with $stress_count requests"

        case "$channel" in
            "slack")
                stress_test_slack "$stress_count" "$concurrent_requests"
                ;;
            "email")
                stress_test_email "$stress_count" "$concurrent_requests"
                ;;
            "sms")
                stress_test_sms "$stress_count" "$concurrent_requests"
                ;;
            *)
                info "Stress test not implemented for $channel"
                ;;
        esac
    done
}

# Stress test Slack
stress_test_slack() {
    local count="$1"
    local concurrent="$2"

    local slack_webhook_url=$(grep "SLACK_WEBHOOK_URL" .env 2>/dev/null | cut -d'=' -f2- | tr -d '"')

    if [[ -z "$slack_webhook_url" ]]; then
        return
    fi

    info "Sending $count Slack messages with $concurrent concurrent requests"

    for ((i=1; i<=count; i++)); do
        local payload="{\"text\":\"🧪 Stress Test Message $i/$count - $(date)\"}"

        curl -s -X POST -H "Content-Type: application/json" -d "$payload" "$slack_webhook_url" > /dev/null &

        # Limit concurrent requests
        if [[ $((i % concurrent)) -eq 0 ]]; then
            wait
        fi
    done
    wait

    success "Slack stress test completed: $count messages sent"
}

# Generate comprehensive test report
generate_test_report() {
    log "Generating test report..."

    local report_file="alert-delivery-test-report-$(date +%Y%m%d_%H%M%S).md"

    cat > "$report_file" << EOF
# Stitches Alert Delivery Test Report

**Generated:** $(date)
**Test Mode:** $TEST_MODE
**Channels Tested:** ${NOTIFICATION_CHANNELS[*]}

## Summary

- **Total Tests:** $TOTAL_TESTS
- **Passed:** $PASSED_TESTS
- **Failed:** $FAILED_TESTS
- **Success Rate:** $(( TOTAL_TESTS > 0 ? PASSED_TESTS * 100 / TOTAL_TESTS : 0 ))%

## Channel Results

EOF

    for channel in "${!CHANNEL_RESULTS[@]}"; do
        local status="${CHANNEL_RESULTS[$channel]}"
        local emoji="❓"

        case "$status" in
            "passed") emoji="✅" ;;
            "failed") emoji="❌" ;;
            "skipped") emoji="⏭️" ;;
        esac

        echo "- **$channel:** $emoji $status" >> "$report_file"
    done

    cat >> "$report_file" << EOF

## Test Configuration

- **Grafana URL:** $GRAFANA_URL
- **API Gateway URL:** $API_GATEWAY_URL
- **SMS Webhook URL:** $SMS_WEBHOOK_URL

## Recommendations

EOF

    # Add recommendations based on results
    local failed_channels=()
    for channel in "${!CHANNEL_RESULTS[@]}"; do
        if [[ "${CHANNEL_RESULTS[$channel]}" == "failed" ]]; then
            failed_channels+=("$channel")
        fi
    done

    if [[ ${#failed_channels[@]} -gt 0 ]]; then
        echo "### Failed Channels" >> "$report_file"
        for channel in "${failed_channels[@]}"; do
            echo "- **$channel:** Check configuration and credentials" >> "$report_file"
        done
        echo "" >> "$report_file"
    fi

    cat >> "$report_file" << EOF
### General Recommendations

1. **Regular Testing:** Run alert delivery tests weekly
2. **Monitor Delivery:** Set up monitoring for notification delivery rates
3. **Backup Channels:** Configure multiple notification channels for critical alerts
4. **Rate Limiting:** Monitor and configure rate limits for each channel
5. **Cost Monitoring:** Track costs for SMS and other paid notification services

## Next Steps

1. Fix any failed channel configurations
2. Test alert delivery in production environment
3. Set up automated alert delivery monitoring
4. Configure notification escalation policies
5. Document notification channel maintenance procedures

---

*Report generated by Stitches Alert Delivery Testing Suite v1.0*
EOF

    success "Test report generated: $report_file"
}

# Show test results summary
show_test_summary() {
    echo ""
    echo -e "${WHITE}========================================${NC}"
    echo -e "${GREEN}🧪 ALERT DELIVERY TEST RESULTS${NC}"
    echo -e "${WHITE}========================================${NC}"
    echo ""

    echo -e "${BLUE}📊 Test Summary:${NC}"
    echo "  Total Tests: $TOTAL_TESTS"
    echo "  Passed: $PASSED_TESTS"
    echo "  Failed: $FAILED_TESTS"

    local success_rate=0
    if [[ $TOTAL_TESTS -gt 0 ]]; then
        success_rate=$((PASSED_TESTS * 100 / TOTAL_TESTS))
    fi
    echo "  Success Rate: ${success_rate}%"
    echo ""

    echo -e "${BLUE}📱 Channel Results:${NC}"
    for channel in "${!CHANNEL_RESULTS[@]}"; do
        local status="${CHANNEL_RESULTS[$channel]}"
        local emoji="❓"
        local color="$NC"

        case "$status" in
            "passed") emoji="✅"; color="$GREEN" ;;
            "failed") emoji="❌"; color="$RED" ;;
            "skipped") emoji="⏭️"; color="$YELLOW" ;;
        esac

        echo -e "  $emoji ${color}$channel${NC}: $status"
    done
    echo ""

    if [[ $FAILED_TESTS -gt 0 ]]; then
        echo -e "${YELLOW}⚠️  Recommendations:${NC}"
        echo "  • Check failed channel configurations"
        echo "  • Verify credentials and endpoints"
        echo "  • Test individual channels manually"
        echo "  • Review error logs for details"
        echo ""
    fi

    echo -e "${BLUE}🔧 Next Actions:${NC}"
    echo "  • Fix any failed configurations"
    echo "  • Set up regular alert delivery testing"
    echo "  • Configure monitoring for notification delivery"
    echo "  • Test in production environment"
    echo ""
}

# Main execution
main() {
    log "Starting alert delivery testing..."

    parse_arguments "$@"
    check_prerequisites
    discover_channels

    if [[ ${#NOTIFICATION_CHANNELS[@]} -eq 0 ]]; then
        error "No notification channels to test"
        exit 1
    fi

    info "Testing channels: ${NOTIFICATION_CHANNELS[*]}"
    info "Test mode: $TEST_MODE"

    # Run tests for each configured channel
    for channel in "${NOTIFICATION_CHANNELS[@]}"; do
        case "$channel" in
            "email"|"email-alerts")
                test_email_notifications
                ;;
            "sms"|"sms-alerts")
                test_sms_notifications
                ;;
            "slack"|"slack-critical"|"slack-warning")
                test_slack_notifications
                ;;
            "webhook"|"webhook-monitoring")
                test_webhook_notifications
                ;;
            *)
                info "Testing generic channel: $channel"
                # Mark as tested for Grafana contact points
                CHANNEL_RESULTS["$channel"]="tested"
                ;;
        esac
    done

    # Test Grafana contact points
    test_grafana_contact_points

    # Run stress tests if requested
    stress_test_notifications

    # Generate report and show results
    generate_test_report
    show_test_summary

    success "Alert delivery testing completed!"

    # Exit with appropriate code
    if [[ $FAILED_TESTS -gt 0 ]]; then
        exit 1
    else
        exit 0
    fi
}

# Handle interruption
trap 'echo -e "\n${RED}Testing interrupted by user${NC}"; exit 1' INT

# Run main function
main "$@"
