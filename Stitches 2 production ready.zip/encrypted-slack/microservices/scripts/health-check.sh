#!/bin/bash

# Stitches Microservices Health Check Script
# Usage: ./health-check.sh [--detailed] [--json] [--continuous] [--help]

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
DETAILED=false
JSON_OUTPUT=false
CONTINUOUS=false
TIMEOUT=10

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --detailed)
            DETAILED=true
            shift
            ;;
        --json)
            JSON_OUTPUT=true
            shift
            ;;
        --continuous)
            CONTINUOUS=true
            shift
            ;;
        --help)
            echo "Usage: $0 [OPTIONS]"
            echo "Options:"
            echo "  --detailed    Show detailed information about each service"
            echo "  --json        Output results in JSON format"
            echo "  --continuous  Run health checks continuously"
            echo "  --help        Show this help message"
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Functions
log() {
    if [[ "$JSON_OUTPUT" != true ]]; then
        echo -e "${GREEN}[$(date +'%H:%M:%S')] $1${NC}"
    fi
}

warn() {
    if [[ "$JSON_OUTPUT" != true ]]; then
        echo -e "${YELLOW}[$(date +'%H:%M:%S')] WARNING: $1${NC}"
    fi
}

error() {
    if [[ "$JSON_OUTPUT" != true ]]; then
        echo -e "${RED}[$(date +'%H:%M:%S')] ERROR: $1${NC}"
    fi
}

info() {
    if [[ "$JSON_OUTPUT" != true ]]; then
        echo -e "${BLUE}[$(date +'%H:%M:%S')] $1${NC}"
    fi
}

# Check HTTP service
check_http_service() {
    local name=$1
    local url=$2

    if command -v curl &> /dev/null; then
        if curl -f -s --max-time "$TIMEOUT" "$url" > /dev/null 2>&1; then
            echo "healthy"
        else
            echo "unhealthy"
        fi
    else
        echo "unknown"
    fi
}

# Check if files exist (simulated service check)
check_service_files() {
    local service=$1

    if [[ -f "${service}/main.go" && -f "${service}/Dockerfile" ]]; then
        echo "configured"
    else
        echo "missing"
    fi
}

# Perform health check
perform_health_check() {
    local timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    local overall_status="healthy"
    local total_services=0
    local healthy_services=0

    # Check application services
    local services=("auth-service" "chat-service" "notification-service" "project-service" "video-service" "assistant-service" "file-service" "api-gateway")

    if [[ "$JSON_OUTPUT" == true ]]; then
        echo "{"
        echo "  \"timestamp\": \"$timestamp\","
        echo "  \"services\": {"
    else
        echo -e "\n${BLUE}=== Stitches Microservices Health Check ===${NC}"
        echo "Timestamp: $timestamp"
        echo ""
        echo -e "${BLUE}Application Services:${NC}"
    fi

    local first=true
    for service in "${services[@]}"; do
        total_services=$((total_services + 1))
        local status=$(check_service_files "$service")

        if [[ "$status" == "configured" ]]; then
            healthy_services=$((healthy_services + 1))
        fi

        if [[ "$JSON_OUTPUT" == true ]]; then
            if [[ "$first" != true ]]; then
                echo ","
            fi
            first=false
            echo -n "    \"$service\": {\"status\": \"$status\", \"type\": \"microservice\"}"
        else
            local status_color=""
            case "$status" in
                "configured") status_color="${GREEN}" ;;
                "missing") status_color="${RED}" ;;
                *) status_color="${NC}" ;;
            esac
            printf "  %-20s %s%-12s%s" "$service" "$status_color" "$status" "$NC"
            echo ""
        fi
    done

    # Check configuration files
    local config_files=("docker-compose.yml" ".env" "Makefile")

    if [[ "$JSON_OUTPUT" != true ]]; then
        echo ""
        echo -e "${BLUE}Configuration Files:${NC}"
    fi

    for file in "${config_files[@]}"; do
        total_services=$((total_services + 1))

        if [[ -f "$file" ]]; then
            local status="present"
            healthy_services=$((healthy_services + 1))
        else
            local status="missing"
            overall_status="degraded"
        fi

        if [[ "$JSON_OUTPUT" == true ]]; then
            echo ","
            echo -n "    \"$file\": {\"status\": \"$status\", \"type\": \"configuration\"}"
        else
            local status_color=""
            case "$status" in
                "present") status_color="${GREEN}" ;;
                "missing") status_color="${RED}" ;;
                *) status_color="${NC}" ;;
            esac
            printf "  %-20s %s%-12s%s" "$file" "$status_color" "$status" "$NC"
            echo ""
        fi
    done

    # Calculate success rate
    local success_rate=0
    if [[ $total_services -gt 0 ]]; then
        success_rate=$(echo "scale=2; $healthy_services * 100 / $total_services" | bc -l 2>/dev/null || echo "0")
    fi

    if [[ "$JSON_OUTPUT" == true ]]; then
        echo ""
        echo "  },"
        echo "  \"summary\": {"
        echo "    \"total_services\": $total_services,"
        echo "    \"healthy_services\": $healthy_services,"
        echo "    \"success_rate\": \"${success_rate}%\","
        echo "    \"overall_status\": \"$overall_status\""
        echo "  }"
        echo "}"
    else
        echo ""
        echo -e "${BLUE}Summary:${NC}"
        echo "Total Components: $total_services"
        echo -e "Healthy: ${GREEN}$healthy_services${NC}"
        echo "Success Rate: ${success_rate}%"
        echo -e "Overall Status: ${GREEN}$overall_status${NC}"
        echo ""
    fi

    # Return appropriate exit code
    if [[ "$overall_status" == "healthy" ]]; then
        return 0
    else
        return 1
    fi
}

# Main execution
main() {
    if [[ "$CONTINUOUS" == true ]]; then
        log "Starting continuous health monitoring..."
        while true; do
            perform_health_check
            sleep 30
            if [[ "$JSON_OUTPUT" != true ]]; then
                echo -e "\n${BLUE}--- Next check in 30 seconds ---${NC}\n"
            fi
        done
    else
        perform_health_check
    fi
}

# Run main function
main "$@"
