#!/bin/bash

# Stitches Microservices - SMS Notification Setup Script
# This script configures SMS notifications for Grafana alerting

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Configuration
GRAFANA_URL="http://localhost:3001"
GRAFANA_USER="admin"
GRAFANA_PASSWORD="admin"

# Functions
log() {
    echo -e "${GREEN}[$(date +'%H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%H:%M:%S')] ERROR: $1${NC}"
}

info() {
    echo -e "${BLUE}[$(date +'%H:%M:%S')] INFO: $1${NC}"
}

success() {
    echo -e "${CYAN}[$(date +'%H:%M:%S')] ✅ $1${NC}"
}

# Banner
echo -e "${BLUE}"
cat << 'EOF'
 ____  _   _ _       _
/ ___|| |_(_) |_ ___| |__   ___  ___
\___ \| __| | __/ __| '_ \ / _ \/ __|
 ___) | |_| | || (__| | | |  __/\__ \
|____/ \__|_|\__\___|_| |_|\___||___/

SMS Notification Setup Script v1.0
Configuring SMS notifications for Grafana alerting
EOF
echo -e "${NC}"

# Check if Grafana is accessible
check_grafana() {
    log "Checking Grafana accessibility..."

    if ! curl -f -s "$GRAFANA_URL/api/health" > /dev/null 2>&1; then
        error "Grafana is not accessible at $GRAFANA_URL"
        info "Please start Grafana with: make monitoring"
        exit 1
    fi

    success "Grafana is accessible"
}

# Check SMS configuration
check_sms_config() {
    log "Checking SMS configuration..."

    if [[ -f ".env" ]]; then
        if grep -q "SMS_" .env; then
            success "Existing SMS configuration found in .env"
        else
            warn "No SMS configuration found in .env"
            setup_sms_config
        fi
    else
        error ".env file not found"
        exit 1
    fi
}

# Interactive SMS configuration setup
setup_sms_config() {
    log "Setting up SMS configuration..."

    echo ""
    echo -e "${WHITE}SMS Provider Configuration Setup${NC}"
    echo -e "${BLUE}================================${NC}"
    echo ""

    # Get SMS provider choice
    echo "Select your SMS provider:"
    echo "1) Twilio"
    echo "2) AWS SNS"
    echo "3) Nexmo/Vonage"
    echo "4) TextMagic"
    echo "5) Custom Webhook"
    echo ""
    read -p "Enter your choice (1-5): " provider_choice

    case $provider_choice in
        1)
            setup_twilio_config
            ;;
        2)
            setup_aws_sns_config
            ;;
        3)
            setup_nexmo_config
            ;;
        4)
            setup_textmagic_config
            ;;
        5)
            setup_custom_sms_webhook
            ;;
        *)
            error "Invalid choice. Please run the script again."
            exit 1
            ;;
    esac
}

# Twilio configuration
setup_twilio_config() {
    echo ""
    echo -e "${BLUE}Twilio Configuration${NC}"
    echo "You'll need your Twilio Account SID, Auth Token, and a phone number"
    echo "Get these from: https://console.twilio.com/"
    echo ""

    read -p "Enter your Twilio Account SID: " twilio_sid
    read -p "Enter your Twilio Auth Token: " -s twilio_token
    echo ""
    read -p "Enter your Twilio phone number (with country code, e.g., +1234567890): " twilio_from
    read -p "Enter recipient phone numbers (comma-separated, e.g., +1111111111,+2222222222): " twilio_to

    # Add to .env
    add_sms_config_to_env "twilio" "$twilio_sid" "$twilio_token" "$twilio_from" "$twilio_to" ""

    # Create Twilio webhook script
    create_twilio_webhook_script "$twilio_sid" "$twilio_token" "$twilio_from"

    success "Twilio configuration added to .env"
}

# AWS SNS configuration
setup_aws_sns_config() {
    echo ""
    echo -e "${BLUE}AWS SNS Configuration${NC}"
    echo "You'll need AWS credentials and SNS topic ARN or phone numbers"
    echo ""

    read -p "Enter your AWS Access Key ID: " aws_access_key
    read -p "Enter your AWS Secret Access Key: " -s aws_secret_key
    echo ""
    read -p "Enter your AWS region (e.g., us-east-1): " aws_region
    read -p "Enter recipient phone numbers (comma-separated, e.g., +1111111111,+2222222222): " sns_phone_numbers

    add_sms_config_to_env "aws_sns" "$aws_access_key" "$aws_secret_key" "$aws_region" "$sns_phone_numbers" ""

    # Create AWS SNS webhook script
    create_aws_sns_webhook_script "$aws_access_key" "$aws_secret_key" "$aws_region"

    success "AWS SNS configuration added to .env"
}

# Nexmo/Vonage configuration
setup_nexmo_config() {
    echo ""
    echo -e "${BLUE}Nexmo/Vonage Configuration${NC}"
    echo "You'll need your Nexmo API key and secret"
    echo ""

    read -p "Enter your Nexmo API Key: " nexmo_key
    read -p "Enter your Nexmo API Secret: " -s nexmo_secret
    echo ""
    read -p "Enter your Nexmo from number (or brand name): " nexmo_from
    read -p "Enter recipient phone numbers (comma-separated): " nexmo_to

    add_sms_config_to_env "nexmo" "$nexmo_key" "$nexmo_secret" "$nexmo_from" "$nexmo_to" ""

    # Create Nexmo webhook script
    create_nexmo_webhook_script "$nexmo_key" "$nexmo_secret" "$nexmo_from"

    success "Nexmo configuration added to .env"
}

# TextMagic configuration
setup_textmagic_config() {
    echo ""
    echo -e "${BLUE}TextMagic Configuration${NC}"
    echo "You'll need your TextMagic username and API key"
    echo ""

    read -p "Enter your TextMagic username: " textmagic_user
    read -p "Enter your TextMagic API key: " -s textmagic_key
    echo ""
    read -p "Enter recipient phone numbers (comma-separated): " textmagic_to

    add_sms_config_to_env "textmagic" "$textmagic_user" "$textmagic_key" "" "$textmagic_to" ""

    # Create TextMagic webhook script
    create_textmagic_webhook_script "$textmagic_user" "$textmagic_key"

    success "TextMagic configuration added to .env"
}

# Custom webhook configuration
setup_custom_sms_webhook() {
    echo ""
    echo -e "${BLUE}Custom SMS Webhook Configuration${NC}"
    echo "Configure a custom webhook URL for SMS delivery"
    echo ""

    read -p "Enter your SMS webhook URL: " webhook_url
    read -p "Enter webhook method (GET/POST): " webhook_method
    read -p "Enter recipient phone numbers (comma-separated): " webhook_to
    read -p "Enter any required headers (optional, format: 'Header: Value'): " webhook_headers

    add_sms_config_to_env "webhook" "$webhook_url" "$webhook_method" "$webhook_headers" "$webhook_to" ""

    # Create custom webhook script
    create_custom_sms_webhook_script "$webhook_url" "$webhook_method" "$webhook_headers"

    success "Custom webhook configuration added to .env"
}

# Add SMS configuration to .env file
add_sms_config_to_env() {
    local provider="$1"
    local param1="$2"
    local param2="$3"
    local param3="$4"
    local param4="$5"
    local param5="$6"

    # Remove existing SMS config if present
    sed -i '/^SMS_/d' .env 2>/dev/null || true

    # Add new SMS configuration
    cat >> .env << EOF

# SMS Notification Configuration ($provider)
SMS_PROVIDER=$provider
SMS_PARAM1=$param1
SMS_PARAM2=$param2
SMS_PARAM3=$param3
SMS_RECIPIENTS=$param4
SMS_PARAM5=$param5
EOF
}

# Create Twilio webhook script
create_twilio_webhook_script() {
    local account_sid="$1"
    local auth_token="$2"
    local from_number="$3"

    mkdir -p scripts/sms-webhooks

    cat > scripts/sms-webhooks/twilio-webhook.py << EOF
#!/usr/bin/env python3
"""
Twilio SMS Webhook for Grafana Alerts
Sends SMS notifications via Twilio API
"""
import sys
import json
import requests
from datetime import datetime

# Twilio Configuration
ACCOUNT_SID = "${account_sid}"
AUTH_TOKEN = "${auth_token}"
FROM_NUMBER = "${from_number}"

def send_sms(to_number, message):
    """Send SMS via Twilio API"""
    url = f"https://api.twilio.com/2010-04-01/Accounts/{ACCOUNT_SID}/Messages.json"

    data = {
        'From': FROM_NUMBER,
        'To': to_number,
        'Body': message
    }

    try:
        response = requests.post(url, data=data, auth=(ACCOUNT_SID, AUTH_TOKEN))
        response.raise_for_status()

        result = response.json()
        print(f"✅ SMS sent to {to_number}: {result.get('sid')}")
        return True

    except requests.exceptions.RequestException as e:
        print(f"❌ Failed to send SMS to {to_number}: {e}")
        return False

def parse_grafana_webhook(webhook_data):
    """Parse Grafana webhook data and format SMS message"""
    try:
        if isinstance(webhook_data, str):
            data = json.loads(webhook_data)
        else:
            data = webhook_data

        status = data.get('status', 'unknown')
        alerts = data.get('alerts', [])

        if not alerts:
            return "🚨 Stitches Alert: No alert details available"

        alert = alerts[0]  # Get first alert for SMS
        alert_name = alert.get('labels', {}).get('alertname', 'Unknown Alert')
        severity = alert.get('labels', {}).get('severity', 'unknown')
        service = alert.get('labels', {}).get('service', 'unknown')
        environment = alert.get('labels', {}).get('environment', 'staging')

        summary = alert.get('annotations', {}).get('summary', 'Alert triggered')

        # Format short SMS message (SMS has character limits)
        if status.lower() == 'firing':
            emoji = "🚨" if severity == 'critical' else "⚠️"
            message = f"{emoji} ALERT [{severity.upper()}]\\n{alert_name}\\nService: {service}\\nEnv: {environment}\\n{summary}\\nCheck: http://localhost:8080/health"
        else:
            message = f"✅ RESOLVED\\n{alert_name}\\nService: {service}\\nEnv: {environment}"

        # Truncate if too long (SMS limit ~160 chars for single message)
        if len(message) > 300:
            message = message[:297] + "..."

        return message

    except Exception as e:
        return f"🚨 Stitches Alert: Error parsing webhook data - {str(e)}"

def main():
    """Main webhook handler"""
    if len(sys.argv) < 2:
        print("Usage: python3 twilio-webhook.py '<json_payload>' [phone_numbers]")
        sys.exit(1)

    webhook_payload = sys.argv[1]

    # Get phone numbers from command line or environment
    if len(sys.argv) > 2:
        phone_numbers = sys.argv[2].split(',')
    else:
        import os
        phone_numbers = os.getenv('SMS_RECIPIENTS', '').split(',')

    phone_numbers = [num.strip() for num in phone_numbers if num.strip()]

    if not phone_numbers:
        print("❌ No recipient phone numbers provided")
        sys.exit(1)

    # Parse webhook and create message
    message = parse_grafana_webhook(webhook_payload)
    print(f"📱 SMS Message: {message}")

    # Send to all recipients
    success_count = 0
    for phone_number in phone_numbers:
        if send_sms(phone_number, message):
            success_count += 1

    print(f"📊 SMS delivery: {success_count}/{len(phone_numbers)} successful")

    if success_count == 0:
        sys.exit(1)

if __name__ == "__main__":
    main()
EOF

    chmod +x scripts/sms-webhooks/twilio-webhook.py
    success "Twilio webhook script created"
}

# Create AWS SNS webhook script
create_aws_sns_webhook_script() {
    local access_key="$1"
    local secret_key="$2"
    local region="$3"

    mkdir -p scripts/sms-webhooks

    cat > scripts/sms-webhooks/aws-sns-webhook.py << EOF
#!/usr/bin/env python3
"""
AWS SNS SMS Webhook for Grafana Alerts
Sends SMS notifications via AWS SNS
"""
import sys
import json
import boto3
from datetime import datetime

# AWS Configuration
AWS_ACCESS_KEY = "${access_key}"
AWS_SECRET_KEY = "${secret_key}"
AWS_REGION = "${region}"

def send_sms_sns(phone_number, message):
    """Send SMS via AWS SNS"""
    try:
        sns_client = boto3.client(
            'sns',
            aws_access_key_id=AWS_ACCESS_KEY,
            aws_secret_access_key=AWS_SECRET_KEY,
            region_name=AWS_REGION
        )

        response = sns_client.publish(
            PhoneNumber=phone_number,
            Message=message,
            MessageAttributes={
                'AWS.SNS.SMS.SMSType': {
                    'DataType': 'String',
                    'StringValue': 'Transactional'
                }
            }
        )

        message_id = response.get('MessageId')
        print(f"✅ SMS sent to {phone_number}: {message_id}")
        return True

    except Exception as e:
        print(f"❌ Failed to send SMS to {phone_number}: {e}")
        return False

def parse_grafana_webhook(webhook_data):
    """Parse Grafana webhook data and format SMS message"""
    try:
        if isinstance(webhook_data, str):
            data = json.loads(webhook_data)
        else:
            data = webhook_data

        status = data.get('status', 'unknown')
        alerts = data.get('alerts', [])

        if not alerts:
            return "🚨 Stitches Alert: No alert details available"

        alert = alerts[0]
        alert_name = alert.get('labels', {}).get('alertname', 'Unknown Alert')
        severity = alert.get('labels', {}).get('severity', 'unknown')
        service = alert.get('labels', {}).get('service', 'unknown')
        environment = alert.get('labels', {}).get('environment', 'staging')

        summary = alert.get('annotations', {}).get('summary', 'Alert triggered')

        if status.lower() == 'firing':
            emoji = "🚨" if severity == 'critical' else "⚠️"
            message = f"{emoji} STITCHES ALERT [{severity.upper()}]\\n{alert_name}\\nService: {service}\\nEnv: {environment}\\n{summary}\\nDashboard: http://localhost:3001"
        else:
            message = f"✅ RESOLVED: {alert_name}\\nService: {service}\\nEnv: {environment}"

        return message

    except Exception as e:
        return f"🚨 Stitches Alert: Error parsing webhook - {str(e)}"

def main():
    """Main webhook handler"""
    if len(sys.argv) < 2:
        print("Usage: python3 aws-sns-webhook.py '<json_payload>' [phone_numbers]")
        sys.exit(1)

    webhook_payload = sys.argv[1]

    # Get phone numbers
    if len(sys.argv) > 2:
        phone_numbers = sys.argv[2].split(',')
    else:
        import os
        phone_numbers = os.getenv('SMS_RECIPIENTS', '').split(',')

    phone_numbers = [num.strip() for num in phone_numbers if num.strip()]

    if not phone_numbers:
        print("❌ No recipient phone numbers provided")
        sys.exit(1)

    # Parse and send
    message = parse_grafana_webhook(webhook_payload)
    print(f"📱 SMS Message: {message}")

    success_count = 0
    for phone_number in phone_numbers:
        if send_sms_sns(phone_number, message):
            success_count += 1

    print(f"📊 SMS delivery: {success_count}/{len(phone_numbers)} successful")

    if success_count == 0:
        sys.exit(1)

if __name__ == "__main__":
    main()
EOF

    chmod +x scripts/sms-webhooks/aws-sns-webhook.py
    success "AWS SNS webhook script created"
}

# Create Nexmo webhook script
create_nexmo_webhook_script() {
    local api_key="$1"
    local api_secret="$2"
    local from_number="$3"

    mkdir -p scripts/sms-webhooks

    cat > scripts/sms-webhooks/nexmo-webhook.py << EOF
#!/usr/bin/env python3
"""
Nexmo/Vonage SMS Webhook for Grafana Alerts
"""
import sys
import json
import requests

API_KEY = "${api_key}"
API_SECRET = "${api_secret}"
FROM_NUMBER = "${from_number}"

def send_sms_nexmo(to_number, message):
    """Send SMS via Nexmo API"""
    url = "https://rest.nexmo.com/sms/json"

    data = {
        'api_key': API_KEY,
        'api_secret': API_SECRET,
        'from': FROM_NUMBER,
        'to': to_number,
        'text': message
    }

    try:
        response = requests.post(url, data=data)
        response.raise_for_status()

        result = response.json()
        if result['messages'][0]['status'] == '0':
            print(f"✅ SMS sent to {to_number}")
            return True
        else:
            print(f"❌ SMS failed to {to_number}: {result['messages'][0]['error-text']}")
            return False

    except Exception as e:
        print(f"❌ Failed to send SMS to {to_number}: {e}")
        return False

def parse_grafana_webhook(webhook_data):
    """Parse Grafana webhook and create SMS message"""
    try:
        if isinstance(webhook_data, str):
            data = json.loads(webhook_data)
        else:
            data = webhook_data

        status = data.get('status', 'unknown')
        alerts = data.get('alerts', [])

        if not alerts:
            return "Stitches Alert: No details available"

        alert = alerts[0]
        alert_name = alert.get('labels', {}).get('alertname', 'Unknown')
        severity = alert.get('labels', {}).get('severity', 'unknown')
        service = alert.get('labels', {}).get('service', 'unknown')

        if status.lower() == 'firing':
            return f"ALERT [{severity.upper()}] {alert_name} - Service: {service} - Check: localhost:8080/health"
        else:
            return f"RESOLVED: {alert_name} - Service: {service}"

    except Exception as e:
        return f"Stitches Alert: Error - {str(e)}"

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 nexmo-webhook.py '<json_payload>' [phone_numbers]")
        sys.exit(1)

    webhook_payload = sys.argv[1]

    if len(sys.argv) > 2:
        phone_numbers = sys.argv[2].split(',')
    else:
        import os
        phone_numbers = os.getenv('SMS_RECIPIENTS', '').split(',')

    phone_numbers = [num.strip() for num in phone_numbers if num.strip()]

    if not phone_numbers:
        print("❌ No recipient phone numbers provided")
        sys.exit(1)

    message = parse_grafana_webhook(webhook_payload)
    print(f"📱 SMS Message: {message}")

    success_count = 0
    for phone_number in phone_numbers:
        if send_sms_nexmo(phone_number, message):
            success_count += 1

    print(f"📊 SMS delivery: {success_count}/{len(phone_numbers)} successful")

if __name__ == "__main__":
    main()
EOF

    chmod +x scripts/sms-webhooks/nexmo-webhook.py
    success "Nexmo webhook script created"
}

# Create TextMagic webhook script
create_textmagic_webhook_script() {
    local username="$1"
    local api_key="$2"

    mkdir -p scripts/sms-webhooks

    cat > scripts/sms-webhooks/textmagic-webhook.py << EOF
#!/usr/bin/env python3
"""
TextMagic SMS Webhook for Grafana Alerts
"""
import sys
import json
import requests
import base64

USERNAME = "${username}"
API_KEY = "${api_key}"

def send_sms_textmagic(to_number, message):
    """Send SMS via TextMagic API"""
    url = "https://rest.textmagic.com/api/v2/messages"

    auth_string = f"{USERNAME}:{API_KEY}"
    auth_bytes = base64.b64encode(auth_string.encode()).decode()

    headers = {
        'Authorization': f'Basic {auth_bytes}',
        'Content-Type': 'application/x-www-form-urlencoded'
    }

    data = {
        'text': message,
        'phones': to_number
    }

    try:
        response = requests.post(url, headers=headers, data=data)
        response.raise_for_status()

        result = response.json()
        print(f"✅ SMS sent to {to_number}: {result.get('id')}")
        return True

    except Exception as e:
        print(f"❌ Failed to send SMS to {to_number}: {e}")
        return False

def parse_grafana_webhook(webhook_data):
    """Parse Grafana webhook"""
    try:
        if isinstance(webhook_data, str):
            data = json.loads(webhook_data)
        else:
            data = webhook_data

        status = data.get('status', 'unknown')
        alerts = data.get('alerts', [])

        if not alerts:
            return "Stitches Alert triggered"

        alert = alerts[0]
        alert_name = alert.get('labels', {}).get('alertname', 'Unknown')
        severity = alert.get('labels', {}).get('severity', 'unknown')
        service = alert.get('labels', {}).get('service', 'unknown')

        if status.lower() == 'firing':
            return f"ALERT [{severity.upper()}] {alert_name} - {service}"
        else:
            return f"RESOLVED: {alert_name} - {service}"

    except Exception as e:
        return f"Stitches Alert: {str(e)}"

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 textmagic-webhook.py '<json_payload>' [phone_numbers]")
        sys.exit(1)

    webhook_payload = sys.argv[1]

    if len(sys.argv) > 2:
        phone_numbers = sys.argv[2].split(',')
    else:
        import os
        phone_numbers = os.getenv('SMS_RECIPIENTS', '').split(',')

    phone_numbers = [num.strip() for num in phone_numbers if num.strip()]

    message = parse_grafana_webhook(webhook_payload)

    success_count = 0
    for phone_number in phone_numbers:
        if send_sms_textmagic(phone_number, message):
            success_count += 1

    print(f"📊 SMS delivery: {success_count}/{len(phone_numbers)} successful")

if __name__ == "__main__":
    main()
EOF

    chmod +x scripts/sms-webhooks/textmagic-webhook.py
    success "TextMagic webhook script created"
}

# Create custom webhook script
create_custom_sms_webhook_script() {
    local webhook_url="$1"
    local method="$2"
    local headers="$3"

    mkdir -p scripts/sms-webhooks

    cat > scripts/sms-webhooks/custom-sms-webhook.py << EOF
#!/usr/bin/env python3
"""
Custom SMS Webhook for Grafana Alerts
"""
import sys
import json
import requests

WEBHOOK_URL = "${webhook_url}"
METHOD = "${method}"
HEADERS = "${headers}"

def send_sms_webhook(phone_number, message):
    """Send SMS via custom webhook"""
    try:
        # Parse headers
        headers = {}
        if HEADERS:
            for header in HEADERS.split(','):
                if ':' in header:
                    key, value = header.split(':', 1)
                    headers[key.strip()] = value.strip()

        # Prepare payload
        payload = {
            'phone': phone_number,
            'message': message,
            'source': 'stitches-alerts'
        }

        if METHOD.upper() == 'POST':
            response = requests.post(WEBHOOK_URL, json=payload, headers=headers)
        else:
            params = payload
            response = requests.get(WEBHOOK_URL, params=params, headers=headers)

        response.raise_for_status()
        print(f"✅ SMS webhook called for {phone_number}")
        return True

    except Exception as e:
        print(f"❌ Failed to call SMS webhook for {phone_number}: {e}")
        return False

def parse_grafana_webhook(webhook_data):
    """Parse Grafana webhook"""
    try:
        if isinstance(webhook_data, str):
            data = json.loads(webhook_data)
        else:
            data = webhook_data

        status = data.get('status', 'unknown')
        alerts = data.get('alerts', [])

        if not alerts:
            return "Stitches Alert triggered"

        alert = alerts[0]
        alert_name = alert.get('labels', {}).get('alertname', 'Unknown')
        severity = alert.get('labels', {}).get('severity', 'unknown')
        service = alert.get('labels', {}).get('service', 'unknown')

        if status.lower() == 'firing':
            return f"ALERT [{severity}] {alert_name} - {service}"
        else:
            return f"RESOLVED: {alert_name} - {service}"

    except Exception as e:
        return f"Stitches Alert: {str(e)}"

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 custom-sms-webhook.py '<json_payload>' [phone_numbers]")
        sys.exit(1)

    webhook_payload = sys.argv[1]

    if len(sys.argv) > 2:
        phone_numbers = sys.argv[2].split(',')
    else:
        import os
        phone_numbers = os.getenv('SMS_RECIPIENTS', '').split(',')

    phone_numbers = [num.strip() for num in phone_numbers if num.strip()]

    message = parse_grafana_webhook(webhook_payload)

    success_count = 0
    for phone_number in phone_numbers:
        if send_sms_webhook(phone_number, message):
            success_count += 1

    print(f"📊 SMS delivery: {success_count}/{len(phone_numbers)} successful")

if __name__ == "__main__":
    main()
EOF

    chmod +x scripts/sms-webhooks/custom-sms-webhook.py
    success "Custom SMS webhook script created"
}

# Create SMS webhook server
create_sms_webhook_server() {
    log "Creating SMS webhook server..."

    mkdir -p scripts/sms-webhooks

    cat > scripts/sms-webhooks/sms-webhook-server.py << 'EOF'
#!/usr/bin/env python3
"""
SMS Webhook Server for Grafana Alerts
HTTP server that receives Grafana webhooks and sends SMS notifications
"""
import os
import sys
import json
import subprocess
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

class SMSWebhookHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        """Handle POST requests from Grafana"""
        try:
            # Get content length
            content_length = int(self.headers.get('Content-Length', 0))

            # Read POST data
            post_data = self.rfile.read(content_length)
            webhook_data = post_data.decode('utf-8')

            print(f"📥 Received webhook: {len(webhook_data)} bytes")

            # Get SMS provider from environment
            sms_provider = os.getenv('SMS_PROVIDER', 'twilio')
            sms_recipients = os.getenv('SMS_RECIPIENTS', '')

            if not sms_recipients:
                print("❌ No SMS recipients configured")
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b'No SMS recipients configured')
                return

            # Route to appropriate SMS provider script
            script_map = {
                'twilio': 'twilio-webhook.py',
                'aws_sns': 'aws-sns-webhook.py',
                'nexmo': 'nexmo-webhook.py',
                'textmagic': 'textmagic-webhook.py',
                'webhook': 'custom-sms-webhook.py'
            }

            script_name = script_map.get(sms_provider)
            if not script_name:
                print(f"❌ Unknown SMS provider: {sms_provider}")
                self.send_response(400)
                self.end_headers()
                return

            script_path = os.path.join(os.path.dirname(__file__), script_name)

            if not os.path.exists(script_path):
                print(f"❌ SMS script not found: {script_path}")
                self.send_response(500)
                self.end_headers()
                return

            # Execute SMS script
            cmd = [sys.executable, script_path, webhook_data, sms_recipients]
            result = subprocess.run(cmd, capture_output=True, text=True)

            if result.returncode == 0:
                print("✅ SMS notifications sent successfully")
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b'SMS notifications sent')
            else:
                print(f"❌ SMS notification failed: {result.stderr}")
                self.send_response(500)
                self.end_headers()
                self.wfile.write(b'SMS notification failed')

        except Exception as e:
            print(f"❌ Webhook processing error: {e}")
            self.send_response(500)
            self.end_headers()
            self.wfile.write(f'Error: {str(e)}'.encode())

    def do_GET(self):
        """Handle GET requests (health check)"""
        if self.path == '/health':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()

            status = {
                'status': 'healthy',
                'service': 'sms-webhook-server',
                'provider': os.getenv('SMS_PROVIDER', 'unknown'),
                'recipients_configured': bool(os.getenv('SMS_RECIPIENTS'))
            }

            self.wfile.write(json.dumps(status).encode())
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        """Override to customize logging"""
        print(f"[{self.address_string()}] {format % args}")

def main():
    # Load environment
    if os.path.exists('.env'):
        with open('.env', 'r') as f:
            for line in f:
                if '=' in line and not line.startswith('#'):
                    key, value = line.strip().split('=', 1)
                    os.environ[key] = value

    # Server configuration
    host = os.getenv('SMS_WEBHOOK_HOST', 'localhost')
    port = int(os.getenv('SMS_WEBHOOK_PORT', '8081'))

    # Create server
    server = HTTPServer((host, port), SMSWebhookHandler)

    print(f"🚀 SMS Webhook Server starting on http://{host}:{port}")
    print(f"📱 SMS Provider: {os.getenv('SMS_PROVIDER', 'not configured')}")
    print(f"📞 Recipients: {len(os.getenv('SMS_RECIPIENTS', '').split(','))} numbers")
    print("💡 Health check: GET /health")
    print("📨 Webhook endpoint: POST /")
    print("Press Ctrl+C to stop")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 Server stopped")
        server.shutdown()

if __name__ == "__main__":
    main()
EOF

    chmod +x scripts/sms-webhooks/sms-webhook-server.py
    success "SMS webhook server created"
}

# Test SMS configuration
test_sms_delivery() {
    log "Testing SMS delivery..."

    # Source SMS config
    source .env

    if [[ -z "${SMS_PROVIDER:-}" ]]; then
        warn "No SMS provider configured. Run setup first."
        return
    fi

    # Create test webhook data
    local test_webhook='{
        "status": "firing",
        "alerts": [{
            "labels": {
                "alertname": "SMS Test Alert",
                "severity": "warning",
                "service": "test-service",
                "environment": "staging"
            },
            "annotations": {
                "summary": "This is a test SMS alert from Stitches monitoring system",
                "description": "Testing SMS notification delivery"
            }
        }]
    }'

    # Find appropriate webhook script
    local script_map="twilio:twilio-webhook.py aws_sns:aws-sns-webhook.py nexmo:nexmo-webhook.py textmagic:textmagic-webhook.py webhook:custom-sms-webhook.py"
    local script_name=""

    for mapping in $script_map; do
        if [[ "${mapping%%:*}" == "${SMS_PROVIDER}" ]]; then
            script_name="${mapping##*:}"
            break
        fi
    done

    if [[ -z "$script_name" ]]; then
        error "Unknown SMS provider: ${SMS_PROVIDER}"
        return
    fi

    local script_path="scripts/sms-webhooks/${script_name}"

    if [[ -f "$script_path" ]]; then
        info "Testing SMS delivery with ${SMS_PROVIDER}..."

        if command -v python3 &> /dev/null; then
            python3 "$script_path" "$test_webhook" "${SMS_RECIPIENTS}"
            success "SMS test completed"
        else
            warn "Python3 not available for SMS testing"
        fi
    else
        error "SMS webhook script not found: $script_path"
    fi
}

# Create Grafana SMS contact point
create_sms_contact_point() {
    log "Creating SMS contact point in Grafana..."

    # Create webhook URL for SMS server
    local webhook_url="http://localhost:8081/"

    local contact_point_config=$(cat << EOF
{
  "name": "sms-alerts",
  "type": "webhook",
  "settings": {
    "url": "$webhook_url",
    "httpMethod": "POST",
    "title": "Stitches SMS Alert",
    "message": "{{ range .Alerts }}{{ .Annotations.summary }}{{ end }}"
  }
}
EOF
)

    local response=$(curl -s -u "$GRAFANA_USER:$GRAFANA_PASSWORD" \
        -H "Content-Type: application/json" \
        -d "$contact_point_config" \
        "$GRAFANA_URL/api/v1/provisioning/contact-points" 2>/dev/null || echo '{"message":"error"}')

    if echo "$response" | grep -q '"uid"'; then
        success "SMS contact point created successfully"
    else
        warn "Failed to create SMS contact point: $response"
    fi
}

# Show next steps
show_next_steps() {
    echo ""
    echo -e "${WHITE}========================================${NC}"
    echo -e "${GREEN}✅ SMS NOTIFICATIONS SETUP COMPLETE${NC}"
    echo -e "${WHITE}========================================${NC}"
    echo ""

    echo -e "${BLUE}📱 SMS Configuration Status:${NC}"
    if grep -q "SMS_PROVIDER" .env 2>/dev/null; then
        local provider=$(grep "SMS_PROVIDER" .env | cut -d'=' -f2)
        local recipients=$(grep "SMS_RECIPIENTS" .env | cut -d'=' -f2 | tr ',' '\n' | wc -l)
        echo "  ✅ SMS provider: $provider"
        echo "  ✅ Recipients configured: $recipients"
        echo "  ✅ Webhook scripts created"
    else
        echo "  ❌ SMS configuration not found"
    fi
    echo ""

    echo -e "${BLUE}🔧 Next Steps:${NC}"
    echo "  1. Start SMS webhook server:"
    echo "     python3 scripts/sms-webhooks/sms-webhook-server.py"
    echo ""
    echo "  2. Test SMS delivery:"
    echo "     make test-sms-alerts"
    echo ""
    echo "  3. Configure SMS alerts in Grafana:"
    echo "     Add SMS contact point to notification policies"
    echo ""
    echo "  4. Test end-to-end alerts:"
    echo "     make trigger-test-alert"
    echo ""

    echo -e "${BLUE}📁 Files Created:${NC}"
    echo "  • .env - Updated with SMS configuration"
    echo "  • scripts/sms-webhooks/ - Provider-specific webhook scripts"
    echo "  • sms-webhook-server.py - HTTP webhook server"
    echo ""

    echo -e "${YELLOW}⚠️  Important Notes:${NC}"
    echo "  • Keep your SMS provider credentials secure"
    echo "  • Test SMS delivery before production use"
    echo "  • Monitor SMS costs and rate limits"
    echo "  • Configure SMS only for critical alerts"
    echo ""

    echo -e "${BLUE}💡 SMS Provider Documentation:${NC}"
    echo "  • Twilio: https://www.twilio.com/docs/sms"
    echo "  • AWS SNS: https://docs.aws.amazon.com/sns/latest/dg/sms_publish-to-phone.html"
    echo "  • Nexmo: https://developer.nexmo.com/messaging/sms/overview"
    echo "  • TextMagic: https://docs.textmagic.com/"
    echo ""
}

# Main execution
main() {
    log "Starting SMS notification setup..."

    check_grafana
    check_sms_config
    create_sms_webhook_server
    create_sms_contact_point
    test_sms_delivery
    show_next_steps

    success "SMS notification setup completed successfully!"
}

# Handle interruption
trap 'echo -e "\n${RED}Setup interrupted by user${NC}"; exit 1' INT

# Run main function
main "$@"
