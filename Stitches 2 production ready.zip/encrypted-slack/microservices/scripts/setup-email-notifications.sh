#!/bin/bash

# Stitches Microservices - Email Notification Setup Script
# This script configures SMTP email notifications for Grafana alerting

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Configuration
GRAFANA_URL="http://localhost:3001"
GRAFANA_USER="admin"
GRAFANA_PASSWORD="admin"

# Functions
log() {
    echo -e "${GREEN}[$(date +'%H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%H:%M:%S')] ERROR: $1${NC}"
}

info() {
    echo -e "${BLUE}[$(date +'%H:%M:%S')] INFO: $1${NC}"
}

success() {
    echo -e "${CYAN}[$(date +'%H:%M:%S')] ✅ $1${NC}"
}

# Banner
echo -e "${BLUE}"
cat << 'EOF'
 ____  _   _ _       _
/ ___|| |_(_) |_ ___| |__   ___  ___
\___ \| __| | __/ __| '_ \ / _ \/ __|
 ___) | |_| | || (__| | | |  __/\__ \
|____/ \__|_|\__\___|_| |_|\___||___/

Email Notification Setup Script v1.0
Configuring SMTP email notifications for Grafana alerting
EOF
echo -e "${NC}"

# Check if Grafana is accessible
check_grafana() {
    log "Checking Grafana accessibility..."

    if ! curl -f -s "$GRAFANA_URL/api/health" > /dev/null 2>&1; then
        error "Grafana is not accessible at $GRAFANA_URL"
        info "Please start Grafana with: make monitoring"
        exit 1
    fi

    success "Grafana is accessible"
}

# Check environment variables
check_email_config() {
    log "Checking email configuration..."

    local missing_vars=()

    # Check for email configuration in .env
    if [[ -f ".env" ]]; then
        if ! grep -q "EMAIL_SMTP_HOST" .env; then missing_vars+=("EMAIL_SMTP_HOST"); fi
        if ! grep -q "EMAIL_SMTP_PORT" .env; then missing_vars+=("EMAIL_SMTP_PORT"); fi
        if ! grep -q "EMAIL_USERNAME" .env; then missing_vars+=("EMAIL_USERNAME"); fi
        if ! grep -q "EMAIL_PASSWORD" .env; then missing_vars+=("EMAIL_PASSWORD"); fi
        if ! grep -q "EMAIL_FROM" .env; then missing_vars+=("EMAIL_FROM"); fi
    else
        error ".env file not found"
        exit 1
    fi

    if [[ ${#missing_vars[@]} -gt 0 ]]; then
        warn "Missing email configuration variables: ${missing_vars[*]}"
        setup_email_config
    else
        success "Email configuration found in .env"
    fi
}

# Interactive email configuration setup
setup_email_config() {
    log "Setting up email configuration..."

    echo ""
    echo -e "${WHITE}Email SMTP Configuration Setup${NC}"
    echo -e "${BLUE}================================${NC}"
    echo ""

    # Get SMTP provider choice
    echo "Select your email provider:"
    echo "1) Gmail"
    echo "2) Outlook/Hotmail"
    echo "3) SendGrid"
    echo "4) AWS SES"
    echo "5) Custom SMTP"
    echo ""
    read -p "Enter your choice (1-5): " provider_choice

    case $provider_choice in
        1)
            setup_gmail_config
            ;;
        2)
            setup_outlook_config
            ;;
        3)
            setup_sendgrid_config
            ;;
        4)
            setup_aws_ses_config
            ;;
        5)
            setup_custom_smtp_config
            ;;
        *)
            error "Invalid choice. Please run the script again."
            exit 1
            ;;
    esac
}

# Gmail configuration
setup_gmail_config() {
    echo ""
    echo -e "${BLUE}Gmail Configuration${NC}"
    echo "Note: You'll need to use an App Password, not your regular Gmail password"
    echo "Generate one at: https://myaccount.google.com/apppasswords"
    echo ""

    read -p "Enter your Gmail address: " gmail_address
    read -p "Enter your Gmail App Password: " -s gmail_password
    echo ""
    read -p "Enter 'from' email address (or press Enter to use $gmail_address): " from_email

    if [[ -z "$from_email" ]]; then
        from_email="$gmail_address"
    fi

    # Add to .env
    add_email_config_to_env "smtp.gmail.com" "587" "$gmail_address" "$gmail_password" "$from_email" "true"

    success "Gmail configuration added to .env"
}

# Outlook configuration
setup_outlook_config() {
    echo ""
    echo -e "${BLUE}Outlook/Hotmail Configuration${NC}"
    echo ""

    read -p "Enter your Outlook email address: " outlook_address
    read -p "Enter your Outlook password: " -s outlook_password
    echo ""
    read -p "Enter 'from' email address (or press Enter to use $outlook_address): " from_email

    if [[ -z "$from_email" ]]; then
        from_email="$outlook_address"
    fi

    add_email_config_to_env "smtp-mail.outlook.com" "587" "$outlook_address" "$outlook_password" "$from_email" "true"

    success "Outlook configuration added to .env"
}

# SendGrid configuration
setup_sendgrid_config() {
    echo ""
    echo -e "${BLUE}SendGrid Configuration${NC}"
    echo "Note: Use 'apikey' as username and your SendGrid API key as password"
    echo ""

    read -p "Enter your SendGrid API key: " -s sendgrid_key
    echo ""
    read -p "Enter 'from' email address (verified in SendGrid): " from_email

    add_email_config_to_env "smtp.sendgrid.net" "587" "apikey" "$sendgrid_key" "$from_email" "true"

    success "SendGrid configuration added to .env"
}

# AWS SES configuration
setup_aws_ses_config() {
    echo ""
    echo -e "${BLUE}AWS SES Configuration${NC}"
    echo "Note: Use your AWS Access Key ID as username and Secret Access Key as password"
    echo ""

    read -p "Enter your AWS region (e.g., us-east-1): " aws_region
    read -p "Enter your AWS Access Key ID: " aws_access_key
    read -p "Enter your AWS Secret Access Key: " -s aws_secret_key
    echo ""
    read -p "Enter 'from' email address (verified in SES): " from_email

    local ses_host="email-smtp.${aws_region}.amazonaws.com"
    add_email_config_to_env "$ses_host" "587" "$aws_access_key" "$aws_secret_key" "$from_email" "true"

    success "AWS SES configuration added to .env"
}

# Custom SMTP configuration
setup_custom_smtp_config() {
    echo ""
    echo -e "${BLUE}Custom SMTP Configuration${NC}"
    echo ""

    read -p "Enter SMTP host: " smtp_host
    read -p "Enter SMTP port (usually 587 or 465): " smtp_port
    read -p "Enter SMTP username: " smtp_username
    read -p "Enter SMTP password: " -s smtp_password
    echo ""
    read -p "Enter 'from' email address: " from_email
    read -p "Use TLS? (y/n): " use_tls

    local tls_setting="false"
    if [[ "$use_tls" =~ ^[Yy]$ ]]; then
        tls_setting="true"
    fi

    add_email_config_to_env "$smtp_host" "$smtp_port" "$smtp_username" "$smtp_password" "$from_email" "$tls_setting"

    success "Custom SMTP configuration added to .env"
}

# Add email configuration to .env file
add_email_config_to_env() {
    local host="$1"
    local port="$2"
    local username="$3"
    local password="$4"
    local from_email="$5"
    local use_tls="$6"

    # Remove existing email config if present
    sed -i '/^EMAIL_SMTP_HOST=/d' .env 2>/dev/null || true
    sed -i '/^EMAIL_SMTP_PORT=/d' .env 2>/dev/null || true
    sed -i '/^EMAIL_USERNAME=/d' .env 2>/dev/null || true
    sed -i '/^EMAIL_PASSWORD=/d' .env 2>/dev/null || true
    sed -i '/^EMAIL_FROM=/d' .env 2>/dev/null || true
    sed -i '/^EMAIL_USE_TLS=/d' .env 2>/dev/null || true

    # Add new email configuration
    cat >> .env << EOF

# Email Notification Configuration
EMAIL_SMTP_HOST=$host
EMAIL_SMTP_PORT=$port
EMAIL_USERNAME=$username
EMAIL_PASSWORD=$password
EMAIL_FROM=$from_email
EMAIL_USE_TLS=$use_tls
EOF
}

# Create email notification contact point in Grafana
create_email_contact_point() {
    log "Creating email contact point in Grafana..."

    # Source email config from .env
    source .env

    local contact_point_config=$(cat << EOF
{
  "name": "email-alerts",
  "type": "email",
  "settings": {
    "addresses": ["${EMAIL_FROM}", "platform-team@stitches.dev", "oncall@stitches.dev"],
    "subject": "[{{ .Status | title }}] {{ .GroupLabels.alertname }} - {{ .CommonLabels.environment | title }}",
    "body": "<!DOCTYPE html>\n<html>\n<head>\n    <meta charset=\"UTF-8\">\n    <title>Stitches Alert</title>\n    <style>\n        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }\n        .header { background: {{ if eq .Status \"firing\" }}{{ if eq .CommonLabels.severity \"critical\" }}#d32f2f{{ else }}#f57c00{{ end }}{{ else }}#4caf50{{ end }}; color: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; }\n        .alert-info { background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0; }\n        .alert-details { background: #fff; border: 1px solid #ddd; padding: 15px; border-radius: 5px; margin: 10px 0; }\n        .quick-links { background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0; }\n        .quick-links a { color: #1976d2; text-decoration: none; margin-right: 15px; }\n    </style>\n</head>\n<body>\n    <div class=\"header\">\n        <h1>{{ if eq .Status \"firing\" }}🚨{{ else }}✅{{ end }} {{ .GroupLabels.alertname }}</h1>\n        <p>Environment: {{ .CommonLabels.environment | title }} | Status: {{ .Status | title }}</p>\n    </div>\n    \n    <div class=\"alert-info\">\n        <h3>Alert Information</h3>\n        <p><strong>Service:</strong> {{ .CommonLabels.service }}</p>\n        <p><strong>Severity:</strong> {{ .CommonLabels.severity | title }}</p>\n        <p><strong>Team:</strong> {{ .CommonLabels.team }}</p>\n        <p><strong>Fired At:</strong> {{ .StartsAt.Format \"2006-01-02 15:04:05 UTC\" }}</p>\n    </div>\n    \n    {{ range .Alerts }}\n    <div class=\"alert-details\">\n        <h3>{{ .Annotations.summary }}</h3>\n        <p><strong>Description:</strong> {{ .Annotations.description }}</p>\n        {{ if .Annotations.runbook_url }}<p><strong>Runbook:</strong> <a href=\"{{ .Annotations.runbook_url }}\">{{ .Annotations.runbook_url }}</a></p>{{ end }}\n    </div>\n    {{ end }}\n    \n    <div class=\"quick-links\">\n        <h3>Quick Actions</h3>\n        <a href=\"http://localhost:3001/d/stitches-cicd-performance\">📊 Performance Dashboard</a>\n        <a href=\"http://localhost:8080/health\">🏥 API Health Check</a>\n        <a href=\"http://localhost:9090/targets\">🎯 Prometheus Targets</a>\n    </div>\n</body>\n</html>"
  }
}
EOF
)

    local response=$(curl -s -u "$GRAFANA_USER:$GRAFANA_PASSWORD" \
        -H "Content-Type: application/json" \
        -d "$contact_point_config" \
        "$GRAFANA_URL/api/v1/provisioning/contact-points" 2>/dev/null || echo '{"message":"error"}')

    if echo "$response" | grep -q '"uid"'; then
        success "Email contact point created successfully"
    else
        warn "Failed to create email contact point: $response"
    fi
}

# Test email configuration
test_email_delivery() {
    log "Testing email delivery..."

    # Source email config
    source .env

    # Create test email script
    cat > test_email.py << 'EOF'
#!/usr/bin/env python3
import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

def test_email():
    # Get configuration from environment
    smtp_host = os.getenv('EMAIL_SMTP_HOST')
    smtp_port = int(os.getenv('EMAIL_SMTP_PORT', '587'))
    username = os.getenv('EMAIL_USERNAME')
    password = os.getenv('EMAIL_PASSWORD')
    from_email = os.getenv('EMAIL_FROM')
    use_tls = os.getenv('EMAIL_USE_TLS', 'true').lower() == 'true'

    if not all([smtp_host, username, password, from_email]):
        print("❌ Missing email configuration")
        return False

    try:
        # Create message
        msg = MIMEMultipart('alternative')
        msg['Subject'] = f"🧪 Stitches Alert System Test - {datetime.now().strftime('%H:%M:%S')}"
        msg['From'] = from_email
        msg['To'] = from_email

        # HTML content
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; }}
                .header {{ background: #4caf50; color: white; padding: 20px; border-radius: 5px; }}
                .content {{ padding: 20px; }}
                .footer {{ background: #f5f5f5; padding: 10px; border-radius: 5px; font-size: 12px; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>🧪 Stitches Alert System Test</h1>
                <p>Email notification test successful!</p>
            </div>
            <div class="content">
                <h3>Test Details</h3>
                <p><strong>Timestamp:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}</p>
                <p><strong>SMTP Host:</strong> {smtp_host}</p>
                <p><strong>SMTP Port:</strong> {smtp_port}</p>
                <p><strong>From Email:</strong> {from_email}</p>
                <p><strong>TLS Enabled:</strong> {use_tls}</p>

                <h3>Alert System Status</h3>
                <p>✅ Email notifications are working correctly</p>
                <p>✅ SMTP configuration is valid</p>
                <p>✅ Ready to receive production alerts</p>
            </div>
            <div class="footer">
                <p>This is a test message from the Stitches microservices alert system.</p>
                <p>If you received this, email notifications are working properly!</p>
            </div>
        </body>
        </html>
        """

        # Plain text fallback
        text = f"""
        🧪 Stitches Alert System Test

        Email notification test successful!

        Test Details:
        - Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}
        - SMTP Host: {smtp_host}
        - SMTP Port: {smtp_port}
        - From Email: {from_email}
        - TLS Enabled: {use_tls}

        Alert System Status:
        ✅ Email notifications are working correctly
        ✅ SMTP configuration is valid
        ✅ Ready to receive production alerts

        This is a test message from the Stitches microservices alert system.
        If you received this, email notifications are working properly!
        """

        msg.attach(MIMEText(text, 'plain'))
        msg.attach(MIMEText(html, 'html'))

        # Connect and send
        server = smtplib.SMTP(smtp_host, smtp_port)

        if use_tls:
            server.starttls()

        server.login(username, password)
        server.send_message(msg)
        server.quit()

        print("✅ Test email sent successfully!")
        print(f"📧 Check your inbox at: {from_email}")
        return True

    except Exception as e:
        print(f"❌ Email test failed: {e}")
        return False

if __name__ == "__main__":
    test_email()
EOF

    # Run test email
    if command -v python3 &> /dev/null; then
        python3 test_email.py
        local test_result=$?
        rm -f test_email.py

        if [[ $test_result -eq 0 ]]; then
            success "Email test completed successfully"
        else
            error "Email test failed"
        fi
    else
        warn "Python3 not available for email testing"
    fi
}

# Create Grafana SMTP configuration
setup_grafana_smtp() {
    log "Setting up Grafana SMTP configuration..."

    # Source email config
    source .env

    # Create Grafana SMTP config file
    cat > grafana-smtp.ini << EOF
[smtp]
enabled = true
host = ${EMAIL_SMTP_HOST}:${EMAIL_SMTP_PORT}
user = ${EMAIL_USERNAME}
password = ${EMAIL_PASSWORD}
cert_file =
key_file =
skip_verify = false
from_address = ${EMAIL_FROM}
from_name = Stitches Alerts
ehlo_identity =
startTLS_policy =

[emails]
welcome_email_on_sign_up = false
templates_pattern = emails/*.html
EOF

    info "Grafana SMTP configuration created: grafana-smtp.ini"
    info "To apply this configuration:"
    echo "  1. Copy grafana-smtp.ini settings to your Grafana configuration"
    echo "  2. Restart Grafana: docker-compose restart grafana"
    echo "  3. Or add these settings to your Docker Compose environment variables"
}

# Generate email notification examples
generate_email_examples() {
    log "Generating email notification examples..."

    mkdir -p email-templates

    # Critical alert example
    cat > email-templates/critical-alert-example.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>🚨 CRITICAL ALERT - Service Down</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; }
        .header { background: #d32f2f; color: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
        .alert-info { background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .alert-details { background: #fff; border: 1px solid #ddd; border-left: 5px solid #d32f2f; padding: 15px; margin: 10px 0; }
        .quick-links { background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .quick-links a { color: #1976d2; text-decoration: none; margin-right: 15px; display: inline-block; padding: 8px 12px; background: white; border-radius: 3px; }
        .footer { margin-top: 30px; padding-top: 15px; border-top: 1px solid #ddd; font-size: 12px; color: #666; }
        .status-badge { padding: 4px 8px; border-radius: 3px; color: white; font-weight: bold; }
        .critical { background: #d32f2f; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚨 CRITICAL ALERT</h1>
            <h2>Service Down - Auth Service</h2>
            <p>Environment: Staging | Status: <span class="status-badge critical">FIRING</span></p>
        </div>

        <div class="alert-info">
            <h3>Alert Information</h3>
            <table style="width: 100%; border-collapse: collapse;">
                <tr><td><strong>Service:</strong></td><td>auth-service</td></tr>
                <tr><td><strong>Severity:</strong></td><td>Critical</td></tr>
                <tr><td><strong>Team:</strong></td><td>Platform</td></tr>
                <tr><td><strong>Priority:</strong></td><td>P1 - Immediate Response Required</td></tr>
                <tr><td><strong>Fired At:</strong></td><td>2024-01-15 14:32:15 UTC</td></tr>
            </table>
        </div>

        <div class="alert-details">
            <h3>Service Down Alert</h3>
            <p><strong>Description:</strong> Auth service is down and not responding to health checks. This affects user authentication across the platform.</p>
            <p><strong>Impact:</strong> Users cannot log in or access the platform. All authentication requests are failing.</p>
            <p><strong>Runbook:</strong> <a href="https://docs.stitches.dev/runbooks/service-down">https://docs.stitches.dev/runbooks/service-down</a></p>
        </div>

        <div class="quick-links">
            <h3>🚀 Immediate Actions</h3>
            <a href="http://localhost:3001/d/stitches-cicd-performance">📊 Performance Dashboard</a>
            <a href="http://localhost:8080/health">🏥 API Health Check</a>
            <a href="http://localhost:9090/targets">🎯 Prometheus Targets</a>
            <a href="http://localhost:3001/alerting/list">⚠️ All Alerts</a>
        </div>

        <div style="background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <h3>🔧 Quick Troubleshooting</h3>
            <pre style="background: #f8f9fa; padding: 10px; border-radius: 3px; overflow-x: auto;">
# Check service status
make status

# View service logs
make logs SERVICE=auth-service

# Restart service
make restart-service SERVICE=auth-service

# Run health check
make health-check
            </pre>
        </div>

        <div class="footer">
            <p><strong>Response Required:</strong> This is a critical alert requiring immediate attention.</p>
            <p><strong>Escalation:</strong> If not resolved within 10 minutes, escalate to senior engineer.</p>
            <p><strong>Generated by:</strong> Grafana at 2024-01-15 14:32:15 UTC</p>
        </div>
    </div>
</body>
</html>
EOF

    # Warning alert example
    cat > email-templates/warning-alert-example.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>⚠️ WARNING ALERT - High Response Time</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; }
        .header { background: #f57c00; color: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
        .alert-info { background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .alert-details { background: #fff; border: 1px solid #ddd; border-left: 5px solid #f57c00; padding: 15px; margin: 10px 0; }
        .quick-links { background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .quick-links a { color: #1976d2; text-decoration: none; margin-right: 15px; display: inline-block; padding: 8px 12px; background: white; border-radius: 3px; }
        .footer { margin-top: 30px; padding-top: 15px; border-top: 1px solid #ddd; font-size: 12px; color: #666; }
        .status-badge { padding: 4px 8px; border-radius: 3px; color: white; font-weight: bold; }
        .warning { background: #f57c00; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>⚠️ WARNING ALERT</h1>
            <h2>High Response Time (P95)</h2>
            <p>Environment: Staging | Status: <span class="status-badge warning">FIRING</span></p>
        </div>

        <div class="alert-info">
            <h3>Alert Information</h3>
            <table style="width: 100%; border-collapse: collapse;">
                <tr><td><strong>Service:</strong></td><td>api-gateway</td></tr>
                <tr><td><strong>Severity:</strong></td><td>Warning</td></tr>
                <tr><td><strong>Team:</strong></td><td>Platform</td></tr>
                <tr><td><strong>Response Time:</strong></td><td>5-10 minutes</td></tr>
                <tr><td><strong>Fired At:</strong></td><td>2024-01-15 14:25:45 UTC</td></tr>
            </table>
        </div>

        <div class="alert-details">
            <h3>High Response Time Detected</h3>
            <p><strong>Description:</strong> API 95th percentile response time is 650ms, exceeding the 500ms threshold</p>
            <p><strong>Impact:</strong> Users may experience slower page loads and API responses</p>
            <p><strong>Runbook:</strong> <a href="https://docs.stitches.dev/runbooks/high-response-time">https://docs.stitches.dev/runbooks/high-response-time</a></p>
        </div>

        <div class="quick-links">
            <h3>📊 Investigation Links</h3>
            <a href="http://localhost:3001/d/stitches-cicd-performance">📊 Performance Dashboard</a>
            <a href="http://localhost:8080/health">🏥 API Health Check</a>
            <a href="http://localhost:9090/targets">🎯 Prometheus Targets</a>
        </div>

        <div class="footer">
            <p><strong>Action Required:</strong> Investigate performance degradation within 10 minutes.</p>
            <p><strong>Generated by:</strong> Grafana at 2024-01-15 14:25:45 UTC</p>
        </div>
    </div>
</body>
</html>
EOF

    success "Email template examples created in email-templates/"
}

# Show next steps
show_next_steps() {
    echo ""
    echo -e "${WHITE}========================================${NC}"
    echo -e "${GREEN}✅ EMAIL NOTIFICATIONS SETUP COMPLETE${NC}"
    echo -e "${WHITE}========================================${NC}"
    echo ""

    echo -e "${BLUE}📧 Email Configuration Status:${NC}"
    if grep -q "EMAIL_SMTP_HOST" .env 2>/dev/null; then
        echo "  ✅ SMTP configuration added to .env"
        echo "  ✅ Email contact point configured"
        echo "  ✅ HTML email templates created"
    else
        echo "  ❌ SMTP configuration not found"
    fi
    echo ""

    echo -e "${BLUE}🔧 Next Steps:${NC}"
    echo "  1. Restart Grafana to apply SMTP settings:"
    echo "     docker-compose restart grafana"
    echo ""
    echo "  2. Test email delivery:"
    echo "     make test-email-alerts"
    echo ""
    echo "  3. Configure email recipients:"
    echo "     Edit notification policies in Grafana"
    echo ""
    echo "  4. Verify email notifications:"
    echo "     make trigger-test-alert"
    echo ""

    echo -e "${BLUE}📁 Files Created:${NC}"
    echo "  • .env - Updated with SMTP configuration"
    echo "  • grafana-smtp.ini - Grafana SMTP settings"
    echo "  • email-templates/ - Example email templates"
    echo ""

    echo -e "${YELLOW}⚠️  Important Notes:${NC}"
    echo "  • Keep your email credentials secure"
    echo "  • Test email delivery before production use"
    echo "  • Configure email rate limiting if needed"
    echo "  • Set up email monitoring and delivery tracking"
    echo ""
}

# Main execution
main() {
    log "Starting email notification setup..."

    check_grafana
    check_email_config
    create_email_contact_point
    test_email_delivery
    setup_grafana_smtp
    generate_email_examples
    show_next_steps

    success "Email notification setup completed successfully!"
}

# Handle interruption
trap 'echo -e "\n${RED}Setup interrupted by user${NC}"; exit 1' INT

# Run main function
main "$@"
