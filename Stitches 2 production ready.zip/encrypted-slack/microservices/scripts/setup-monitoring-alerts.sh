#!/bin/bash

# Stitches Microservices - Monitoring Alerts Setup Script
# This script sets up comprehensive performance monitoring alerts in Grafana

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Configuration
GRAFANA_URL="http://localhost:3001"
GRAFANA_USER="admin"
GRAFANA_PASSWORD="admin"
PROMETHEUS_URL="http://localhost:9090"
API_GATEWAY_URL="http://localhost:8080"

# Functions
log() {
    echo -e "${GREEN}[$(date +'%H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%H:%M:%S')] ERROR: $1${NC}"
}

info() {
    echo -e "${BLUE}[$(date +'%H:%M:%S')] INFO: $1${NC}"
}

success() {
    echo -e "${CYAN}[$(date +'%H:%M:%S')] ✅ $1${NC}"
}

# Banner
echo -e "${BLUE}"
cat << 'EOF'
 ____  _   _ _       _
/ ___|| |_(_) |_ ___| |__   ___  ___
\___ \| __| | __/ __| '_ \ / _ \/ __|
 ___) | |_| | || (__| | | |  __/\__ \
|____/ \__|_|\__\___|_| |_|\___||___/

Monitoring Alerts Setup Script v1.0
Setting up comprehensive performance monitoring for staging environment
EOF
echo -e "${NC}"

# Check prerequisites
check_prerequisites() {
    log "Checking prerequisites..."

    # Check if services are running
    if ! curl -f -s "$GRAFANA_URL/api/health" > /dev/null 2>&1; then
        error "Grafana is not accessible at $GRAFANA_URL"
        info "Please start Grafana with: make monitoring"
        exit 1
    fi

    if ! curl -f -s "$PROMETHEUS_URL/-/healthy" > /dev/null 2>&1; then
        error "Prometheus is not accessible at $PROMETHEUS_URL"
        info "Please start Prometheus with: make monitoring"
        exit 1
    fi

    if ! curl -f -s "$API_GATEWAY_URL/health" > /dev/null 2>&1; then
        warn "API Gateway is not accessible at $API_GATEWAY_URL"
        info "Some alerts may not work properly. Start services with: make start"
    fi

    # Check if jq is available
    if ! command -v jq &> /dev/null; then
        warn "jq is not installed. JSON responses will not be formatted."
    fi

    # Check if curl supports basic auth
    if ! curl --help | grep -q "user"; then
        error "curl does not support authentication"
        exit 1
    fi

    success "Prerequisites check completed"
}

# Wait for Grafana to be ready
wait_for_grafana() {
    log "Waiting for Grafana to be ready..."

    local max_attempts=30
    local attempt=1

    while [[ $attempt -le $max_attempts ]]; do
        if curl -f -s -u "$GRAFANA_USER:$GRAFANA_PASSWORD" "$GRAFANA_URL/api/org" > /dev/null 2>&1; then
            success "Grafana is ready"
            return 0
        fi

        if [[ $attempt -eq $max_attempts ]]; then
            error "Grafana did not become ready within timeout"
            exit 1
        fi

        info "Waiting for Grafana... (attempt $attempt/$max_attempts)"
        sleep 10
        ((attempt++))
    done
}

# Check Prometheus data source
check_prometheus_datasource() {
    log "Checking Prometheus data source..."

    local response=$(curl -s -u "$GRAFANA_USER:$GRAFANA_PASSWORD" \
        "$GRAFANA_URL/api/datasources" 2>/dev/null || echo "[]")

    if echo "$response" | grep -q "prometheus"; then
        success "Prometheus data source found"
    else
        warn "Prometheus data source not found, creating it..."
        create_prometheus_datasource
    fi
}

# Create Prometheus data source
create_prometheus_datasource() {
    local datasource_config='{
        "name": "Prometheus",
        "type": "prometheus",
        "url": "'$PROMETHEUS_URL'",
        "access": "proxy",
        "isDefault": true,
        "basicAuth": false
    }'

    local response=$(curl -s -u "$GRAFANA_USER:$GRAFANA_PASSWORD" \
        -H "Content-Type: application/json" \
        -d "$datasource_config" \
        "$GRAFANA_URL/api/datasources" 2>/dev/null || echo '{"message":"error"}')

    if echo "$response" | grep -q '"id"'; then
        success "Prometheus data source created"
    else
        warn "Failed to create Prometheus data source: $response"
    fi
}

# Test Prometheus connectivity
test_prometheus_connectivity() {
    log "Testing Prometheus connectivity..."

    # Test basic connectivity
    if curl -f -s "$PROMETHEUS_URL/api/v1/label/__name__/values" > /dev/null 2>&1; then
        success "Prometheus API is accessible"
    else
        error "Cannot access Prometheus API"
        return 1
    fi

    # Test for microservices metrics
    local metrics_check=$(curl -s "$PROMETHEUS_URL/api/v1/label/__name__/values" | \
        grep -E "(http_requests|up|container_memory)" || echo "")

    if [[ -n "$metrics_check" ]]; then
        success "Microservices metrics found in Prometheus"
    else
        warn "No microservices metrics found in Prometheus"
        info "Make sure services are running and exposing metrics"
    fi
}

# Validate alert rule files
validate_alert_rules() {
    log "Validating alert rule files..."

    local alert_files=(
        "monitoring/grafana/provisioning/alerting/alert-rules.yml"
        "monitoring/grafana/provisioning/alerting/enhanced-performance-alerts.yml"
        "monitoring/grafana/provisioning/alerting/contact-points.yml"
        "monitoring/grafana/provisioning/alerting/notification-policies.yml"
        "monitoring/grafana/provisioning/alerting/message-templates.yml"
    )

    for file in "${alert_files[@]}"; do
        if [[ -f "$file" ]]; then
            success "Found: $file"

            # Basic YAML validation
            if command -v python3 &> /dev/null; then
                if python3 -c "import yaml; yaml.safe_load(open('$file'))" 2>/dev/null; then
                    success "✓ Valid YAML: $file"
                else
                    error "✗ Invalid YAML: $file"
                fi
            fi
        else
            error "Missing: $file"
        fi
    done
}

# Check alert rules in Grafana
check_alert_rules() {
    log "Checking alert rules in Grafana..."

    local response=$(curl -s -u "$GRAFANA_USER:$GRAFANA_PASSWORD" \
        "$GRAFANA_URL/api/ruler/grafana/api/v1/rules" 2>/dev/null || echo '{}')

    local rule_count=0
    if command -v jq &> /dev/null; then
        rule_count=$(echo "$response" | jq 'length' 2>/dev/null || echo "0")
    fi

    if [[ $rule_count -gt 0 ]]; then
        success "Found $rule_count alert rule groups"

        # List rule groups
        if command -v jq &> /dev/null; then
            echo "$response" | jq -r 'keys[]' | while read -r group; do
                info "  ✓ Rule group: $group"
            done
        fi
    else
        warn "No alert rules found in Grafana"
        info "Alert rules should be provisioned automatically"
    fi
}

# Check notification channels
check_notification_channels() {
    log "Checking notification channels..."

    local response=$(curl -s -u "$GRAFANA_USER:$GRAFANA_PASSWORD" \
        "$GRAFANA_URL/api/alert-notifications" 2>/dev/null || echo '[]')

    local channel_count=0
    if command -v jq &> /dev/null; then
        channel_count=$(echo "$response" | jq 'length' 2>/dev/null || echo "0")
    fi

    if [[ $channel_count -gt 0 ]]; then
        success "Found $channel_count notification channels"
    else
        warn "No notification channels found"
        info "Configure notification channels for alert delivery"
    fi
}

# Test alert conditions
test_alert_conditions() {
    log "Testing alert conditions with sample queries..."

    local test_queries=(
        'up{job="prometheus"}'
        'rate(http_requests_total[5m])'
        'histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))'
        'container_memory_usage_bytes'
    )

    for query in "${test_queries[@]}"; do
        local encoded_query=$(echo "$query" | sed 's/ /%20/g' | sed 's/{/%7B/g' | sed 's/}/%7D/g')
        local response=$(curl -s "$PROMETHEUS_URL/api/v1/query?query=$encoded_query" 2>/dev/null || echo '{"status":"error"}')

        if echo "$response" | grep -q '"status":"success"'; then
            success "✓ Query works: $query"
        else
            warn "✗ Query failed: $query"
        fi
    done
}

# Simulate alert conditions for testing
simulate_alert_conditions() {
    log "Simulating alert conditions for testing..."

    info "Testing API response time..."
    # Make several requests to potentially trigger response time alerts
    for i in {1..10}; do
        curl -s -w "Response time: %{time_total}s\n" -o /dev/null "$API_GATEWAY_URL/health" &
    done
    wait

    info "Testing authentication endpoint..."
    # Test auth endpoint (should return 400/401, which is expected)
    curl -s -X POST -H "Content-Type: application/json" \
        -d '{"email":"test@example.com","password":"test"}' \
        "$API_GATEWAY_URL/api/v1/auth/login" > /dev/null

    info "Testing load on different endpoints..."
    local endpoints=(
        "/health"
        "/api/v1/chat/channels"
        "/api/v1/projects"
        "/api/v1/files/upload"
    )

    for endpoint in "${endpoints[@]}"; do
        curl -s -o /dev/null "$API_GATEWAY_URL$endpoint" &
    done
    wait

    success "Alert condition simulation completed"
}

# Check current alerts
check_current_alerts() {
    log "Checking current active alerts..."

    local response=$(curl -s -u "$GRAFANA_USER:$GRAFANA_PASSWORD" \
        "$GRAFANA_URL/api/alertmanager/grafana/api/v2/alerts" 2>/dev/null || echo '[]')

    local alert_count=0
    if command -v jq &> /dev/null; then
        alert_count=$(echo "$response" | jq 'length' 2>/dev/null || echo "0")
    fi

    if [[ $alert_count -gt 0 ]]; then
        warn "Found $alert_count active alerts"

        if command -v jq &> /dev/null; then
            echo "$response" | jq -r '.[] | "\(.labels.alertname) - \(.labels.severity)"' | while read -r alert; do
                warn "  ⚠️  $alert"
            done
        fi
    else
        success "No active alerts (system is healthy)"
    fi
}

# Create test dashboard
create_test_dashboard() {
    log "Creating monitoring test dashboard..."

    local dashboard_config='{
        "dashboard": {
            "title": "Stitches Monitoring Test Dashboard",
            "tags": ["stitches", "test", "monitoring"],
            "panels": [
                {
                    "id": 1,
                    "title": "API Response Times",
                    "type": "timeseries",
                    "targets": [
                        {
                            "expr": "histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m])) * 1000",
                            "legendFormat": "95th Percentile"
                        }
                    ],
                    "gridPos": {"h": 8, "w": 12, "x": 0, "y": 0}
                },
                {
                    "id": 2,
                    "title": "Service Health",
                    "type": "stat",
                    "targets": [
                        {
                            "expr": "up",
                            "legendFormat": "{{job}}"
                        }
                    ],
                    "gridPos": {"h": 8, "w": 12, "x": 12, "y": 0}
                }
            ]
        },
        "overwrite": true
    }'

    local response=$(curl -s -u "$GRAFANA_USER:$GRAFANA_PASSWORD" \
        -H "Content-Type: application/json" \
        -d "$dashboard_config" \
        "$GRAFANA_URL/api/dashboards/db" 2>/dev/null || echo '{"status":"error"}')

    if echo "$response" | grep -q '"status":"success"'; then
        success "Test dashboard created"
        info "Access it at: $GRAFANA_URL/d/$(echo "$response" | grep -o '"uid":"[^"]*"' | cut -d'"' -f4)"
    else
        warn "Failed to create test dashboard"
    fi
}

# Generate monitoring report
generate_monitoring_report() {
    log "Generating monitoring setup report..."

    local report_file="monitoring-setup-report-$(date +%Y%m%d_%H%M%S).txt"

    cat > "$report_file" << EOF
# Stitches Microservices Monitoring Setup Report
Generated: $(date)

## System Status
- Grafana URL: $GRAFANA_URL
- Prometheus URL: $PROMETHEUS_URL
- API Gateway URL: $API_GATEWAY_URL

## Alert Rules Configuration
EOF

    # Add alert rule files status
    local alert_files=(
        "monitoring/grafana/provisioning/alerting/alert-rules.yml"
        "monitoring/grafana/provisioning/alerting/enhanced-performance-alerts.yml"
        "monitoring/grafana/provisioning/alerting/contact-points.yml"
        "monitoring/grafana/provisioning/alerting/notification-policies.yml"
        "monitoring/grafana/provisioning/alerting/message-templates.yml"
    )

    for file in "${alert_files[@]}"; do
        if [[ -f "$file" ]]; then
            echo "✅ $file" >> "$report_file"
        else
            echo "❌ $file" >> "$report_file"
        fi
    done

    cat >> "$report_file" << EOF

## Service Health Check
EOF

    # Check service health
    local services=("grafana" "prometheus" "api-gateway")
    local urls=("$GRAFANA_URL/api/health" "$PROMETHEUS_URL/-/healthy" "$API_GATEWAY_URL/health")

    for i in "${!services[@]}"; do
        local service="${services[$i]}"
        local url="${urls[$i]}"

        if curl -f -s "$url" > /dev/null 2>&1; then
            echo "✅ $service: Healthy" >> "$report_file"
        else
            echo "❌ $service: Unhealthy" >> "$report_file"
        fi
    done

    cat >> "$report_file" << EOF

## Quick Access Links
- Performance Dashboard: $GRAFANA_URL/d/stitches-cicd-performance
- Alert Rules: $GRAFANA_URL/alerting/list
- Prometheus Targets: $PROMETHEUS_URL/targets
- API Health: $API_GATEWAY_URL/health

## Next Steps
1. Configure notification channels (Slack, email, etc.)
2. Set up environment variables for webhooks
3. Test alert notifications
4. Create custom dashboards for your metrics
5. Set up alert escalation policies

## Troubleshooting
- If alerts don't fire, check Prometheus metrics collection
- Verify alert rule syntax in Grafana
- Check notification channel configuration
- Review alert evaluation intervals

## Support
- Alert Runbooks: docs/ALERT_RUNBOOKS.md
- Deployment Guide: DEPLOYMENT.md
- CI/CD Setup: CI_CD_SETUP.md
EOF

    success "Monitoring report generated: $report_file"
}

# Show next steps
show_next_steps() {
    echo ""
    echo -e "${WHITE}========================================${NC}"
    echo -e "${GREEN}✅ MONITORING ALERTS SETUP COMPLETE${NC}"
    echo -e "${WHITE}========================================${NC}"
    echo ""

    echo -e "${BLUE}📊 Access Your Monitoring:${NC}"
    echo "  • Grafana Dashboard: $GRAFANA_URL"
    echo "  • Performance Dashboard: $GRAFANA_URL/d/stitches-cicd-performance"
    echo "  • Alert Rules: $GRAFANA_URL/alerting/list"
    echo "  • Prometheus Metrics: $PROMETHEUS_URL"
    echo ""

    echo -e "${BLUE}🔧 Next Configuration Steps:${NC}"
    echo "  1. Set up notification channels:"
    echo "     • SLACK_WEBHOOK_URL for Slack notifications"
    echo "     • Email SMTP settings for email alerts"
    echo "     • PagerDuty integration key"
    echo ""
    echo "  2. Configure environment variables:"
    echo "     • Edit .env file with webhook URLs"
    echo "     • Restart Grafana to load new settings"
    echo ""
    echo "  3. Test alert notifications:"
    echo "     • Trigger test alerts"
    echo "     • Verify notification delivery"
    echo "     • Adjust alert thresholds if needed"
    echo ""

    echo -e "${BLUE}📚 Documentation:${NC}"
    echo "  • Alert Runbooks: docs/ALERT_RUNBOOKS.md"
    echo "  • CI/CD Setup: CI_CD_SETUP.md"
    echo "  • Deployment Guide: DEPLOYMENT.md"
    echo ""

    echo -e "${BLUE}🚨 Alert Categories Configured:${NC}"
    echo "  • API Performance (response time, error rates)"
    echo "  • Service Health (uptime, connectivity)"
    echo "  • Infrastructure (CPU, memory, disk)"
    echo "  • Business Metrics (auth failures, load tests)"
    echo "  • Security (traffic anomalies, attack patterns)"
    echo ""

    echo -e "${YELLOW}⚠️  Important Notes:${NC}"
    echo "  • Alerts are configured for staging environment"
    echo "  • Customize thresholds for your specific needs"
    echo "  • Set up escalation policies for critical alerts"
    echo "  • Regular review and tune alert sensitivity"
    echo ""
}

# Main execution
main() {
    log "Starting Stitches monitoring alerts setup..."

    check_prerequisites
    wait_for_grafana
    check_prometheus_datasource
    test_prometheus_connectivity
    validate_alert_rules
    check_alert_rules
    check_notification_channels
    test_alert_conditions
    simulate_alert_conditions
    check_current_alerts
    create_test_dashboard
    generate_monitoring_report
    show_next_steps

    success "Monitoring alerts setup completed successfully!"
}

# Handle interruption
trap 'echo -e "\n${RED}Setup interrupted by user${NC}"; exit 1' INT

# Run main function
main "$@"
