package main

import (
	"encoding/json"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
)

type APIGateway struct {
	router *gin.Engine
}

// Health check endpoint
func (api *APIGateway) healthCheck(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"status":    "ok",
		"timestamp": time.Now().UTC(),
		"service":   "api-gateway",
		"version":   "1.0.0",
	})
}

// Auth endpoints
func (api *APIGateway) login(c *gin.Context) {
	log.Println("Login request received at API Gateway")
	// Mock response - in real implementation, this would call auth-service
	c.JSON(http.StatusOK, gin.H{
		"token":   "sample-jwt-token",
		"user_id": "sample-user-id",
		"status":  "success",
	})
}

func (api *APIGateway) register(c *gin.Context) {
	log.Println("Register request received at API Gateway")
	// Mock response - in real implementation, this would call auth-service
	c.JSON(http.StatusOK, gin.H{
		"user_id": "sample-user-id",
		"status":  "success",
	})
}

// Chat endpoints
func (api *APIGateway) getChannels(c *gin.Context) {
	log.Println("GetChannels request received at API Gateway")
	// Mock response - in real implementation, this would call chat-service
	c.JSON(http.StatusOK, gin.H{
		"channels": []map[string]interface{}{
			{"id": "1", "name": "general", "type": "public"},
			{"id": "2", "name": "random", "type": "public"},
		},
	})
}

func (api *APIGateway) sendMessage(c *gin.Context) {
	log.Println("SendMessage request received at API Gateway")
	// Mock response - in real implementation, this would call chat-service
	c.JSON(http.StatusOK, gin.H{
		"message_id": "sample-message-id",
		"status":     "sent",
	})
}

// Project endpoints
func (api *APIGateway) getProjects(c *gin.Context) {
	log.Println("GetProjects request received at API Gateway")
	// Mock response - in real implementation, this would call project-service
	c.JSON(http.StatusOK, gin.H{
		"projects": []map[string]interface{}{
			{"id": "1", "name": "Sample Project", "status": "active"},
		},
	})
}

// File endpoints
func (api *APIGateway) uploadFile(c *gin.Context) {
	log.Println("UploadFile request received at API Gateway")
	// Mock response - in real implementation, this would call file-service
	c.JSON(http.StatusOK, gin.H{
		"file_id": "sample-file-id",
		"status":  "uploaded",
	})
}

// Middleware for authentication (mock)
func (api *APIGateway) authMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		// Mock authentication - in real implementation, this would validate JWT
		authHeader := c.GetHeader("Authorization")
		if authHeader == "" {
			// Allow health check and auth endpoints without token
			path := c.Request.URL.Path
			if path == "/health" || path == "/api/v1/auth/login" || path == "/api/v1/auth/register" {
				c.Next()
				return
			}
			c.JSON(http.StatusUnauthorized, gin.H{"error": "Authorization header required"})
			c.Abort()
			return
		}
		c.Next()
	}
}

func (api *APIGateway) setupRoutes() {
	// Configure CORS
	config := cors.DefaultConfig()
	config.AllowOrigins = []string{"*"} // In production, specify exact origins
	config.AllowMethods = []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"}
	config.AllowHeaders = []string{"Origin", "Content-Type", "Accept", "Authorization"}
	api.router.Use(cors.New(config))

	// Apply auth middleware
	api.router.Use(api.authMiddleware())

	// Health check (no auth required)
	api.router.GET("/health", api.healthCheck)

	// API version 1
	v1 := api.router.Group("/api/v1")
	{
		// Auth routes (no auth required)
		auth := v1.Group("/auth")
		{
			auth.POST("/login", api.login)
			auth.POST("/register", api.register)
		}

		// Chat routes
		chat := v1.Group("/chat")
		{
			chat.GET("/channels", api.getChannels)
			chat.POST("/channels/:id/messages", api.sendMessage)
		}

		// Project routes
		projects := v1.Group("/projects")
		{
			projects.GET("", api.getProjects)
		}

		// File routes
		files := v1.Group("/files")
		{
			files.POST("/upload", api.uploadFile)
		}
	}
}

func main() {
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	// Set gin mode
	gin.SetMode(gin.ReleaseMode)

	api := &APIGateway{
		router: gin.New(),
	}

	// Use gin's default middleware
	api.router.Use(gin.Logger())
	api.router.Use(gin.Recovery())

	// Setup routes
	api.setupRoutes()

	log.Printf("API Gateway starting on port %s", port)

	// Start server in a goroutine
	server := &http.Server{
		Addr:    ":" + port,
		Handler: api.router,
	}

	go func() {
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Failed to start server: %v", err)
		}
	}()

	// Wait for interrupt signal to gracefully shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	log.Println("Shutting down API Gateway...")
	log.Println("API Gateway stopped")
}
