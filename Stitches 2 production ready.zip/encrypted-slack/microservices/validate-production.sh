#!/bin/bash

# Stitches Microservices Production Readiness Validation Script
# This script validates that the microservices are ready for production deployment

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Validation counters
TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0
WARNING_CHECKS=0

# Functions
log() {
    echo -e "${GREEN}[$(date +'%H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%H:%M:%S')] ERROR: $1${NC}"
}

info() {
    echo -e "${BLUE}[$(date +'%H:%M:%S')] INFO: $1${NC}"
}

# Validation function
validate() {
    local check_name="$1"
    local check_command="$2"
    local check_type="${3:-error}"  # error, warning, info

    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))

    if eval "$check_command" >/dev/null 2>&1; then
        log "✅ PASS: $check_name"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
        return 0
    else
        case "$check_type" in
            "error")
                error "❌ FAIL: $check_name"
                FAILED_CHECKS=$((FAILED_CHECKS + 1))
                ;;
            "warning")
                warn "⚠️  WARN: $check_name"
                WARNING_CHECKS=$((WARNING_CHECKS + 1))
                ;;
            "info")
                info "ℹ️  INFO: $check_name"
                ;;
        esac
        return 1
    fi
}

# File existence validation
validate_file_exists() {
    local file="$1"
    local description="$2"
    local check_type="${3:-error}"

    validate "$description" "test -f '$file'" "$check_type"
}

# Directory existence validation
validate_dir_exists() {
    local dir="$1"
    local description="$2"
    local check_type="${3:-error}"

    validate "$description" "test -d '$dir'" "$check_type"
}

# Environment variable validation
validate_env_var() {
    local var_name="$1"
    local description="$2"
    local check_type="${3:-warning}"

    if [[ -f ".env" ]]; then
        validate "$description" "grep -q '^${var_name}=' .env && ! grep -q '^${var_name}=.*CHANGE_THIS\\|^${var_name}=your-.*\\|^${var_name}=$' .env" "$check_type"
    else
        error "❌ FAIL: .env file not found"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
        TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    fi
}

# Banner
echo -e "${BLUE}"
cat << 'EOF'
 ____  _   _ _       _
/ ___|| |_(_) |_ ___| |__   ___  ___
\___ \| __| | __/ __| '_ \ / _ \/ __|
 ___) | |_| | || (__| | | |  __/\__ \
|____/ \__|_|\__\___|_| |_|\___||___/

Production Readiness Validation v1.0
EOF
echo -e "${NC}"

# Validate core files and structure
validate_core_structure() {
    log "Validating core project structure..."

    # Core configuration files
    validate_file_exists "docker-compose.yml" "Docker Compose configuration"
    validate_file_exists "Makefile" "Makefile for automation"
    validate_file_exists ".env.example" "Environment template file"
    validate_file_exists "README.md" "Project documentation"
    validate_file_exists "DEPLOYMENT.md" "Deployment documentation"

    # Essential scripts
    validate_file_exists "deploy-production.sh" "Production deployment script"
    validate_file_exists "scripts/health-check.sh" "Health check script"
    validate_file_exists "scripts/create-multiple-databases.sh" "Database initialization script"

    # Check script permissions
    validate "Production deployment script executable" "test -x deploy-production.sh"
    validate "Health check script executable" "test -x scripts/health-check.sh"
}

# Validate microservices structure
validate_microservices() {
    log "Validating microservices structure..."

    local services=("auth-service" "chat-service" "notification-service" "project-service" "video-service" "assistant-service" "file-service" "api-gateway")

    for service in "${services[@]}"; do
        validate_dir_exists "$service" "$service directory"
        validate_file_exists "$service/main.go" "$service main.go"
        validate_file_exists "$service/Dockerfile" "$service Dockerfile"
        validate_file_exists "$service/go.mod" "$service go.mod"

        # Check if protobuf files exist for gRPC services
        if [[ "$service" != "api-gateway" ]]; then
            local service_name=${service%-service}
            validate_file_exists "$service/proto/${service_name}.pb.go" "$service protobuf Go file" "warning"
            validate_file_exists "$service/proto/${service_name}_grpc.pb.go" "$service gRPC Go file" "warning"
        fi
    done
}

# Validate Docker configurations
validate_docker_configs() {
    log "Validating Docker configurations..."

    # Check Docker Compose file syntax
    validate "Docker Compose file syntax" "docker-compose config -q"

    # Validate that all services are defined in docker-compose.yml
    local services=("auth-service" "chat-service" "notification-service" "project-service" "video-service" "assistant-service" "file-service" "api-gateway")

    for service in "${services[@]}"; do
        validate "$service defined in Docker Compose" "grep -q '$service:' docker-compose.yml"
    done

    # Check infrastructure services
    validate "PostgreSQL service defined" "grep -q 'postgres:' docker-compose.yml"
    validate "Redis service defined" "grep -q 'redis:' docker-compose.yml"
    validate "MinIO service defined" "grep -q 'minio:' docker-compose.yml"
    validate "Nginx service defined" "grep -q 'nginx:' docker-compose.yml"
    validate "Prometheus service defined" "grep -q 'prometheus:' docker-compose.yml"
    validate "Grafana service defined" "grep -q 'grafana:' docker-compose.yml"
}

# Validate environment configuration
validate_environment() {
    log "Validating environment configuration..."

    # Check if .env file exists
    validate_file_exists ".env" "Environment configuration file"

    if [[ -f ".env" ]]; then
        # Critical environment variables
        validate_env_var "JWT_SECRET" "JWT Secret configured" "error"
        validate_env_var "POSTGRES_PASSWORD" "PostgreSQL password configured" "error"

        # Important API keys (warnings if not set)
        validate_env_var "OPENAI_API_KEY" "OpenAI API key configured" "warning"
        validate_env_var "SENDGRID_API_KEY" "SendGrid API key configured" "warning"

        # Optional API keys
        validate_env_var "ZOOM_API_KEY" "Zoom API key configured" "info"
        validate_env_var "ZOOM_API_SECRET" "Zoom API secret configured" "info"

        # Database configuration
        validate_env_var "DATABASE_URL" "Database URL configured" "error"
        validate_env_var "REDIS_URL" "Redis URL configured" "error"

        # MinIO configuration
        validate_env_var "MINIO_ROOT_PASSWORD" "MinIO root password configured" "warning"

        # Check for production-specific settings
        if grep -q "ENVIRONMENT=production" .env 2>/dev/null; then
            validate_env_var "SSL_CERT_PATH" "SSL certificate path configured" "warning"
            validate_env_var "SSL_KEY_PATH" "SSL key path configured" "warning"
        fi
    fi
}

# Validate security configurations
validate_security() {
    log "Validating security configurations..."

    # Check for default passwords
    if [[ -f ".env" ]]; then
        validate "No default PostgreSQL password" "! grep -q 'POSTGRES_PASSWORD=password' .env" "error"
        validate "No default Redis password" "! grep -q 'REDIS_PASSWORD=password' .env" "warning"
        validate "No default MinIO password" "! grep -q 'MINIO_ROOT_PASSWORD=minioadmin' .env" "warning"
        validate "No default JWT secret" "! grep -q 'JWT_SECRET=your-super-secret' .env" "error"
    fi

    # Check Dockerfile security
    local services=("auth-service" "chat-service" "notification-service" "project-service" "video-service" "assistant-service" "file-service")

    for service in "${services[@]}"; do
        if [[ -f "$service/Dockerfile" ]]; then
            validate "$service runs as non-root user" "grep -q 'USER appuser' $service/Dockerfile"
            validate "$service has health check" "grep -q 'HEALTHCHECK' $service/Dockerfile"
            validate "$service installs grpc_health_probe" "grep -q 'grpc_health_probe' $service/Dockerfile" "warning"
        fi
    done
}

# Validate monitoring setup
validate_monitoring() {
    log "Validating monitoring setup..."

    # Prometheus configuration
    validate_file_exists "monitoring/prometheus.yml" "Prometheus configuration"

    # Grafana configuration
    validate_dir_exists "monitoring/grafana" "Grafana configuration directory"
    validate_dir_exists "monitoring/grafana/provisioning" "Grafana provisioning directory"
    validate_file_exists "monitoring/grafana/provisioning/datasources/prometheus.yml" "Grafana Prometheus datasource"
    validate_file_exists "monitoring/grafana/provisioning/dashboards/dashboard.yml" "Grafana dashboard configuration"

    # Check for custom dashboards
    validate_file_exists "monitoring/grafana/provisioning/dashboards/stitches-microservices-health.json" "Stitches microservices dashboard" "warning"
}

# Validate production configurations
validate_production_configs() {
    log "Validating production configurations..."

    # Production environment file
    validate_file_exists ".env.production" "Production environment template"

    # Nginx configuration
    validate_file_exists "nginx/nginx.conf" "Nginx configuration" "warning"

    # SSL certificates directory (for production)
    validate_dir_exists "nginx/ssl" "SSL certificates directory" "info"

    # Backup and deployment scripts
    validate_file_exists "deploy-production.sh" "Production deployment script"
    validate "Production deployment script executable" "test -x deploy-production.sh"

    # Check production-specific configurations
    if [[ -f ".env.production" ]]; then
        validate "Production environment properly configured" "! grep -q 'CHANGE_THIS' .env.production" "warning"
    fi
}

# Validate network and connectivity
validate_network() {
    log "Validating network configuration..."

    # Check Docker network configuration
    if command -v docker &> /dev/null; then
        validate "Docker is accessible" "docker info >/dev/null 2>&1"

        # Check if services are running
        if docker-compose ps >/dev/null 2>&1; then
            validate "Docker Compose services status" "docker-compose ps | grep -q 'Up'" "warning"
        fi
    fi

    # Check port configurations in docker-compose.yml
    validate "API Gateway port configured" "grep -q '8080:8080' docker-compose.yml"
    validate "Auth service port configured" "grep -q '50051:50051' docker-compose.yml"
    validate "Chat service port configured" "grep -q '50052:50052' docker-compose.yml"
    validate "Notification service port configured" "grep -q '50053:50053' docker-compose.yml"
    validate "Project service port configured" "grep -q '50054:50054' docker-compose.yml"
    validate "Video service port configured" "grep -q '50055:50055' docker-compose.yml"
    validate "Assistant service port configured" "grep -q '50056:50056' docker-compose.yml"
    validate "File service port configured" "grep -q '50057:50057' docker-compose.yml"
}

# Generate validation report
generate_report() {
    echo ""
    echo -e "${BLUE}============================================${NC}"
    echo -e "${BLUE}     PRODUCTION READINESS VALIDATION      ${NC}"
    echo -e "${BLUE}============================================${NC}"
    echo ""
    echo "Total Checks: $TOTAL_CHECKS"
    echo -e "Passed: ${GREEN}$PASSED_CHECKS${NC}"
    echo -e "Failed: ${RED}$FAILED_CHECKS${NC}"
    echo -e "Warnings: ${YELLOW}$WARNING_CHECKS${NC}"
    echo ""

    local success_rate=0
    if [[ $TOTAL_CHECKS -gt 0 ]]; then
        success_rate=$(echo "scale=2; $PASSED_CHECKS * 100 / $TOTAL_CHECKS" | bc -l 2>/dev/null || echo "0")
    fi

    echo "Success Rate: ${success_rate}%"
    echo ""

    # Production readiness assessment
    if [[ $FAILED_CHECKS -eq 0 ]]; then
        if [[ $WARNING_CHECKS -eq 0 ]]; then
            log "🎉 EXCELLENT! The system is fully ready for production deployment."
            echo -e "Recommendation: ${GREEN}Proceed with production deployment${NC}"
        else
            log "✅ GOOD! The system is ready for production with minor recommendations."
            echo -e "Recommendation: ${YELLOW}Address warnings before production deployment${NC}"
        fi
        return 0
    else
        if [[ $FAILED_CHECKS -le 2 ]]; then
            warn "⚠️  PARTIAL! The system has minor issues that should be addressed."
            echo -e "Recommendation: ${YELLOW}Fix critical issues before production deployment${NC}"
        else
            error "❌ NOT READY! The system has significant issues that must be resolved."
            echo -e "Recommendation: ${RED}Do not deploy to production until all issues are resolved${NC}"
        fi
        return 1
    fi
}

# Show recommendations
show_recommendations() {
    echo ""
    echo -e "${BLUE}Recommendations for Production Deployment:${NC}"
    echo ""

    if [[ $FAILED_CHECKS -gt 0 ]]; then
        echo -e "${RED}Critical Issues to Fix:${NC}"
        echo "1. Review and fix all failed validation checks above"
        echo "2. Ensure all environment variables are properly configured"
        echo "3. Test the complete deployment in a staging environment"
        echo ""
    fi

    if [[ $WARNING_CHECKS -gt 0 ]]; then
        echo -e "${YELLOW}Recommended Improvements:${NC}"
        echo "1. Configure all API keys for full functionality"
        echo "2. Set up SSL certificates for secure communication"
        echo "3. Review and update default passwords"
        echo "4. Ensure monitoring dashboards are properly configured"
        echo ""
    fi

    echo -e "${BLUE}Next Steps:${NC}"
    echo "1. Run './setup-microservices.sh' to set up the environment"
    echo "2. Run './test-microservices.sh' to test all functionality"
    echo "3. Run './deploy-production.sh' for production deployment"
    echo "4. Monitor the system using Grafana dashboards"
    echo ""
}

# Main execution
main() {
    log "Starting production readiness validation..."

    validate_core_structure
    validate_microservices
    validate_docker_configs
    validate_environment
    validate_security
    validate_monitoring
    validate_production_configs
    validate_network

    generate_report
    show_recommendations
}

# Run main function
main "$@"
