# Stitches Microservices Platform

A complete production-ready microservices architecture for team collaboration, built with Go, gRPC, and modern cloud-native technologies.

## 🚀 Quick Start

```bash
# Complete setup and deployment
make full-setup

# Or step by step:
make setup-env           # Setup environment
make start              # Start all services
make health-check       # Verify everything is working
```

## 🏗️ Architecture

### Microservices
- **Auth Service** (Port 50051) - Authentication, JWT, User Management
- **Chat Service** (Port 50052) - Real-time messaging, channels
- **Notification Service** (Port 50053) - Email, push notifications
- **Project Service** (Port 50054) - Project management, tasks
- **Video Service** (Port 50055) - Video calls, WebRTC
- **Assistant Service** (Port 50056) - AI features, transcription
- **File Service** (Port 50057) - File storage with MinIO
- **API Gateway** (Port 8080) - REST API, load balancing

### Infrastructure
- **PostgreSQL** - Primary database with separate DBs per service
- **Redis** - Caching and pub/sub messaging
- **MinIO** - S3-compatible object storage
- **Nginx** - Load balancing and reverse proxy
- **Prometheus** - Metrics collection
- **Grafana** - Monitoring dashboards

## 📋 Commands

### Essential Commands
```bash
make start              # Start all services
make stop               # Stop all services
make logs               # View logs
make health-check       # Check service health
make dashboard          # Real-time status dashboard
```

### Development
```bash
make build              # Build all services
make test               # Run tests
make lint               # Run linting
make format             # Format code
```

### Production
```bash
make validate           # Validate production readiness
make deploy-prod        # Deploy to production
make monitoring         # Start monitoring stack
```

## 🌐 Service URLs

- **API Gateway**: http://localhost:8080
- **Grafana**: http://localhost:3001 (admin/admin)
- **MinIO Console**: http://localhost:9001 (minioadmin/minioadmin)
- **Prometheus**: http://localhost:9090

## 📚 Documentation

- [Quick Start Guide](./QUICK_START.md)
- [Deployment Guide](./DEPLOYMENT.md)
- [API Documentation](http://localhost:8080/swagger)

## 🔧 Configuration

Edit `.env` file to configure:
- API keys (OpenAI, SendGrid, Zoom)
- Database credentials
- Service endpoints
- Security settings

## 🛠️ Development

1. **Setup**: `make setup-env`
2. **Start**: `make start-dev`
3. **Test**: `make test-integration`
4. **Deploy**: `make deploy-prod`

## 📊 Monitoring

- **Real-time Dashboard**: `make dashboard`
- **Grafana**: http://localhost:3001
- **Health Checks**: `make health-check`
- **Status**: `make status`

## 🔒 Security

- JWT-based authentication
- Non-root containers
- Network isolation
- SSL/TLS support
- Secret management

## 🚀 Production Ready

- Complete Docker infrastructure
- Health checks and monitoring
- Automated deployment
- Load balancing
- Scalable architecture

Built with ❤️ for modern team collaboration.
