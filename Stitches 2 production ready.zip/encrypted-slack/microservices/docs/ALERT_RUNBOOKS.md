# 🚨 Stitches Microservices Alert Runbooks

Comprehensive troubleshooting guides for performance monitoring alerts in the staging environment.

## 🎯 Quick Reference

| Alert | Severity | Response Time | Page |
|-------|----------|---------------|------|
| Service Down | Critical | Immediate | [Link](#service-down) |
| Ultra High Response Time | Critical | 1 minute | [Link](#ultra-high-response-time) |
| Critical Error Rate | Critical | 2 minutes | [Link](#critical-error-rate) |
| High Response Time | Warning | 5 minutes | [Link](#high-response-time) |
| Load Test Failure | Critical | Immediate | [Link](#load-test-failure) |

---

## 🔥 Critical Alerts

### Service Down

**Alert:** `service-down`
**Severity:** Critical
**Impact:** Service unavailable to users

#### Immediate Actions (0-2 minutes)
1. **Verify the alert**
   ```bash
   curl -f http://localhost:8080/health
   make status
   ```

2. **Check service status**
   ```bash
   docker-compose ps
   make logs SERVICE=<service-name>
   ```

3. **Quick restart attempt**
   ```bash
   make restart-service SERVICE=<service-name>
   # Wait 30 seconds
   make health-check
   ```

#### Investigation (2-10 minutes)
1. **Check container logs**
   ```bash
   docker-compose logs --tail=100 <service-name>
   ```

2. **Verify dependencies**
   ```bash
   # Check database
   docker-compose exec postgres pg_isready -U postgres

   # Check Redis
   docker-compose exec redis redis-cli ping

   # Check MinIO
   curl -f http://localhost:9000/minio/health/live
   ```

3. **Check resource usage**
   ```bash
   docker stats
   free -h
   df -h
   ```

#### Resolution Steps
1. **If container crash:**
   ```bash
   make restart-service SERVICE=<service-name>
   ```

2. **If dependency failure:**
   ```bash
   # Restart infrastructure
   make start-infra
   sleep 30
   make restart
   ```

3. **If resource exhaustion:**
   ```bash
   # Clean up resources
   docker system prune -f
   make restart
   ```

#### Escalation
- If service doesn't recover within 10 minutes
- If multiple services are down
- If database/Redis is unresponsive

---

### Ultra High Response Time

**Alert:** `ultra-high-response-time`
**Severity:** Critical
**Threshold:** P95 > 1000ms

#### Immediate Actions (0-1 minute)
1. **Check current performance**
   ```bash
   curl -w "@curl-format.txt" -s -o /dev/null http://localhost:8080/health
   ```

   Create `curl-format.txt`:
   ```
   time_namelookup:  %{time_namelookup}\n
   time_connect:     %{time_connect}\n
   time_appconnect:  %{time_appconnect}\n
   time_pretransfer: %{time_pretransfer}\n
   time_redirect:    %{time_redirect}\n
   time_starttransfer: %{time_starttransfer}\n
   time_total:       %{time_total}\n
   ```

2. **Check system load**
   ```bash
   top -n1
   iostat 1 3
   ```

#### Investigation (1-5 minutes)
1. **Check database performance**
   ```bash
   # Check active connections
   docker-compose exec postgres psql -U postgres -c "
   SELECT count(*) as active_connections,
          state
   FROM pg_stat_activity
   GROUP BY state;"

   # Check slow queries
   docker-compose exec postgres psql -U postgres -c "
   SELECT query, query_start, state, waiting
   FROM pg_stat_activity
   WHERE state != 'idle'
   ORDER BY query_start;"
   ```

2. **Check Redis performance**
   ```bash
   docker-compose exec redis redis-cli INFO stats
   docker-compose exec redis redis-cli SLOWLOG GET 10
   ```

3. **Check application metrics**
   ```bash
   # View Grafana dashboard
   open http://localhost:3001/d/stitches-cicd-performance
   ```

#### Resolution Steps
1. **If database bottleneck:**
   ```bash
   # Kill long-running queries
   docker-compose exec postgres psql -U postgres -c "
   SELECT pg_terminate_backend(pid)
   FROM pg_stat_activity
   WHERE query_start < now() - interval '5 minutes'
   AND state != 'idle';"
   ```

2. **If memory pressure:**
   ```bash
   # Restart high-memory services
   make restart-service SERVICE=assistant-service
   make restart-service SERVICE=video-service
   ```

3. **If CPU saturation:**
   ```bash
   # Scale down concurrent processes
   docker-compose up -d --scale chat-service=1
   ```

#### Prevention
- Monitor database query performance
- Implement connection pooling
- Add Redis caching for frequent queries
- Set up automated scaling

---

### Critical Error Rate

**Alert:** `critical-error-rate`
**Severity:** Critical
**Threshold:** >10% 5xx errors

#### Immediate Actions (0-2 minutes)
1. **Check error types**
   ```bash
   # Check API Gateway logs for error patterns
   make logs SERVICE=api-gateway | grep -E "(ERROR|FATAL|5[0-9]{2})" | tail -20
   ```

2. **Identify failing endpoints**
   ```bash
   # Check Prometheus metrics
   curl -s "http://localhost:9090/api/v1/query?query=rate(http_requests_total{status=~\"5..\"}[5m])" | jq '.data.result'
   ```

#### Investigation (2-10 minutes)
1. **Check service health**
   ```bash
   for service in auth-service chat-service notification-service project-service video-service assistant-service file-service; do
     echo "=== $service ==="
     docker-compose exec $service grpc_health_probe -addr=localhost:$(echo $service | sed 's/.*-service//' | case $(cat) in auth) echo 50051;; chat) echo 50052;; notification) echo 50053;; project) echo 50054;; video) echo 50055;; assistant) echo 50056;; file) echo 50057;; esac)
   done
   ```

2. **Check dependencies**
   ```bash
   # Database connectivity
   make network-test

   # Check for deadlocks
   docker-compose exec postgres psql -U postgres -c "SELECT * FROM pg_stat_activity WHERE wait_event IS NOT NULL;"
   ```

3. **Review recent changes**
   ```bash
   # Check recent deployments
   git log --oneline -10

   # Check if any env vars changed
   diff .env.example .env
   ```

#### Resolution Steps
1. **If single service failure:**
   ```bash
   make restart-service SERVICE=<failing-service>
   ```

2. **If database issues:**
   ```bash
   # Check and fix connections
   docker-compose restart postgres
   sleep 30
   make restart
   ```

3. **If configuration issues:**
   ```bash
   # Rollback to last known good state
   git checkout HEAD~1 -- .env
   make restart
   ```

4. **If cascading failures:**
   ```bash
   # Full system restart
   make stop
   make start
   make health-check
   ```

---

## ⚠️ Warning Alerts

### High Response Time

**Alert:** `high-response-time-p95`
**Severity:** Warning
**Threshold:** P95 > 500ms

#### Investigation Steps
1. **Check current load**
   ```bash
   # CPU and memory usage
   docker stats --no-stream

   # Check request rate
   curl -s "http://localhost:9090/api/v1/query?query=rate(http_requests_total[5m])" | jq '.data.result[0].value[1]'
   ```

2. **Identify bottlenecks**
   ```bash
   # Check database performance
   docker-compose exec postgres psql -U postgres -c "
   SELECT schemaname, tablename, n_tup_ins, n_tup_upd, n_tup_del
   FROM pg_stat_user_tables
   ORDER BY n_tup_ins + n_tup_upd + n_tup_del DESC
   LIMIT 10;"
   ```

3. **Review service logs**
   ```bash
   # Look for performance warnings
   make logs | grep -E "(slow|timeout|performance|latency)" | tail -10
   ```

#### Optimization Actions
1. **Cache optimization**
   ```bash
   # Check Redis cache hit rate
   docker-compose exec redis redis-cli INFO stats | grep hit_rate

   # Clear and warm cache if needed
   docker-compose exec redis redis-cli FLUSHDB
   ```

2. **Database optimization**
   ```bash
   # Analyze and vacuum tables
   docker-compose exec postgres psql -U postgres -c "VACUUM ANALYZE;"
   ```

3. **Service scaling**
   ```bash
   # Scale up high-load services
   docker-compose up -d --scale api-gateway=2
   ```

---

### High Memory Usage

**Alert:** `high-memory-usage`
**Severity:** Warning
**Threshold:** >80% container memory

#### Investigation Steps
1. **Identify memory consumers**
   ```bash
   # Check container memory usage
   docker stats --format "table {{.Name}}\t{{.MemUsage}}\t{{.MemPerc}}" --no-stream

   # Check system memory
   free -h
   ps aux --sort=-%mem | head -10
   ```

2. **Check for memory leaks**
   ```bash
   # Monitor memory over time
   for i in {1..10}; do
     docker stats --no-stream --format "{{.Name}}: {{.MemUsage}}"
     sleep 30
   done
   ```

#### Resolution Actions
1. **Restart high-memory services**
   ```bash
   # Restart services using >256MB
   for service in assistant-service video-service file-service; do
     make restart-service SERVICE=$service
   done
   ```

2. **Clean up unused resources**
   ```bash
   # Docker cleanup
   docker system prune -f
   docker volume prune -f
   ```

3. **Adjust memory limits**
   ```bash
   # Update docker-compose.yml with higher limits temporarily
   # Then restart affected services
   ```

---

### Authentication Failure Rate Spike

**Alert:** `auth-failure-rate-spike`
**Severity:** Warning
**Threshold:** >20% 4xx errors on auth endpoints

#### Security Investigation
1. **Check login attempt patterns**
   ```bash
   # Analyze auth logs for patterns
   make logs SERVICE=auth-service | grep -E "(login|authentication)" | tail -20

   # Check for IP patterns
   make logs SERVICE=api-gateway | grep -E "POST.*auth.*[45][0-9]{2}" | awk '{print $1}' | sort | uniq -c | sort -nr
   ```

2. **Verify legitimate traffic**
   ```bash
   # Check user agent patterns
   make logs SERVICE=api-gateway | grep -E "auth.*401" | grep -o "User-Agent: [^\"]*" | sort | uniq -c
   ```

#### Response Actions
1. **If potential attack:**
   ```bash
   # Enable rate limiting (update nginx config)
   # Monitor for continued patterns
   # Consider IP blocking if confirmed attack
   ```

2. **If configuration issue:**
   ```bash
   # Check JWT secret configuration
   grep JWT_SECRET .env

   # Verify auth service configuration
   make logs SERVICE=auth-service | grep -E "(config|startup)"
   ```

3. **If legitimate load:**
   ```bash
   # Scale auth service
   docker-compose up -d --scale auth-service=2
   ```

---

## 📊 Load Testing Alerts

### Load Test Failure

**Alert:** `load-test-failure`
**Severity:** Critical
**Impact:** CI/CD pipeline blocked

#### Immediate Actions
1. **Check test results**
   ```bash
   # Review latest load test output
   tail -50 load-test-results.log

   # Check GitHub Actions if running in CI
   open https://github.com/your-org/stitches/actions
   ```

2. **Verify staging environment**
   ```bash
   make health-check --detailed
   make status
   ```

#### Investigation Steps
1. **Compare with baseline**
   ```bash
   # Check historical performance
   curl -s "http://localhost:9090/api/v1/query_range?query=load_test_avg_response_time&start=$(date -d '1 day ago' +%s)&end=$(date +%s)&step=3600" | jq '.data.result'
   ```

2. **Check for regressions**
   ```bash
   # Review recent deployments
   git log --oneline --since="1 day ago"

   # Check for configuration changes
   git diff HEAD~5 .env docker-compose.yml
   ```

#### Resolution Steps
1. **If environment issue:**
   ```bash
   # Reset staging environment
   make stop
   make clean
   make start
   sleep 60
   make health-check
   ```

2. **If performance regression:**
   ```bash
   # Rollback recent changes
   git revert HEAD
   make restart

   # Re-run load test
   make load-test
   ```

3. **If infrastructure limits:**
   ```bash
   # Scale up services
   docker-compose up -d --scale api-gateway=3 --scale auth-service=2

   # Increase resource limits
   # Edit docker-compose.yml memory/CPU limits
   ```

---

## 🏗️ Infrastructure Alerts

### Database Connection Pool High

**Alert:** `db-connection-pool-high`
**Severity:** Warning
**Threshold:** >80% connection pool usage

#### Investigation Steps
1. **Check active connections**
   ```bash
   docker-compose exec postgres psql -U postgres -c "
   SELECT count(*), state
   FROM pg_stat_activity
   GROUP BY state
   ORDER BY count DESC;"
   ```

2. **Identify connection sources**
   ```bash
   docker-compose exec postgres psql -U postgres -c "
   SELECT application_name, count(*)
   FROM pg_stat_activity
   WHERE state = 'active'
   GROUP BY application_name
   ORDER BY count DESC;"
   ```

#### Resolution Actions
1. **Kill idle connections**
   ```bash
   docker-compose exec postgres psql -U postgres -c "
   SELECT pg_terminate_backend(pid)
   FROM pg_stat_activity
   WHERE state = 'idle'
   AND query_start < now() - interval '15 minutes';"
   ```

2. **Restart services with connection leaks**
   ```bash
   # Check which services have most connections
   # Restart those services
   make restart-service SERVICE=<service-with-leaks>
   ```

3. **Increase connection limit temporarily**
   ```bash
   docker-compose exec postgres psql -U postgres -c "ALTER SYSTEM SET max_connections = 150;"
   docker-compose restart postgres
   ```

---

### Redis Memory Critical

**Alert:** `redis-memory-critical`
**Severity:** Critical
**Threshold:** >95% memory usage

#### Immediate Actions
1. **Check memory usage details**
   ```bash
   docker-compose exec redis redis-cli INFO memory
   docker-compose exec redis redis-cli MEMORY USAGE
   ```

2. **Clear non-essential data**
   ```bash
   # Flush expired keys
   docker-compose exec redis redis-cli --scan --pattern "*:temp:*" | xargs docker-compose exec redis redis-cli DEL

   # Clear cache if safe to do so
   docker-compose exec redis redis-cli FLUSHDB
   ```

#### Prevention
- Implement key expiration policies
- Monitor Redis memory usage trends
- Set up automatic cleanup scripts

---

## 🔧 Troubleshooting Commands

### Quick Diagnostics
```bash
# One-liner health check
make status && make health-check && docker stats --no-stream

# Service connectivity test
for port in 8080 50051 50052 50053 50054 50055 50056 50057; do
  echo -n "Port $port: "
  nc -z localhost $port && echo "OK" || echo "FAIL"
done

# Database quick check
docker-compose exec postgres psql -U postgres -c "SELECT version();"

# Redis quick check
docker-compose exec redis redis-cli ping

# MinIO quick check
curl -f http://localhost:9000/minio/health/live
```

### Performance Monitoring
```bash
# Real-time performance dashboard
make dashboard

# API response time check
curl -w "@curl-format.txt" -s -o /dev/null http://localhost:8080/health

# Load test
make load-test

# Check Prometheus metrics
curl -s "http://localhost:9090/api/v1/query?query=up" | jq '.data.result'
```

### Log Analysis
```bash
# Search for errors across all services
make logs | grep -E "(ERROR|FATAL|Exception)" | tail -20

# Filter logs by service
make logs SERVICE=auth-service | tail -50

# Check for specific patterns
make logs | grep -E "(timeout|slow|performance)" | tail -10
```

---

## 📞 Escalation Procedures

### Level 1: Self-Service (0-15 minutes)
- Follow runbook procedures
- Check obvious issues (service down, high load)
- Restart services if safe
- Check recent changes

### Level 2: Team Lead (15-30 minutes)
- Complex performance issues
- Multiple service failures
- Database/infrastructure problems
- Security-related alerts

### Level 3: Senior Engineer/Architect (30+ minutes)
- System-wide outages
- Data integrity issues
- Security incidents
- Infrastructure failures

### Emergency Contacts
- **Platform Team:** platform-team@stitches.dev
- **On-Call Engineer:** oncall@stitches.dev
- **Emergency Hotline:** +1-555-STITCHES

---

## 📚 Additional Resources

- [Performance Dashboard](http://localhost:3001/d/stitches-cicd-performance)
- [Grafana Alerts](http://localhost:3001/alerting/list)
- [Prometheus Metrics](http://localhost:9090/targets)
- [API Health Check](http://localhost:8080/health)
- [Deployment Guide](./DEPLOYMENT.md)
- [CI/CD Pipeline](./CI_CD_SETUP.md)

---

**Last Updated:** $(date '+%Y-%m-%d')
**Version:** 1.0.0
**Maintained by:** Platform Team
