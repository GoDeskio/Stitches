#!/bin/bash

# Stitches Microservices Setup Script
# This script sets up the complete microservices environment

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Functions
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}"
    exit 1
}

info() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')] INFO: $1${NC}"
}

# Banner
echo -e "${BLUE}"
cat << 'EOF'
 ____  _   _ _       _
/ ___|| |_(_) |_ ___| |__   ___  ___
\___ \| __| | __/ __| '_ \ / _ \/ __|
 ___) | |_| | || (__| | | |  __/\__ \
|____/ \__|_|\__\___|_| |_|\___||___/

Microservices Setup Script v1.0
EOF
echo -e "${NC}"

log "Starting Stitches microservices setup..."

# Check prerequisites
check_prerequisites() {
    log "Checking prerequisites..."

    # Check Docker
    if ! command -v docker &> /dev/null; then
        error "Docker is not installed. Please install Docker first."
    fi

    # Check Docker Compose
    if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
        error "Docker Compose is not installed. Please install Docker Compose first."
    fi

    # Check if running as root (should not for security)
    if [[ $EUID -eq 0 ]]; then
        warn "Running as root is not recommended for security reasons"
    fi

    log "Prerequisites check completed successfully"
}

# Setup environment
setup_environment() {
    log "Setting up environment..."

    # Create .env file if it doesn't exist
    if [[ ! -f ".env" ]]; then
        log "Creating .env file from template..."
        cp .env.example .env
        info "Created .env file. Please edit it with your API keys and configuration."
        info "Important: Update OPENAI_API_KEY, SENDGRID_API_KEY, and other API keys in .env"
    else
        log ".env file already exists"
    fi

    # Create necessary directories
    mkdir -p logs
    mkdir -p backups
    mkdir -p monitoring/grafana/data
    mkdir -p monitoring/prometheus/data

    # Set proper permissions
    chmod +x deploy-production.sh
    chmod +x scripts/health-check.sh
    chmod +x generate-proto.sh

    log "Environment setup completed"
}

# Verify service configurations
verify_services() {
    log "Verifying service configurations..."

    # Check that all services have necessary files
    local services=("auth-service" "chat-service" "notification-service" "project-service" "video-service" "assistant-service" "file-service" "api-gateway")

    for service in "${services[@]}"; do
        if [[ ! -f "$service/main.go" ]]; then
            error "Missing main.go for $service"
        fi

        if [[ ! -f "$service/Dockerfile" ]]; then
            error "Missing Dockerfile for $service"
        fi

        if [[ ! -f "$service/go.mod" ]]; then
            error "Missing go.mod for $service"
        fi

        log "✓ $service configuration verified"
    done

    log "Service configurations verified successfully"
}

# Generate protobuf files
generate_proto() {
    log "Generating protobuf files..."

    if [[ -f "generate-proto.sh" ]]; then
        chmod +x generate-proto.sh
        ./generate-proto.sh
        log "Protobuf files generated successfully"
    else
        warn "generate-proto.sh not found, skipping protobuf generation"
    fi
}

# Build and test services
build_services() {
    log "Building and testing services..."

    # Build Docker images
    log "Building Docker images..."
    docker-compose build

    log "Services built successfully"
}

# Start infrastructure services
start_infrastructure() {
    log "Starting infrastructure services..."

    # Start PostgreSQL, Redis, MinIO first
    docker-compose up -d postgres redis minio

    # Wait for infrastructure to be ready
    log "Waiting for infrastructure services to be ready..."
    sleep 30

    # Check if infrastructure is ready
    local max_attempts=30
    local attempt=1

    while [[ $attempt -le $max_attempts ]]; do
        if docker-compose exec postgres pg_isready -U postgres >/dev/null 2>&1 && \
           docker-compose exec redis redis-cli ping >/dev/null 2>&1; then
            log "Infrastructure services are ready"
            break
        fi

        if [[ $attempt -eq $max_attempts ]]; then
            error "Infrastructure services failed to become ready within timeout"
        fi

        info "Waiting for infrastructure services... (attempt $attempt/$max_attempts)"
        sleep 10
        ((attempt++))
    done
}

# Start application services
start_services() {
    log "Starting application services..."

    # Start all services
    docker-compose up -d

    # Wait for services to be ready
    sleep 60

    log "Application services started"
}

# Verify deployment
verify_deployment() {
    log "Verifying deployment..."

    # Check service status
    docker-compose ps

    # Test API Gateway
    local max_attempts=10
    local attempt=1

    while [[ $attempt -le $max_attempts ]]; do
        if curl -f http://localhost:8080/health >/dev/null 2>&1; then
            log "API Gateway is responding"
            break
        fi

        if [[ $attempt -eq $max_attempts ]]; then
            error "API Gateway is not responding"
        fi

        sleep 10
        ((attempt++))
    done

    # Run health check script if available
    if [[ -f "scripts/health-check.sh" ]]; then
        log "Running comprehensive health check..."
        ./scripts/health-check.sh --detailed
    fi

    log "Deployment verification completed successfully"
}

# Show next steps
show_next_steps() {
    echo -e "\n${GREEN}Setup completed successfully!${NC}\n"
    echo -e "${BLUE}Service URLs:${NC}"
    echo "  API Gateway:      http://localhost:8080"
    echo "  Grafana:          http://localhost:3001 (admin/admin)"
    echo "  MinIO Console:    http://localhost:9001 (minioadmin/minioadmin)"
    echo "  Prometheus:       http://localhost:9090"
    echo ""

    echo -e "${BLUE}Next Steps:${NC}"
    echo "1. Edit .env file with your API keys (OpenAI, SendGrid, Zoom)"
    echo "2. Test the API endpoints: curl http://localhost:8080/health"
    echo "3. Check service health: make health-check"
    echo "4. View logs: make logs"
    echo "5. Access monitoring: http://localhost:3001"
    echo ""

    echo -e "${BLUE}Useful Commands:${NC}"
    echo "  make start               # Start all services"
    echo "  make stop                # Stop all services"
    echo "  make logs                # View logs"
    echo "  make health-check        # Check service health"
    echo "  make status              # Show service status"
    echo ""

    echo -e "${BLUE}Production Deployment:${NC}"
    echo "  ./deploy-production.sh   # Deploy to production"
    echo ""
}

# Main execution
main() {
    log "Starting Stitches microservices setup..."

    check_prerequisites
    setup_environment
    verify_services
    generate_proto
    build_services
    start_infrastructure
    start_services
    verify_deployment
    show_next_steps

    log "Stitches microservices setup completed successfully!"
}

# Handle interruption
trap 'echo -e "\n${RED}Setup interrupted by user${NC}"; exit 1' INT

# Run main function
main "$@"
