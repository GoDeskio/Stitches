# 🚀 Stitches Microservices CI/CD Pipeline

Comprehensive automated CI/CD pipeline with continuous load testing for staging and production environments.

## 🎯 Pipeline Overview

Our CI/CD pipeline provides:

- **Automated Testing** - Unit tests, integration tests, security scans
- **Continuous Load Testing** - Performance validation in staging
- **Automated Deployment** - Staging and production deployments
- **Performance Monitoring** - Real-time metrics and alerting
- **Quality Gates** - Deployment blocking based on performance criteria

## 📋 Pipeline Stages

### 1. Build & Test Stage
```yaml
Triggers: Push to main/develop/staging, Pull Requests
Duration: ~5-8 minutes
Parallel Jobs: 8 (one per microservice)
```

**Actions:**
- ✅ Go module caching
- ✅ Service compilation
- ✅ Unit test execution
- ✅ Code coverage reporting
- ✅ Linting and formatting

### 2. Security Scanning
```yaml
Triggers: After successful build
Duration: ~2-3 minutes
```

**Actions:**
- ✅ Trivy vulnerability scanning
- ✅ SARIF report generation
- ✅ Security gate enforcement

### 3. Docker Build & Registry
```yaml
Triggers: Non-PR branches only
Duration: ~8-12 minutes
```

**Actions:**
- ✅ Multi-stage Docker builds
- ✅ Image tagging strategy
- ✅ Container registry push
- ✅ Image vulnerability scanning

### 4. Staging Deployment
```yaml
Triggers: staging/develop branch pushes
Duration: ~3-5 minutes
Environment: staging
```

**Actions:**
- ✅ Docker Compose deployment
- ✅ Service health verification
- ✅ Database migration
- ✅ Smoke testing

### 5. Continuous Load Testing
```yaml
Triggers: After staging deployment
Duration: ~15-25 minutes
Parallel Scenarios: 5
```

**Test Scenarios:**
- **Light Load**: 25 users, 2 minutes
- **Medium Load**: 50 users, 3 minutes
- **Heavy Load**: 100 users, 5 minutes
- **Stress Test**: 200 users, 1 minute
- **Endurance Test**: 50 users, 10 minutes

### 6. Performance Analysis
```yaml
Triggers: After load testing
Duration: ~2-3 minutes
```

**Actions:**
- ✅ Performance metrics aggregation
- ✅ Trend analysis
- ✅ Quality gate evaluation
- ✅ Performance badge generation

### 7. Production Deployment
```yaml
Triggers: Manual (workflow_dispatch) on main branch
Duration: ~5-8 minutes
Environment: production
Requires: Staging tests pass + Performance gate pass
```

**Actions:**
- ✅ Production deployment
- ✅ Health verification
- ✅ Release creation
- ✅ Notification

## 🔧 Configuration & Setup

### Required Secrets

Add these secrets to your GitHub repository:

#### Staging Environment
```bash
STAGING_POSTGRES_PASSWORD=secure_staging_db_password
STAGING_JWT_SECRET=staging_jwt_secret_32_chars_minimum
STAGING_OPENAI_API_KEY=sk-staging-openai-key
STAGING_SENDGRID_API_KEY=SG.staging-sendgrid-key
STAGING_URL=https://staging-api.stitches.dev
```

#### Production Environment
```bash
PRODUCTION_POSTGRES_PASSWORD=secure_production_db_password
PRODUCTION_JWT_SECRET=production_jwt_secret_32_chars_minimum
PRODUCTION_OPENAI_API_KEY=sk-production-openai-key
PRODUCTION_SENDGRID_API_KEY=SG.production-sendgrid-key
```

#### Notifications
```bash
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK
```

### Environment Configuration

Create environment-specific configuration files:

#### Staging Environment
```bash
# Copy and modify for staging
cp .env.example .env.staging

# Key staging settings:
ENVIRONMENT=staging
LOG_LEVEL=info
RATE_LIMIT_REQUESTS_PER_MINUTE=500
DB_MAX_OPEN_CONNS=15
REDIS_POOL_SIZE=50
```

#### Production Environment
```bash
# Copy and modify for production
cp .env.example .env.production

# Key production settings:
ENVIRONMENT=production
LOG_LEVEL=warn
RATE_LIMIT_REQUESTS_PER_MINUTE=1000
DB_MAX_OPEN_CONNS=25
REDIS_POOL_SIZE=100
```

## 📊 Load Testing Configuration

### Test Scenarios Matrix

| Scenario | Users | Duration | Purpose |
|----------|-------|----------|---------|
| Light Load | 25 | 2 min | Basic functionality |
| Medium Load | 50 | 3 min | Normal traffic simulation |
| Heavy Load | 100 | 5 min | Peak traffic simulation |
| Stress Test | 200 | 1 min | Breaking point detection |
| Endurance | 50 | 10 min | Stability validation |

### Performance Thresholds

```javascript
thresholds: {
  'http_req_duration': [
    'p(95)<500',    // 95% under 500ms
    'p(99)<1000',   // 99% under 1s
  ],
  'http_req_failed': ['rate<0.05'], // <5% error rate
  'checks': ['rate>0.95'],          // >95% checks pass
}
```

### Quality Gates

**EXCELLENT** (Production Ready):
- Avg response time < 100ms
- Error rate < 1%
- Success rate > 98%

**GOOD** (Staging Ready):
- Avg response time < 200ms
- Error rate < 2%
- Success rate > 95%

**NEEDS IMPROVEMENT** (Blocks Production):
- Avg response time > 400ms
- Error rate > 5%
- Success rate < 90%

## 🎛️ Pipeline Usage

### Automated Triggers

```bash
# Staging deployment (automatic)
git push origin staging

# Development testing (automatic)
git push origin develop

# Production release (manual approval required)
git push origin main
# Then: GitHub Actions → Run workflow → Deploy to production
```

### Manual Triggers

```bash
# Custom load test parameters
GitHub Actions → Stitches Microservices CI/CD Pipeline → Run workflow
Environment: staging
Load test duration: 600 (seconds)
Concurrent users: 150
```

### Monitoring Deployments

```bash
# Real-time pipeline status
GitHub Repository → Actions → Stitches Microservices CI/CD Pipeline

# Staging environment health
https://staging-api.stitches.dev/health

# Load test results
GitHub Actions → Artifacts → load-test-results-*
```

## 📈 Performance Monitoring

### Metrics Collection

**Application Metrics:**
- Response times (avg, p95, p99)
- Request rates
- Error rates
- Success rates per API

**Infrastructure Metrics:**
- CPU utilization
- Memory usage
- Database connections
- Redis cache hit rates

**Business Metrics:**
- User authentication rates
- Message sending rates
- File upload rates
- Project creation rates

### Alerting Configuration

```yaml
# Grafana Alert Rules
- alert: HighResponseTime
  expr: http_request_duration_p95 > 500
  for: 2m

- alert: HighErrorRate
  expr: http_request_error_rate > 0.05
  for: 1m

- alert: LoadTestFailure
  expr: load_test_success_rate < 0.95
  for: 0m
```

## 🔄 Continuous Improvement

### Daily Automated Testing

The pipeline runs daily load tests at 2 AM UTC:
- Validates system health
- Detects performance regressions
- Maintains performance baselines

### Performance Trending

```bash
# View performance trends
GitHub Repository → Insights → Dependency graph → Insights

# Download historical data
GitHub Actions → Artifacts → performance-analysis
```

### Optimization Cycle

1. **Monitor** - Daily load test results
2. **Analyze** - Performance trends and bottlenecks
3. **Optimize** - Code and infrastructure improvements
4. **Validate** - Automated testing of improvements
5. **Deploy** - Continuous deployment of optimizations

## 🚨 Troubleshooting

### Pipeline Failures

**Build Stage Failures:**
```bash
# Check build logs
GitHub Actions → Failed job → View details

# Common fixes:
- Update Go dependencies: go mod tidy
- Fix linting errors: go fmt ./...
- Resolve test failures: Check test output
```

**Load Test Failures:**
```bash
# Check load test logs
GitHub Actions → load-testing job → View k6 output

# Common issues:
- Service not responsive: Check health endpoints
- High error rates: Review service logs
- Performance degradation: Check resource usage
```

**Deployment Failures:**
```bash
# Check deployment logs
GitHub Actions → deploy-staging/deploy-production

# Common fixes:
- Verify secrets configuration
- Check environment file syntax
- Validate Docker Compose configuration
```

### Performance Issues

**High Response Times:**
```bash
# Check resource limits
docker-compose ps
docker stats

# Optimize queries
# Scale services
# Add caching
```

**High Error Rates:**
```bash
# Check service logs
docker-compose logs service-name

# Common causes:
- Database connection limits
- Memory constraints
- Network timeouts
```

## 📞 Support & Maintenance

### Pipeline Maintenance

**Weekly Tasks:**
- Review performance trends
- Update dependencies
- Verify secret rotation
- Check monitoring alerts

**Monthly Tasks:**
- Performance baseline updates
- Load test scenario reviews
- Infrastructure capacity planning
- Security vulnerability assessments

### Getting Help

**Pipeline Issues:**
- Check GitHub Actions logs
- Review pipeline documentation
- Validate configuration files

**Performance Questions:**
- Analyze load test reports
- Review Grafana dashboards
- Check performance trends

**Deployment Problems:**
- Verify environment configuration
- Check service health endpoints
- Review container logs

---

## 🎉 Pipeline Benefits

✅ **Automated Quality Assurance** - Continuous testing and validation
✅ **Performance Confidence** - Load testing before production
✅ **Rapid Deployment** - Automated staging and production deployment
✅ **Performance Monitoring** - Real-time metrics and alerting
✅ **Quality Gates** - Deployment blocking based on performance
✅ **Continuous Improvement** - Daily testing and optimization

**The CI/CD pipeline ensures that only high-performing, reliable code reaches production!** 🚀
