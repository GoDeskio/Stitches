#!/bin/bash

# Stitches Microservices Integration Test Script
# This script performs comprehensive testing of all microservices

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
API_GATEWAY_URL="http://localhost:8080"
TIMEOUT=30
VERBOSE=false

# Test counters
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0

# Functions
log() {
    echo -e "${GREEN}[$(date +'%H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%H:%M:%S')] ERROR: $1${NC}"
}

info() {
    echo -e "${BLUE}[$(date +'%H:%M:%S')] INFO: $1${NC}"
}

# Test function
run_test() {
    local test_name="$1"
    local test_command="$2"
    local expected_status="${3:-0}"

    TOTAL_TESTS=$((TOTAL_TESTS + 1))

    if [[ "$VERBOSE" == true ]]; then
        info "Running test: $test_name"
        info "Command: $test_command"
    fi

    if eval "$test_command" >/dev/null 2>&1; then
        local actual_status=$?
        if [[ $actual_status -eq $expected_status ]]; then
            log "✅ PASS: $test_name"
            PASSED_TESTS=$((PASSED_TESTS + 1))
            return 0
        else
            error "❌ FAIL: $test_name (exit code: $actual_status, expected: $expected_status)"
            FAILED_TESTS=$((FAILED_TESTS + 1))
            return 1
        fi
    else
        error "❌ FAIL: $test_name (command failed)"
        FAILED_TESTS=$((FAILED_TESTS + 1))
        return 1
    fi
}

# HTTP test function
test_http_endpoint() {
    local endpoint="$1"
    local method="${2:-GET}"
    local expected_status="${3:-200}"
    local data="${4:-}"

    local curl_cmd="curl -s -o /dev/null -w '%{http_code}' --max-time $TIMEOUT -X $method"

    if [[ -n "$data" ]]; then
        curl_cmd="$curl_cmd -H 'Content-Type: application/json' -d '$data'"
    fi

    curl_cmd="$curl_cmd $endpoint"

    local response_code=$(eval "$curl_cmd")

    if [[ "$response_code" == "$expected_status" ]]; then
        return 0
    else
        return 1
    fi
}

# gRPC test function
test_grpc_service() {
    local service_addr="$1"
    local service_name="$2"

    if command -v grpc_health_probe &> /dev/null; then
        if grpc_health_probe -addr="$service_addr" -connect-timeout="${TIMEOUT}s" >/dev/null 2>&1; then
            return 0
        else
            return 1
        fi
    else
        # Fallback to TCP connection test
        if timeout "$TIMEOUT" bash -c "</dev/tcp/${service_addr%:*}/${service_addr#*:}" 2>/dev/null; then
            return 0
        else
            return 1
        fi
    fi
}

# Wait for services
wait_for_services() {
    log "Waiting for services to be ready..."

    local max_attempts=30
    local attempt=1

    while [[ $attempt -le $max_attempts ]]; do
        if curl -f "$API_GATEWAY_URL/health" >/dev/null 2>&1; then
            log "API Gateway is ready"
            break
        fi

        if [[ $attempt -eq $max_attempts ]]; then
            error "Services did not become ready within timeout"
            return 1
        fi

        info "Waiting for services... (attempt $attempt/$max_attempts)"
        sleep 10
        ((attempt++))
    done

    sleep 10  # Additional wait for full initialization
}

# Test infrastructure services
test_infrastructure() {
    log "Testing infrastructure services..."

    # Test PostgreSQL
    run_test "PostgreSQL Connection" \
        "docker-compose exec -T postgres pg_isready -U postgres"

    # Test Redis
    run_test "Redis Connection" \
        "docker-compose exec -T redis redis-cli ping"

    # Test MinIO
    run_test "MinIO Health Check" \
        "test_http_endpoint http://localhost:9000/minio/health/live GET 200"
}

# Test gRPC services
test_grpc_services() {
    log "Testing gRPC services..."

    # Test each gRPC service
    run_test "Auth Service gRPC" \
        "test_grpc_service localhost:50051 auth-service"

    run_test "Chat Service gRPC" \
        "test_grpc_service localhost:50052 chat-service"

    run_test "Notification Service gRPC" \
        "test_grpc_service localhost:50053 notification-service"

    run_test "Project Service gRPC" \
        "test_grpc_service localhost:50054 project-service"

    run_test "Video Service gRPC" \
        "test_grpc_service localhost:50055 video-service"

    run_test "Assistant Service gRPC" \
        "test_grpc_service localhost:50056 assistant-service"

    run_test "File Service gRPC" \
        "test_grpc_service localhost:50057 file-service"
}

# Test API Gateway endpoints
test_api_gateway() {
    log "Testing API Gateway endpoints..."

    # Test health endpoint
    run_test "API Gateway Health Check" \
        "test_http_endpoint $API_GATEWAY_URL/health GET 200"

    # Test CORS headers
    run_test "API Gateway CORS Headers" \
        "curl -s -H 'Origin: http://localhost:3000' -H 'Access-Control-Request-Method: POST' -H 'Access-Control-Request-Headers: X-Requested-With' -X OPTIONS $API_GATEWAY_URL/api/v1/auth/login | grep -q 'Access-Control-Allow-Origin'"

    # Test unknown endpoint (should return 404)
    run_test "API Gateway 404 Response" \
        "test_http_endpoint $API_GATEWAY_URL/unknown-endpoint GET 404"
}

# Test authentication endpoints
test_authentication() {
    log "Testing authentication endpoints..."

    # Test register endpoint exists
    run_test "Auth Register Endpoint" \
        "test_http_endpoint $API_GATEWAY_URL/api/v1/auth/register POST 400"

    # Test login endpoint exists
    run_test "Auth Login Endpoint" \
        "test_http_endpoint $API_GATEWAY_URL/api/v1/auth/login POST 400"

    # Test protected endpoint without auth (should return 401)
    run_test "Protected Endpoint Unauthorized" \
        "test_http_endpoint $API_GATEWAY_URL/api/v1/users/profile GET 401"
}

# Test service integration
test_service_integration() {
    log "Testing service integration..."

    # Test that API Gateway can communicate with all services
    # This is done implicitly through the API endpoint tests

    # Test database connectivity for each service
    local services=("auth_db" "chat_db" "notification_db" "project_db" "video_db" "assistant_db" "file_db")

    for db in "${services[@]}"; do
        run_test "Database $db Connection" \
            "docker-compose exec -T postgres psql -U postgres -d $db -c 'SELECT 1;'"
    done
}

# Test monitoring and observability
test_monitoring() {
    log "Testing monitoring and observability..."

    # Test Prometheus
    run_test "Prometheus Health Check" \
        "test_http_endpoint http://localhost:9090/-/healthy GET 200"

    # Test Grafana
    run_test "Grafana Health Check" \
        "test_http_endpoint http://localhost:3001/api/health GET 200"

    # Test metrics endpoints (if available)
    run_test "API Gateway Metrics" \
        "test_http_endpoint $API_GATEWAY_URL/metrics GET 200"
}

# Test performance
test_performance() {
    log "Testing basic performance..."

    # Test API Gateway response time
    local start_time=$(date +%s.%N)
    if curl -f "$API_GATEWAY_URL/health" >/dev/null 2>&1; then
        local end_time=$(date +%s.%N)
        local response_time=$(echo "$end_time - $start_time" | bc -l 2>/dev/null || echo "0")
        local response_time_ms=$(echo "$response_time * 1000" | bc -l 2>/dev/null || echo "0")

        if (( $(echo "$response_time_ms < 1000" | bc -l 2>/dev/null || echo "1") )); then
            log "✅ PASS: API Gateway Response Time (${response_time_ms}ms < 1000ms)"
            PASSED_TESTS=$((PASSED_TESTS + 1))
        else
            error "❌ FAIL: API Gateway Response Time (${response_time_ms}ms >= 1000ms)"
            FAILED_TESTS=$((FAILED_TESTS + 1))
        fi
        TOTAL_TESTS=$((TOTAL_TESTS + 1))
    else
        error "❌ FAIL: API Gateway Performance Test (endpoint not accessible)"
        FAILED_TESTS=$((FAILED_TESTS + 1))
        TOTAL_TESTS=$((TOTAL_TESTS + 1))
    fi
}

# Generate test report
generate_report() {
    echo ""
    echo -e "${BLUE}==============================${NC}"
    echo -e "${BLUE}     TEST EXECUTION REPORT    ${NC}"
    echo -e "${BLUE}==============================${NC}"
    echo ""
    echo "Total Tests: $TOTAL_TESTS"
    echo -e "Passed: ${GREEN}$PASSED_TESTS${NC}"
    echo -e "Failed: ${RED}$FAILED_TESTS${NC}"
    echo ""

    local success_rate=0
    if [[ $TOTAL_TESTS -gt 0 ]]; then
        success_rate=$(echo "scale=2; $PASSED_TESTS * 100 / $TOTAL_TESTS" | bc -l 2>/dev/null || echo "0")
    fi

    echo "Success Rate: ${success_rate}%"
    echo ""

    if [[ $FAILED_TESTS -eq 0 ]]; then
        log "🎉 All tests passed! The microservices are working correctly."
        return 0
    else
        error "❌ Some tests failed. Please check the logs and fix any issues."
        return 1
    fi
}

# Show usage
show_usage() {
    echo "Usage: $0 [OPTIONS]"
    echo "Options:"
    echo "  --verbose, -v    Enable verbose output"
    echo "  --timeout, -t    Set timeout for individual tests (default: 30s)"
    echo "  --help, -h       Show this help message"
    exit 0
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --verbose|-v)
            VERBOSE=true
            shift
            ;;
        --timeout|-t)
            TIMEOUT="$2"
            shift 2
            ;;
        --help|-h)
            show_usage
            ;;
        *)
            error "Unknown option: $1"
            ;;
    esac
done

# Banner
echo -e "${BLUE}"
cat << 'EOF'
 ____  _   _ _       _
/ ___|| |_(_) |_ ___| |__   ___  ___
\___ \| __| | __/ __| '_ \ / _ \/ __|
 ___) | |_| | || (__| | | |  __/\__ \
|____/ \__|_|\__\___|_| |_|\___||___/

Microservices Integration Test Suite v1.0
EOF
echo -e "${NC}"

# Main execution
main() {
    log "Starting microservices integration tests..."

    # Check if services are running
    if ! docker-compose ps | grep -q "Up"; then
        error "Services are not running. Please start them first with 'make start' or 'docker-compose up -d'"
    fi

    wait_for_services
    test_infrastructure
    test_grpc_services
    test_api_gateway
    test_authentication
    test_service_integration
    test_monitoring
    test_performance

    generate_report
}

# Run main function
main "$@"
