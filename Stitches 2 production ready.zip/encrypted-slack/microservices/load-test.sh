#!/bin/bash

# Stitches Microservices Load Testing Script
# Comprehensive performance testing for all services

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Configuration
API_GATEWAY_URL="http://localhost:8080"
CONCURRENT_USERS=50
TEST_DURATION=60
RAMP_UP_TIME=10
REQUESTS_PER_USER=100

# Test results
TOTAL_REQUESTS=0
SUCCESSFUL_REQUESTS=0
FAILED_REQUESTS=0
TOTAL_RESPONSE_TIME=0
MIN_RESPONSE_TIME=999999
MAX_RESPONSE_TIME=0

# Functions
log() {
    echo -e "${GREEN}[$(date +'%H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%H:%M:%S')] ERROR: $1${NC}"
}

info() {
    echo -e "${BLUE}[$(date +'%H:%M:%S')] INFO: $1${NC}"
}

# Banner
echo -e "${BLUE}"
cat << 'EOF'
 ____  _   _ _       _
/ ___|| |_(_) |_ ___| |__   ___  ___
\___ \| __| | __/ __| '_ \ / _ \/ __|
 ___) | |_| | || (__| | | |  __/\__ \
|____/ \__|_|\__\___|_| |_|\___||___/

Microservices Load Testing Suite v1.0
EOF
echo -e "${NC}"

# Test HTTP endpoint performance
test_endpoint() {
    local endpoint=$1
    local method=${2:-GET}
    local data=${3:-""}
    local expected_status=${4:-200}

    local start_time=$(date +%s.%N)
    local status_code=""
    local response_time=""

    if command -v curl &> /dev/null; then
        if [[ -n "$data" ]]; then
            status_code=$(curl -s -o /dev/null -w "%{http_code}" \
                --max-time 30 \
                -X "$method" \
                -H "Content-Type: application/json" \
                -d "$data" \
                "$endpoint" 2>/dev/null || echo "000")
        else
            status_code=$(curl -s -o /dev/null -w "%{http_code}" \
                --max-time 30 \
                -X "$method" \
                "$endpoint" 2>/dev/null || echo "000")
        fi

        local end_time=$(date +%s.%N)
        response_time=$(echo "$end_time - $start_time" | bc -l 2>/dev/null || echo "0")

        TOTAL_REQUESTS=$((TOTAL_REQUESTS + 1))

        if [[ "$status_code" == "$expected_status" ]]; then
            SUCCESSFUL_REQUESTS=$((SUCCESSFUL_REQUESTS + 1))
        else
            FAILED_REQUESTS=$((FAILED_REQUESTS + 1))
        fi

        # Update response time statistics
        local response_time_ms=$(echo "$response_time * 1000" | bc -l 2>/dev/null || echo "0")
        TOTAL_RESPONSE_TIME=$(echo "$TOTAL_RESPONSE_TIME + $response_time_ms" | bc -l 2>/dev/null || echo "$TOTAL_RESPONSE_TIME")

        if (( $(echo "$response_time_ms < $MIN_RESPONSE_TIME" | bc -l 2>/dev/null || echo "0") )); then
            MIN_RESPONSE_TIME=$response_time_ms
        fi

        if (( $(echo "$response_time_ms > $MAX_RESPONSE_TIME" | bc -l 2>/dev/null || echo "1") )); then
            MAX_RESPONSE_TIME=$response_time_ms
        fi

        echo "$status_code|$response_time_ms"
    else
        echo "000|0"
    fi
}

# Simulate concurrent users
simulate_user_load() {
    local user_id=$1
    local requests_per_user=$2
    local results_file=$3

    for i in $(seq 1 $requests_per_user); do
        # Test various endpoints with different patterns
        case $((i % 5)) in
            0)
                # Health check (lightweight)
                result=$(test_endpoint "$API_GATEWAY_URL/health" "GET")
                ;;
            1)
                # Authentication (medium load)
                result=$(test_endpoint "$API_GATEWAY_URL/api/v1/auth/login" "POST" '{"email":"test@example.com","password":"password"}' "400")
                ;;
            2)
                # Chat channels (read operation)
                result=$(test_endpoint "$API_GATEWAY_URL/api/v1/chat/channels" "GET" "" "401")
                ;;
            3)
                # Projects (read operation)
                result=$(test_endpoint "$API_GATEWAY_URL/api/v1/projects" "GET" "" "401")
                ;;
            4)
                # File upload simulation (write operation)
                result=$(test_endpoint "$API_GATEWAY_URL/api/v1/files/upload" "POST" '{"filename":"test.txt","content":"test"}' "401")
                ;;
        esac

        echo "USER_$user_id:$result" >> "$results_file"

        # Small delay to simulate realistic user behavior
        sleep 0.1
    done
}

# Run load test scenarios
run_load_tests() {
    log "Starting load testing scenarios..."

    local results_file="/tmp/load_test_results_$(date +%s).txt"

    # Test 1: API Gateway Health Check Stress Test
    info "Test 1: API Gateway Health Check Stress Test"
    echo "Starting health check stress test..." > "$results_file"

    for i in $(seq 1 100); do
        result=$(test_endpoint "$API_GATEWAY_URL/health" "GET")
        echo "HEALTH_CHECK:$result" >> "$results_file"
    done

    log "✅ Health Check Stress Test completed (100 requests)"

    # Test 2: Authentication Endpoint Load Test
    info "Test 2: Authentication Endpoint Load Test"

    for i in $(seq 1 50); do
        result=$(test_endpoint "$API_GATEWAY_URL/api/v1/auth/login" "POST" '{"email":"user'$i'@example.com","password":"password"}' "400")
        echo "AUTH_TEST:$result" >> "$results_file"
    done

    log "✅ Authentication Load Test completed (50 requests)"

    # Test 3: Mixed Endpoint Load Test
    info "Test 3: Mixed Endpoint Load Test"

    local endpoints=(
        "$API_GATEWAY_URL/health:GET::200"
        "$API_GATEWAY_URL/api/v1/auth/register:POST:{\"email\":\"test@example.com\",\"password\":\"password\"}:400"
        "$API_GATEWAY_URL/api/v1/chat/channels:GET::401"
        "$API_GATEWAY_URL/api/v1/projects:GET::401"
        "$API_GATEWAY_URL/api/v1/files/upload:POST:{\"filename\":\"test.txt\"}:401"
    )

    for i in $(seq 1 25); do
        for endpoint_config in "${endpoints[@]}"; do
            IFS=':' read -r url method data expected_status <<< "$endpoint_config"
            result=$(test_endpoint "$url" "$method" "$data" "$expected_status")
            echo "MIXED_TEST:$result" >> "$results_file"
        done
    done

    log "✅ Mixed Endpoint Load Test completed (125 requests)"

    # Test 4: Sustained Load Test
    info "Test 4: Sustained Load Test (30 seconds)"

    local sustained_start=$(date +%s)
    local sustained_end=$((sustained_start + 30))
    local sustained_count=0

    while [[ $(date +%s) -lt $sustained_end ]]; do
        result=$(test_endpoint "$API_GATEWAY_URL/health" "GET")
        echo "SUSTAINED:$result" >> "$results_file"
        sustained_count=$((sustained_count + 1))
        sleep 0.5
    done

    log "✅ Sustained Load Test completed ($sustained_count requests in 30 seconds)"

    # Test 5: Error Handling Test
    info "Test 5: Error Handling and Recovery Test"

    for i in $(seq 1 20); do
        # Test non-existent endpoints
        result=$(test_endpoint "$API_GATEWAY_URL/api/v1/nonexistent" "GET" "" "404")
        echo "ERROR_TEST:$result" >> "$results_file"

        # Test malformed requests
        result=$(test_endpoint "$API_GATEWAY_URL/api/v1/auth/login" "POST" "invalid_json" "400")
        echo "ERROR_TEST:$result" >> "$results_file"
    done

    log "✅ Error Handling Test completed (40 requests)"

    echo "$results_file"
}

# Analyze performance results
analyze_results() {
    local results_file=$1

    if [[ ! -f "$results_file" ]]; then
        warn "Results file not found, using accumulated statistics"
        return
    fi

    log "Analyzing performance results..."

    local total_tests=$(grep -c ":" "$results_file" 2>/dev/null || echo "0")
    local health_checks=$(grep -c "HEALTH_CHECK:" "$results_file" 2>/dev/null || echo "0")
    local auth_tests=$(grep -c "AUTH_TEST:" "$results_file" 2>/dev/null || echo "0")
    local mixed_tests=$(grep -c "MIXED_TEST:" "$results_file" 2>/dev/null || echo "0")
    local sustained_tests=$(grep -c "SUSTAINED:" "$results_file" 2>/dev/null || echo "0")
    local error_tests=$(grep -c "ERROR_TEST:" "$results_file" 2>/dev/null || echo "0")

    # Calculate average response time
    local avg_response_time=0
    if [[ $TOTAL_REQUESTS -gt 0 ]]; then
        avg_response_time=$(echo "scale=2; $TOTAL_RESPONSE_TIME / $TOTAL_REQUESTS" | bc -l 2>/dev/null || echo "0")
    fi

    # Calculate success rate
    local success_rate=0
    if [[ $TOTAL_REQUESTS -gt 0 ]]; then
        success_rate=$(echo "scale=2; $SUCCESSFUL_REQUESTS * 100 / $TOTAL_REQUESTS" | bc -l 2>/dev/null || echo "0")
    fi

    # Display results
    echo ""
    echo -e "${WHITE}===============================================${NC}"
    echo -e "${WHITE}          LOAD TEST RESULTS SUMMARY          ${NC}"
    echo -e "${WHITE}===============================================${NC}"
    echo ""

    echo -e "${BLUE}Test Execution Summary:${NC}"
    echo "  Total Test Executions: $total_tests"
    echo "  Health Check Tests: $health_checks"
    echo "  Authentication Tests: $auth_tests"
    echo "  Mixed Endpoint Tests: $mixed_tests"
    echo "  Sustained Load Tests: $sustained_tests"
    echo "  Error Handling Tests: $error_tests"
    echo ""

    echo -e "${BLUE}Performance Metrics:${NC}"
    echo "  Total Requests: $TOTAL_REQUESTS"
    echo "  Successful Requests: $SUCCESSFUL_REQUESTS"
    echo "  Failed Requests: $FAILED_REQUESTS"
    echo "  Success Rate: ${success_rate}%"
    echo ""

    echo -e "${BLUE}Response Time Analysis:${NC}"
    echo "  Average Response Time: ${avg_response_time}ms"
    echo "  Minimum Response Time: ${MIN_RESPONSE_TIME}ms"
    echo "  Maximum Response Time: ${MAX_RESPONSE_TIME}ms"
    echo ""

    # Performance assessment
    echo -e "${BLUE}Performance Assessment:${NC}"

    if (( $(echo "$avg_response_time < 100" | bc -l 2>/dev/null || echo "1") )); then
        echo -e "  Response Time: ${GREEN}EXCELLENT${NC} (< 100ms)"
    elif (( $(echo "$avg_response_time < 500" | bc -l 2>/dev/null || echo "1") )); then
        echo -e "  Response Time: ${YELLOW}GOOD${NC} (< 500ms)"
    else
        echo -e "  Response Time: ${RED}NEEDS IMPROVEMENT${NC} (> 500ms)"
    fi

    if (( $(echo "$success_rate > 95" | bc -l 2>/dev/null || echo "0") )); then
        echo -e "  Reliability: ${GREEN}EXCELLENT${NC} (> 95% success rate)"
    elif (( $(echo "$success_rate > 90" | bc -l 2>/dev/null || echo "0") )); then
        echo -e "  Reliability: ${YELLOW}GOOD${NC} (> 90% success rate)"
    else
        echo -e "  Reliability: ${RED}NEEDS IMPROVEMENT${NC} (< 90% success rate)"
    fi

    if [[ $TOTAL_REQUESTS -gt 300 ]]; then
        echo -e "  Load Capacity: ${GREEN}EXCELLENT${NC} (> 300 requests handled)"
    elif [[ $TOTAL_REQUESTS -gt 200 ]]; then
        echo -e "  Load Capacity: ${YELLOW}GOOD${NC} (> 200 requests handled)"
    else
        echo -e "  Load Capacity: ${YELLOW}MODERATE${NC} (< 200 requests handled)"
    fi

    echo ""
}

# Generate load test recommendations
generate_recommendations() {
    echo -e "${BLUE}Performance Optimization Recommendations:${NC}"
    echo ""

    if (( $(echo "$MAX_RESPONSE_TIME > 1000" | bc -l 2>/dev/null || echo "0") )); then
        echo -e "${YELLOW}⚠️  High Response Times Detected:${NC}"
        echo "   • Consider implementing request caching"
        echo "   • Optimize database queries and indexing"
        echo "   • Review service-to-service communication"
        echo ""
    fi

    if [[ $FAILED_REQUESTS -gt 0 ]]; then
        echo -e "${YELLOW}⚠️  Request Failures Detected:${NC}"
        echo "   • Implement circuit breaker patterns"
        echo "   • Add request retry mechanisms"
        echo "   • Monitor service dependencies"
        echo ""
    fi

    echo -e "${GREEN}✅ Scaling Recommendations:${NC}"
    echo "   • Consider horizontal scaling for high-traffic endpoints"
    echo "   • Implement load balancing across service instances"
    echo "   • Monitor resource usage and scale accordingly"
    echo "   • Use Redis caching for frequently accessed data"
    echo ""

    echo -e "${GREEN}✅ Production Deployment:${NC}"
    echo "   • Run load tests regularly in staging environment"
    echo "   • Set up performance monitoring and alerting"
    echo "   • Implement gradual traffic ramping for deployments"
    echo "   • Use Docker container resource limits"
    echo ""
}

# Main execution
main() {
    log "Starting comprehensive load testing for Stitches microservices..."

    # Pre-test checks
    info "Performing pre-test environment checks..."

    if ! command -v curl &> /dev/null; then
        warn "curl not available - simulating HTTP requests"
    fi

    if ! command -v bc &> /dev/null; then
        warn "bc not available - basic math calculations only"
    fi

    # Check if services are reachable (without Docker)
    info "Checking API Gateway availability..."
    api_check=$(test_endpoint "$API_GATEWAY_URL/health" "GET" "" "200")
    if [[ "$api_check" == "000|0" ]]; then
        warn "API Gateway not reachable - running simulation mode"
        info "In production with Docker, services would be available at configured ports"
    fi

    # Run load tests
    local results_file=$(run_load_tests)

    # Analyze results
    analyze_results "$results_file"

    # Generate recommendations
    generate_recommendations

    # Final summary
    echo -e "${WHITE}===============================================${NC}"
    echo -e "${GREEN}🎯 LOAD TESTING COMPLETED SUCCESSFULLY${NC}"
    echo -e "${WHITE}===============================================${NC}"
    echo ""
    echo -e "${CYAN}Next Steps:${NC}"
    echo "1. Deploy services with 'make start' for live testing"
    echo "2. Configure monitoring alerts for performance metrics"
    echo "3. Run tests periodically in staging environment"
    echo "4. Scale services based on load testing results"
    echo ""

    # Cleanup
    if [[ -f "$results_file" ]]; then
        rm -f "$results_file"
    fi

    log "Load testing suite completed!"
}

# Run main function
main "$@"
