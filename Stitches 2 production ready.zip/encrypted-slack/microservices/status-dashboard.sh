#!/bin/bash

# Stitches Microservices Status Dashboard
# Real-time monitoring dashboard for all microservices

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Configuration
REFRESH_INTERVAL=5
CONTINUOUS=false

# Service definitions
declare -A SERVICES=(
    ["api-gateway"]="http://localhost:8080/health"
    ["auth-service"]="grpc://localhost:50051"
    ["chat-service"]="grpc://localhost:50052"
    ["notification-service"]="grpc://localhost:50053"
    ["project-service"]="grpc://localhost:50054"
    ["video-service"]="grpc://localhost:50055"
    ["assistant-service"]="grpc://localhost:50056"
    ["file-service"]="grpc://localhost:50057"
)

declare -A INFRASTRUCTURE=(
    ["postgres"]="postgres://localhost:5432"
    ["redis"]="redis://localhost:6379"
    ["minio"]="http://localhost:9000/minio/health/live"
    ["nginx"]="http://localhost:80/health"
    ["prometheus"]="http://localhost:9090/-/healthy"
    ["grafana"]="http://localhost:3001/api/health"
)

# Functions
clear_screen() {
    clear
}

get_timestamp() {
    date '+%Y-%m-%d %H:%M:%S'
}

# Check HTTP service
check_http_service() {
    local url=$1
    local timeout=5

    if curl -f -s --max-time "$timeout" "$url" > /dev/null 2>&1; then
        echo "healthy"
    else
        echo "unhealthy"
    fi
}

# Check gRPC service
check_grpc_service() {
    local address=${1#grpc://}
    local timeout=5

    if command -v grpc_health_probe &> /dev/null; then
        if grpc_health_probe -addr="$address" -connect-timeout="${timeout}s" > /dev/null 2>&1; then
            echo "healthy"
        else
            echo "unhealthy"
        fi
    else
        # Fallback to TCP connection test
        if timeout "$timeout" bash -c "</dev/tcp/${address%:*}/${address#*:}" 2>/dev/null; then
            echo "reachable"
        else
            echo "unreachable"
        fi
    fi
}

# Check PostgreSQL
check_postgres() {
    if command -v psql &> /dev/null; then
        if PGPASSWORD=password psql -h localhost -U postgres -d postgres -c "SELECT 1;" > /dev/null 2>&1; then
            echo "healthy"
        else
            echo "unhealthy"
        fi
    else
        # Fallback to Docker exec
        if docker-compose ps postgres | grep -q "Up" 2>/dev/null; then
            if docker-compose exec -T postgres pg_isready -U postgres > /dev/null 2>&1; then
                echo "healthy"
            else
                echo "unhealthy"
            fi
        else
            echo "down"
        fi
    fi
}

# Check Redis
check_redis() {
    if command -v redis-cli &> /dev/null; then
        if redis-cli -h localhost ping > /dev/null 2>&1; then
            echo "healthy"
        else
            echo "unhealthy"
        fi
    else
        # Fallback to Docker exec
        if docker-compose ps redis | grep -q "Up" 2>/dev/null; then
            if docker-compose exec -T redis redis-cli ping > /dev/null 2>&1; then
                echo "healthy"
            else
                echo "unhealthy"
            fi
        else
            echo "down"
        fi
    fi
}

# Get container status
get_container_status() {
    local service=$1
    if command -v docker-compose &> /dev/null; then
        local status=$(docker-compose ps "$service" 2>/dev/null | tail -n +3 | awk '{print $3}')
        if [[ -n "$status" ]]; then
            echo "$status"
        else
            echo "not_found"
        fi
    else
        echo "unknown"
    fi
}

# Get container resource usage
get_container_resources() {
    local service=$1
    if command -v docker &> /dev/null; then
        local container_id=$(docker-compose ps -q "$service" 2>/dev/null)
        if [[ -n "$container_id" ]]; then
            local stats=$(docker stats --no-stream --format "table {{.CPUPerc}}\t{{.MemUsage}}" "$container_id" 2>/dev/null | tail -1)
            echo "$stats"
        else
            echo "N/A N/A"
        fi
    else
        echo "N/A N/A"
    fi
}

# Get system metrics
get_system_metrics() {
    local cpu_usage=""
    local memory_usage=""
    local disk_usage=""
    local load_average=""

    # CPU usage
    if command -v top &> /dev/null; then
        cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1 2>/dev/null || echo "N/A")
    fi

    # Memory usage
    if command -v free &> /dev/null; then
        memory_usage=$(free | grep Mem | awk '{printf "%.1f", ($3/$2) * 100.0}' 2>/dev/null || echo "N/A")
    fi

    # Disk usage
    if command -v df &> /dev/null; then
        disk_usage=$(df . | tail -1 | awk '{print $5}' | sed 's/%//' 2>/dev/null || echo "N/A")
    fi

    # Load average
    if [[ -f /proc/loadavg ]]; then
        load_average=$(cat /proc/loadavg | awk '{print $1}' 2>/dev/null || echo "N/A")
    fi

    echo "$cpu_usage|$memory_usage|$disk_usage|$load_average"
}

# Status color function
get_status_color() {
    local status=$1
    case "$status" in
        "healthy"|"Up") echo "$GREEN" ;;
        "unhealthy"|"down"|"Exit") echo "$RED" ;;
        "reachable"|"degraded") echo "$YELLOW" ;;
        *) echo "$NC" ;;
    esac
}

# Print header
print_header() {
    echo -e "${BLUE}┌─────────────────────────────────────────────────────────────────────────────────┐${NC}"
    echo -e "${BLUE}│${WHITE}                        STITCHES MICROSERVICES STATUS DASHBOARD                   ${BLUE}│${NC}"
    echo -e "${BLUE}├─────────────────────────────────────────────────────────────────────────────────┤${NC}"
    echo -e "${BLUE}│${NC} Last Updated: $(get_timestamp)                                              ${BLUE}│${NC}"
    echo -e "${BLUE}└─────────────────────────────────────────────────────────────────────────────────┘${NC}"
    echo ""
}

# Print service status
print_services() {
    echo -e "${WHITE}APPLICATION SERVICES${NC}"
    echo -e "${BLUE}┌─────────────────────┬─────────────┬─────────────┬─────────────────────────────┐${NC}"
    echo -e "${BLUE}│${WHITE} Service             ${BLUE}│${WHITE} Health      ${BLUE}│${WHITE} Container   ${BLUE}│${WHITE} Resources (CPU/Memory)      ${BLUE}│${NC}"
    echo -e "${BLUE}├─────────────────────┼─────────────┼─────────────┼─────────────────────────────┤${NC}"

    for service in "${!SERVICES[@]}"; do
        local url="${SERVICES[$service]}"
        local health_status=""
        local container_status=$(get_container_status "$service")
        local resources=$(get_container_resources "$service")

        if [[ "$url" == grpc://* ]]; then
            health_status=$(check_grpc_service "$url")
        else
            health_status=$(check_http_service "$url")
        fi

        local health_color=$(get_status_color "$health_status")
        local container_color=$(get_status_color "$container_status")

        printf "${BLUE}│${NC} %-19s ${BLUE}│${health_color} %-11s ${BLUE}│${container_color} %-11s ${BLUE}│${NC} %-27s ${BLUE}│${NC}\n" \
            "$service" "$health_status" "$container_status" "$resources"
    done

    echo -e "${BLUE}└─────────────────────┴─────────────┴─────────────┴─────────────────────────────┘${NC}"
    echo ""
}

# Print infrastructure status
print_infrastructure() {
    echo -e "${WHITE}INFRASTRUCTURE SERVICES${NC}"
    echo -e "${BLUE}┌─────────────────────┬─────────────┬─────────────┬─────────────────────────────┐${NC}"
    echo -e "${BLUE}│${WHITE} Service             ${BLUE}│${WHITE} Health      ${BLUE}│${WHITE} Container   ${BLUE}│${WHITE} Resources (CPU/Memory)      ${BLUE}│${NC}"
    echo -e "${BLUE}├─────────────────────┼─────────────┼─────────────┼─────────────────────────────┤${NC}"

    # Special handling for postgres and redis
    for service in postgres redis; do
        local health_status=""
        local container_status=$(get_container_status "$service")
        local resources=$(get_container_resources "$service")

        if [[ "$service" == "postgres" ]]; then
            health_status=$(check_postgres)
        elif [[ "$service" == "redis" ]]; then
            health_status=$(check_redis)
        fi

        local health_color=$(get_status_color "$health_status")
        local container_color=$(get_status_color "$container_status")

        printf "${BLUE}│${NC} %-19s ${BLUE}│${health_color} %-11s ${BLUE}│${container_color} %-11s ${BLUE}│${NC} %-27s ${BLUE}│${NC}\n" \
            "$service" "$health_status" "$container_status" "$resources"
    done

    # Other infrastructure services
    for service in "${!INFRASTRUCTURE[@]}"; do
        if [[ "$service" != "postgres" && "$service" != "redis" ]]; then
            local url="${INFRASTRUCTURE[$service]}"
            local health_status=$(check_http_service "$url")
            local container_status=$(get_container_status "$service")
            local resources=$(get_container_resources "$service")

            local health_color=$(get_status_color "$health_status")
            local container_color=$(get_status_color "$container_status")

            printf "${BLUE}│${NC} %-19s ${BLUE}│${health_color} %-11s ${BLUE}│${container_color} %-11s ${BLUE}│${NC} %-27s ${BLUE}│${NC}\n" \
                "$service" "$health_status" "$container_status" "$resources"
        fi
    done

    echo -e "${BLUE}└─────────────────────┴─────────────┴─────────────┴─────────────────────────────┘${NC}"
    echo ""
}

# Print system metrics
print_system_metrics() {
    local metrics=$(get_system_metrics)
    local cpu=$(echo "$metrics" | cut -d'|' -f1)
    local memory=$(echo "$metrics" | cut -d'|' -f2)
    local disk=$(echo "$metrics" | cut -d'|' -f3)
    local load=$(echo "$metrics" | cut -d'|' -f4)

    echo -e "${WHITE}SYSTEM METRICS${NC}"
    echo -e "${BLUE}┌─────────────────────┬─────────────────────┬─────────────────────┬─────────────────────┐${NC}"
    echo -e "${BLUE}│${WHITE} CPU Usage           ${BLUE}│${WHITE} Memory Usage        ${BLUE}│${WHITE} Disk Usage          ${BLUE}│${WHITE} Load Average        ${BLUE}│${NC}"
    echo -e "${BLUE}├─────────────────────┼─────────────────────┼─────────────────────┼─────────────────────┤${NC}"

    # Color coding for metrics
    local cpu_color=$NC
    local memory_color=$NC
    local disk_color=$NC

    if [[ "$cpu" != "N/A" ]] && (( $(echo "$cpu > 80" | bc -l 2>/dev/null || echo "0") )); then
        cpu_color=$RED
    elif [[ "$cpu" != "N/A" ]] && (( $(echo "$cpu > 60" | bc -l 2>/dev/null || echo "0") )); then
        cpu_color=$YELLOW
    else
        cpu_color=$GREEN
    fi

    if [[ "$memory" != "N/A" ]] && (( $(echo "$memory > 80" | bc -l 2>/dev/null || echo "0") )); then
        memory_color=$RED
    elif [[ "$memory" != "N/A" ]] && (( $(echo "$memory > 60" | bc -l 2>/dev/null || echo "0") )); then
        memory_color=$YELLOW
    else
        memory_color=$GREEN
    fi

    if [[ "$disk" != "N/A" ]] && (( $(echo "$disk > 80" | bc -l 2>/dev/null || echo "0") )); then
        disk_color=$RED
    elif [[ "$disk" != "N/A" ]] && (( $(echo "$disk > 60" | bc -l 2>/dev/null || echo "0") )); then
        disk_color=$YELLOW
    else
        disk_color=$GREEN
    fi

    printf "${BLUE}│${cpu_color} %-19s ${BLUE}│${memory_color} %-19s ${BLUE}│${disk_color} %-19s ${BLUE}│${NC} %-19s ${BLUE}│${NC}\n" \
        "${cpu}%" "${memory}%" "${disk}%" "$load"

    echo -e "${BLUE}└─────────────────────┴─────────────────────┴─────────────────────┴─────────────────────┘${NC}"
    echo ""
}

# Print quick actions
print_actions() {
    echo -e "${WHITE}QUICK ACTIONS${NC}"
    echo -e "${CYAN}Commands:${NC}"
    echo -e "  ${YELLOW}make start${NC}         - Start all services"
    echo -e "  ${YELLOW}make stop${NC}          - Stop all services"
    echo -e "  ${YELLOW}make restart${NC}       - Restart all services"
    echo -e "  ${YELLOW}make logs${NC}          - View logs"
    echo -e "  ${YELLOW}make health-check${NC}  - Run health check"
    echo ""
    echo -e "${CYAN}URLs:${NC}"
    echo -e "  ${YELLOW}API Gateway:${NC}      http://localhost:8080"
    echo -e "  ${YELLOW}Grafana:${NC}          http://localhost:3001 (admin/admin)"
    echo -e "  ${YELLOW}MinIO Console:${NC}    http://localhost:9001 (minioadmin/minioadmin)"
    echo -e "  ${YELLOW}Prometheus:${NC}       http://localhost:9090"
    echo ""

    if [[ "$CONTINUOUS" == true ]]; then
        echo -e "${CYAN}Press Ctrl+C to stop continuous monitoring${NC}"
    else
        echo -e "${CYAN}Use --continuous flag for real-time monitoring${NC}"
    fi
}

# Print overall status summary
print_summary() {
    local total_services=0
    local healthy_services=0

    # Count application services
    for service in "${!SERVICES[@]}"; do
        total_services=$((total_services + 1))
        local url="${SERVICES[$service]}"
        local status=""

        if [[ "$url" == grpc://* ]]; then
            status=$(check_grpc_service "$url")
        else
            status=$(check_http_service "$url")
        fi

        if [[ "$status" == "healthy" ]]; then
            healthy_services=$((healthy_services + 1))
        fi
    done

    # Count infrastructure services
    local postgres_status=$(check_postgres)
    local redis_status=$(check_redis)

    total_services=$((total_services + 2))
    if [[ "$postgres_status" == "healthy" ]]; then
        healthy_services=$((healthy_services + 1))
    fi
    if [[ "$redis_status" == "healthy" ]]; then
        healthy_services=$((healthy_services + 1))
    fi

    local overall_status="DEGRADED"
    local status_color=$YELLOW

    if [[ $healthy_services -eq $total_services ]]; then
        overall_status="HEALTHY"
        status_color=$GREEN
    elif [[ $healthy_services -eq 0 ]]; then
        overall_status="DOWN"
        status_color=$RED
    fi

    echo -e "${WHITE}OVERALL STATUS${NC}"
    echo -e "${BLUE}┌─────────────────────────────────────────────────────────────────────────────────┐${NC}"
    printf "${BLUE}│${NC} System Status: ${status_color}%-10s${NC} │ Services: ${GREEN}%2d${NC}/${BLUE}%2d${NC} healthy                     ${BLUE}│${NC}\n" \
        "$overall_status" "$healthy_services" "$total_services"
    echo -e "${BLUE}└─────────────────────────────────────────────────────────────────────────────────┘${NC}"
    echo ""
}

# Show dashboard
show_dashboard() {
    clear_screen
    print_header
    print_summary
    print_services
    print_infrastructure
    print_system_metrics
    print_actions
}

# Show usage
show_usage() {
    echo "Usage: $0 [OPTIONS]"
    echo "Options:"
    echo "  --continuous, -c     Run in continuous mode (refresh every 5 seconds)"
    echo "  --interval, -i NUM   Set refresh interval in seconds (default: 5)"
    echo "  --help, -h           Show this help message"
    exit 0
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --continuous|-c)
            CONTINUOUS=true
            shift
            ;;
        --interval|-i)
            REFRESH_INTERVAL="$2"
            shift 2
            ;;
        --help|-h)
            show_usage
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Main execution
main() {
    if [[ "$CONTINUOUS" == true ]]; then
        # Continuous monitoring mode
        while true; do
            show_dashboard
            sleep "$REFRESH_INTERVAL"
        done
    else
        # Single snapshot mode
        show_dashboard
    fi
}

# Handle interruption
trap 'echo -e "\n${YELLOW}Monitoring stopped by user${NC}"; exit 0' INT

# Run main function
main "$@"
