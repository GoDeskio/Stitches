# Stitches Microservices Deployment Guide

Complete guide for deploying the Stitches microservices platform to production.

## 🏗️ Architecture Overview

The platform consists of 8 microservices and 6 infrastructure components, all orchestrated with Docker Compose.

### Core Services
- **Auth Service** - Authentication and user management
- **Chat Service** - Real-time messaging and channels
- **Notification Service** - Email and push notifications
- **Project Service** - Project management and tasks
- **Video Service** - Video calls and WebRTC
- **Assistant Service** - AI features and transcription
- **File Service** - File storage and management
- **API Gateway** - REST API and load balancing

### Infrastructure
- **PostgreSQL** - Primary database
- **Redis** - Caching and pub/sub
- **MinIO** - Object storage
- **Nginx** - Load balancer
- **Prometheus** - Metrics collection
- **Grafana** - Monitoring dashboards

## 🚀 Quick Deployment

### Prerequisites
- Docker & Docker Compose
- 4GB+ RAM, 20GB+ disk space
- Domain name (for production)

### One-Command Deployment
```bash
make full-setup
```

## 📋 Step-by-Step Deployment

### 1. Environment Setup
```bash
# Clone repository
git clone <repository>
cd microservices

# Setup environment
cp .env.example .env
# Edit .env with your configuration
```

### 2. Configure Services
Edit `.env` file:
```bash
# Required
JWT_SECRET=your-secure-jwt-secret
POSTGRES_PASSWORD=your-secure-password

# Optional (for full functionality)
OPENAI_API_KEY=your-openai-key
SENDGRID_API_KEY=your-sendgrid-key
ZOOM_API_KEY=your-zoom-key
```

### 3. Deploy Infrastructure
```bash
# Start infrastructure services
make start-infra

# Wait for services to be ready
sleep 30

# Verify infrastructure
make health-check
```

### 4. Deploy Application Services
```bash
# Build and start all services
make start

# Verify deployment
make health-check
make status
```

### 5. Verify Deployment
```bash
# Run integration tests
make test-integration

# Check API Gateway
curl http://localhost:8080/health

# View real-time dashboard
make dashboard
```

## 🔧 Production Configuration

### Security Settings
```bash
# Strong passwords
POSTGRES_PASSWORD=secure-random-password-32-chars
JWT_SECRET=secure-jwt-secret-minimum-32-characters

# SSL/TLS (for production)
SSL_CERT_PATH=/etc/ssl/certs/stitches.crt
SSL_KEY_PATH=/etc/ssl/private/stitches.key
```

### Performance Tuning
```bash
# Database connections
DB_MAX_OPEN_CONNS=25
DB_MAX_IDLE_CONNS=5

# Redis settings
REDIS_POOL_SIZE=100
REDIS_POOL_TIMEOUT=30s
```

### Resource Limits
```yaml
# In docker-compose.yml
deploy:
  resources:
    limits:
      cpus: '0.5'
      memory: 512M
```

## 📊 Monitoring Setup

### Prometheus Configuration
- Metrics collection from all services
- Custom alerts and thresholds
- Service discovery

### Grafana Dashboards
- Service health overview
- Performance metrics
- Resource utilization
- Custom alerts

### Health Checks
```bash
# Real-time monitoring
make dashboard-continuous

# Detailed health check
make health-check-detailed

# JSON output for automation
./scripts/health-check.sh --json
```

## 🔄 Scaling

### Horizontal Scaling
```bash
# Scale specific services
docker-compose up -d --scale auth-service=3
docker-compose up -d --scale api-gateway=5
```

### Load Balancing
- Nginx for HTTP traffic
- gRPC load balancing
- Database connection pooling

### Resource Monitoring
```bash
# Monitor resource usage
make perf-monitor

# Load testing
make load-test
```

## 🛡️ Security

### Built-in Security Features
- Non-root containers
- Network isolation
- JWT authentication
- Input validation
- Rate limiting

### SSL/TLS Setup
```bash
# Generate certificates
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout nginx/ssl/key.pem \
  -out nginx/ssl/cert.pem

# Update nginx configuration
# Uncomment HTTPS block in nginx/nginx.conf
```

### Secret Management
- Environment-based secrets
- Docker secrets support
- External secret management

## 🔄 Backup & Recovery

### Database Backup
```bash
# Automated backup
make backup-db

# Schedule daily backups
0 2 * * * cd /path/to/microservices && make backup-db
```

### Full System Backup
```bash
# Backup everything
make backup-full

# Restore from backup
make restore-full BACKUP_DIR=backup_directory
```

## 🚨 Troubleshooting

### Common Issues

**Services won't start:**
```bash
make logs              # Check logs
make status            # Check status
make restart           # Restart services
```

**Database connection issues:**
```bash
# Test database
docker-compose exec postgres psql -U postgres -c "SELECT 1;"

# Reset database (DEV ONLY)
docker-compose down -v
docker-compose up -d postgres
```

**High resource usage:**
```bash
docker stats           # Check container resources
make dashboard         # Real-time monitoring
```

### Emergency Recovery
```bash
# Stop all services
make stop

# Restore from backup
make restore-db BACKUP=latest_backup.sql

# Restart services
make start

# Verify functionality
make health-check
```

## 📈 Performance Optimization

### Database Optimization
```sql
-- PostgreSQL settings for production
shared_buffers = '256MB'
effective_cache_size = '1GB'
maintenance_work_mem = '64MB'
```

### Application Optimization
```bash
# Go build optimizations
CGO_ENABLED=0 GOOS=linux go build -ldflags="-w -s"

# Container optimization
# Multi-stage builds
# Minimal base images
# Layer caching
```

## 🎯 Production Checklist

### Pre-Deployment
- [ ] Environment variables configured
- [ ] SSL certificates installed
- [ ] Database backups tested
- [ ] Monitoring configured
- [ ] Load testing completed
- [ ] Security scan passed

### Post-Deployment
- [ ] All services healthy
- [ ] Database migrations applied
- [ ] Monitoring alerts configured
- [ ] Backup procedures tested
- [ ] Performance baseline established

## 📞 Support

### Monitoring
- Grafana: http://localhost:3001
- Prometheus: http://localhost:9090
- Health Dashboard: `make dashboard`

### Diagnostics
```bash
make validate          # Production readiness
make health-check      # Service health
make logs              # Service logs
make status            # Container status
```

### Emergency Contacts
- System Health: `make dashboard`
- Logs: `make logs`
- Status: `make status`

---

**Complete deployment guide for production-ready microservices platform! 🚀**
