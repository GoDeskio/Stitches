import http from 'k6/http';
import { check, sleep } from 'k6';
import { Counter, Rate, Trend } from 'k6/metrics';
import { randomString } from 'https://jslib.k6.io/k6-utils/1.2.0/index.js';

// Custom metrics
const successRate = new Rate('success_rate');
const responseTime = new Trend('response_time');
const errorCounter = new Counter('errors');
const authSuccessRate = new Rate('auth_success_rate');
const chatSuccessRate = new Rate('chat_success_rate');
const projectSuccessRate = new Rate('project_success_rate');
const fileSuccessRate = new Rate('file_success_rate');

// Test configuration
export let options = {
  stages: [
    { duration: '2m', target: 20 },  // Ramp up to 20 users
    { duration: '5m', target: 50 },  // Stay at 50 users
    { duration: '2m', target: 100 }, // Ramp up to 100 users
    { duration: '10m', target: 100 }, // Stay at 100 users
    { duration: '2m', target: 0 },   // Ramp down
  ],
  thresholds: {
    // Performance thresholds
    'http_req_duration': [
      'p(95)<500',    // 95% of requests must complete below 500ms
      'p(99)<1000',   // 99% of requests must complete below 1s
    ],
    'http_req_failed': ['rate<0.05'], // Error rate must be below 5%
    'checks': ['rate>0.95'],          // 95% of all checks must pass

    // Custom metrics thresholds
    'success_rate': ['rate>0.95'],
    'auth_success_rate': ['rate>0.90'],
    'chat_success_rate': ['rate>0.95'],
    'project_success_rate': ['rate>0.95'],
    'file_success_rate': ['rate>0.90'],
  },
};

// Base URL configuration
const baseUrl = __ENV.STAGING_URL || 'http://localhost:8080';
const apiVersion = '/api/v1';

// Test data
const testUsers = [
  { email: 'loadtest1@stitches.dev', password: 'LoadTest123!' },
  { email: 'loadtest2@stitches.dev', password: 'LoadTest123!' },
  { email: 'loadtest3@stitches.dev', password: 'LoadTest123!' },
];

// Helper functions
function makeRequest(method, endpoint, payload = null, headers = {}) {
  const startTime = new Date().getTime();

  let response;
  if (method === 'POST' && payload) {
    response = http.post(endpoint, JSON.stringify(payload), {
      headers: { 'Content-Type': 'application/json', ...headers },
    });
  } else if (method === 'GET') {
    response = http.get(endpoint, { headers });
  } else {
    response = http.request(method, endpoint, payload, { headers });
  }

  const endTime = new Date().getTime();
  const duration = endTime - startTime;

  responseTime.add(duration);

  return response;
}

// Main test function
export default function() {
  const userIndex = __VU % testUsers.length;
  const testUser = testUsers[userIndex];

  // Test 1: Health Check
  testHealthCheck();
  sleep(0.5);

  // Test 2: Authentication Flow
  const authToken = testAuthentication(testUser);
  sleep(1);

  // Test 3: Chat API Tests
  testChatAPI(authToken);
  sleep(0.5);

  // Test 4: Project API Tests
  testProjectAPI(authToken);
  sleep(0.5);

  // Test 5: File API Tests
  testFileAPI(authToken);
  sleep(0.5);

  // Test 6: Mixed Load Pattern
  testMixedLoad(authToken);

  // Random sleep to simulate user think time
  sleep(Math.random() * 3 + 1);
}

// Test Functions
function testHealthCheck() {
  const response = makeRequest('GET', `${baseUrl}/health`);

  const success = check(response, {
    'health check status is 200': (r) => r.status === 200,
    'health check response time < 100ms': (r) => r.timings.duration < 100,
    'health check contains status': (r) => r.json('status') === 'ok',
  });

  successRate.add(success);

  if (!success) {
    errorCounter.add(1);
    console.log(`Health check failed: ${response.status}`);
  }
}

function testAuthentication(user) {
  // Test login
  const loginPayload = {
    email: user.email,
    password: user.password
  };

  const loginResponse = makeRequest('POST', `${baseUrl}${apiVersion}/auth/login`, loginPayload);

  const loginSuccess = check(loginResponse, {
    'login request processed': (r) => r.status === 400 || r.status === 401 || r.status === 200,
    'login response time < 500ms': (r) => r.timings.duration < 500,
  });

  authSuccessRate.add(loginSuccess);

  // Test registration (expect conflict or success)
  const registerPayload = {
    email: `test_${randomString(8)}@stitches.dev`,
    password: 'TestPassword123!',
    name: `Test User ${randomString(4)}`
  };

  const registerResponse = makeRequest('POST', `${baseUrl}${apiVersion}/auth/register`, registerPayload);

  const registerSuccess = check(registerResponse, {
    'register request processed': (r) => r.status === 400 || r.status === 409 || r.status === 201,
    'register response time < 1000ms': (r) => r.timings.duration < 1000,
  });

  authSuccessRate.add(registerSuccess);

  // Return mock token for subsequent requests
  return 'mock_jwt_token_for_testing';
}

function testChatAPI(authToken) {
  const headers = authToken ? { 'Authorization': `Bearer ${authToken}` } : {};

  // Test get channels
  const channelsResponse = makeRequest('GET', `${baseUrl}${apiVersion}/chat/channels`, null, headers);

  const channelsSuccess = check(channelsResponse, {
    'channels request handled': (r) => r.status === 401 || r.status === 200,
    'channels response time < 300ms': (r) => r.timings.duration < 300,
  });

  chatSuccessRate.add(channelsSuccess);

  // Test send message
  const messagePayload = {
    channel_id: 'general',
    content: `Load test message ${randomString(10)}`,
    type: 'text'
  };

  const messageResponse = makeRequest('POST', `${baseUrl}${apiVersion}/chat/channels/general/messages`, messagePayload, headers);

  const messageSuccess = check(messageResponse, {
    'message request handled': (r) => r.status === 401 || r.status === 201,
    'message response time < 500ms': (r) => r.timings.duration < 500,
  });

  chatSuccessRate.add(messageSuccess);
}

function testProjectAPI(authToken) {
  const headers = authToken ? { 'Authorization': `Bearer ${authToken}` } : {};

  // Test get projects
  const projectsResponse = makeRequest('GET', `${baseUrl}${apiVersion}/projects`, null, headers);

  const projectsSuccess = check(projectsResponse, {
    'projects request handled': (r) => r.status === 401 || r.status === 200,
    'projects response time < 400ms': (r) => r.timings.duration < 400,
  });

  projectSuccessRate.add(projectsSuccess);

  // Test create project
  const projectPayload = {
    name: `Load Test Project ${randomString(6)}`,
    description: 'Project created during load testing',
    status: 'active'
  };

  const createProjectResponse = makeRequest('POST', `${baseUrl}${apiVersion}/projects`, projectPayload, headers);

  const createSuccess = check(createProjectResponse, {
    'create project request handled': (r) => r.status === 401 || r.status === 201,
    'create project response time < 800ms': (r) => r.timings.duration < 800,
  });

  projectSuccessRate.add(createSuccess);
}

function testFileAPI(authToken) {
  const headers = authToken ? { 'Authorization': `Bearer ${authToken}` } : {};

  // Test file upload
  const filePayload = {
    filename: `loadtest_${randomString(8)}.txt`,
    content: 'This is a load test file content',
    size: 1024
  };

  const uploadResponse = makeRequest('POST', `${baseUrl}${apiVersion}/files/upload`, filePayload, headers);

  const uploadSuccess = check(uploadResponse, {
    'file upload request handled': (r) => r.status === 401 || r.status === 201,
    'file upload response time < 1000ms': (r) => r.timings.duration < 1000,
  });

  fileSuccessRate.add(uploadSuccess);

  // Test file list
  const listResponse = makeRequest('GET', `${baseUrl}${apiVersion}/files`, null, headers);

  const listSuccess = check(listResponse, {
    'file list request handled': (r) => r.status === 401 || r.status === 200,
    'file list response time < 300ms': (r) => r.timings.duration < 300,
  });

  fileSuccessRate.add(listSuccess);
}

function testMixedLoad(authToken) {
  // Simulate realistic user behavior with mixed requests
  const endpoints = [
    { method: 'GET', path: '/health', weight: 3 },
    { method: 'GET', path: `${apiVersion}/chat/channels`, weight: 2 },
    { method: 'GET', path: `${apiVersion}/projects`, weight: 2 },
    { method: 'GET', path: `${apiVersion}/files`, weight: 1 },
  ];

  // Select random endpoint based on weight
  const totalWeight = endpoints.reduce((sum, ep) => sum + ep.weight, 0);
  let random = Math.floor(Math.random() * totalWeight);

  let selectedEndpoint;
  for (const endpoint of endpoints) {
    random -= endpoint.weight;
    if (random < 0) {
      selectedEndpoint = endpoint;
      break;
    }
  }

  const headers = authToken ? { 'Authorization': `Bearer ${authToken}` } : {};
  const response = makeRequest(selectedEndpoint.method, `${baseUrl}${selectedEndpoint.path}`, null, headers);

  const success = check(response, {
    'mixed load request handled': (r) => r.status < 500,
    'mixed load response time < 1000ms': (r) => r.timings.duration < 1000,
  });

  successRate.add(success);
}

// Setup function (runs once per VU)
export function setup() {
  console.log('🚀 Starting Stitches Microservices Load Test');
  console.log(`Target URL: ${baseUrl}`);
  console.log(`Test Users: ${testUsers.length}`);

  // Verify base URL is accessible
  const healthResponse = http.get(`${baseUrl}/health`);
  if (healthResponse.status !== 200) {
    console.warn(`Warning: Health check failed with status ${healthResponse.status}`);
  }

  return { baseUrl, startTime: new Date() };
}

// Teardown function (runs once after all VUs finish)
export function teardown(data) {
  const endTime = new Date();
  const duration = (endTime - data.startTime) / 1000;

  console.log('🏁 Load Test Completed');
  console.log(`Total Duration: ${duration.toFixed(2)} seconds`);
  console.log('📊 Check detailed results in the summary report');
}

// Custom summary function
export function handleSummary(data) {
  return {
    'stdout': createTextSummary(data),
    'load-test-report.html': createHtmlReport(data),
    'load-test-results.json': JSON.stringify(data, null, 2),
  };
}

function createTextSummary(data) {
  const summary = `
🔍 STITCHES MICROSERVICES LOAD TEST SUMMARY
============================================

📊 Test Overview:
   Duration: ${data.state.testRunDurationMs / 1000}s
   VUs: ${data.metrics.vus.values.max}
   Iterations: ${data.metrics.iterations.values.count}

⚡ Performance Metrics:
   Avg Response Time: ${data.metrics.http_req_duration.values.avg.toFixed(2)}ms
   95th Percentile: ${data.metrics.http_req_duration.values['p(95)'].toFixed(2)}ms
   99th Percentile: ${data.metrics.http_req_duration.values['p(99)'].toFixed(2)}ms

📈 Request Statistics:
   Total Requests: ${data.metrics.http_reqs.values.count}
   Request Rate: ${data.metrics.http_reqs.values.rate.toFixed(2)}/s
   Failed Requests: ${(data.metrics.http_req_failed.values.rate * 100).toFixed(2)}%

✅ Success Rates:
   Overall: ${(data.metrics.success_rate?.values.rate * 100 || 0).toFixed(2)}%
   Auth API: ${(data.metrics.auth_success_rate?.values.rate * 100 || 0).toFixed(2)}%
   Chat API: ${(data.metrics.chat_success_rate?.values.rate * 100 || 0).toFixed(2)}%
   Project API: ${(data.metrics.project_success_rate?.values.rate * 100 || 0).toFixed(2)}%
   File API: ${(data.metrics.file_success_rate?.values.rate * 100 || 0).toFixed(2)}%

🎯 Performance Grade: ${getPerformanceGrade(data)}
`;

  return summary;
}

function createHtmlReport(data) {
  const performanceGrade = getPerformanceGrade(data);
  const gradeColor = performanceGrade === 'A+' ? 'green' :
                     performanceGrade === 'A' ? 'lightgreen' :
                     performanceGrade === 'B' ? 'yellow' : 'red';

  return `
<!DOCTYPE html>
<html>
<head>
  <title>Stitches Microservices Load Test Report</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .header { background: #2c3e50; color: white; padding: 20px; border-radius: 5px; }
    .metric { background: #ecf0f1; padding: 15px; margin: 10px 0; border-radius: 5px; }
    .grade { font-size: 24px; font-weight: bold; color: ${gradeColor}; }
    .success { color: green; }
    .warning { color: orange; }
    .error { color: red; }
  </style>
</head>
<body>
  <div class="header">
    <h1>🚀 Stitches Microservices Load Test Report</h1>
    <p>Generated: ${new Date().toISOString()}</p>
  </div>

  <div class="metric">
    <h2>📊 Test Overview</h2>
    <p><strong>Duration:</strong> ${data.state.testRunDurationMs / 1000}s</p>
    <p><strong>Virtual Users:</strong> ${data.metrics.vus.values.max}</p>
    <p><strong>Total Iterations:</strong> ${data.metrics.iterations.values.count}</p>
  </div>

  <div class="metric">
    <h2>⚡ Performance Metrics</h2>
    <p><strong>Average Response Time:</strong> ${data.metrics.http_req_duration.values.avg.toFixed(2)}ms</p>
    <p><strong>95th Percentile:</strong> ${data.metrics.http_req_duration.values['p(95)'].toFixed(2)}ms</p>
    <p><strong>99th Percentile:</strong> ${data.metrics.http_req_duration.values['p(99)'].toFixed(2)}ms</p>
  </div>

  <div class="metric">
    <h2>📈 Request Statistics</h2>
    <p><strong>Total Requests:</strong> ${data.metrics.http_reqs.values.count}</p>
    <p><strong>Request Rate:</strong> ${data.metrics.http_reqs.values.rate.toFixed(2)}/s</p>
    <p><strong>Failed Requests:</strong> ${(data.metrics.http_req_failed.values.rate * 100).toFixed(2)}%</p>
  </div>

  <div class="metric">
    <h2>✅ Success Rates</h2>
    <p><strong>Overall:</strong> ${(data.metrics.success_rate?.values.rate * 100 || 0).toFixed(2)}%</p>
    <p><strong>Auth API:</strong> ${(data.metrics.auth_success_rate?.values.rate * 100 || 0).toFixed(2)}%</p>
    <p><strong>Chat API:</strong> ${(data.metrics.chat_success_rate?.values.rate * 100 || 0).toFixed(2)}%</p>
    <p><strong>Project API:</strong> ${(data.metrics.project_success_rate?.values.rate * 100 || 0).toFixed(2)}%</p>
    <p><strong>File API:</strong> ${(data.metrics.file_success_rate?.values.rate * 100 || 0).toFixed(2)}%</p>
  </div>

  <div class="metric">
    <h2>🎯 Performance Grade</h2>
    <p class="grade">${performanceGrade}</p>
  </div>
</body>
</html>`;
}

function getPerformanceGrade(data) {
  const avgResponseTime = data.metrics.http_req_duration.values.avg;
  const errorRate = data.metrics.http_req_failed.values.rate;
  const successRate = data.metrics.success_rate?.values.rate || 0;

  if (avgResponseTime < 100 && errorRate < 0.01 && successRate > 0.98) return 'A+';
  if (avgResponseTime < 200 && errorRate < 0.02 && successRate > 0.95) return 'A';
  if (avgResponseTime < 400 && errorRate < 0.05 && successRate > 0.90) return 'B';
  if (avgResponseTime < 800 && errorRate < 0.10 && successRate > 0.85) return 'C';
  return 'D';
}
